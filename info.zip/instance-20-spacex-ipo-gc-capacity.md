# Instance 20 (`S*` Shard) — GC Capacity Analysis for SpaceX IPO

> **Paste into Confluence via the Markdown macro.**

| | |
|---|---|
| **Author** | Zilvinas Marozas |
| **Date** | 9 Jun 2026 |
| **Event** | SpaceX IPO — Fri 12 Jun 2026 |
| **Requested by** | Zahid Islam |
| **Status** | Draft — pending desk order estimate |

---

## TL;DR

- **Memory is not the constraint.** Instance 20 carries a resident working set of ~6.7 GB on a normal day and ~7.2–7.5 GB on the heaviest recent days — roughly **45–47% of its 16 GB heap**. Ample headroom to the ceiling.
- **The real watch item:** Friday will be the **first peak-volume day on the new JDK 17 / G1 stack** we cut over to at the start of this week. It has only run on light days so far.
- A genuinely heavy day will likely push the heap **across G1's marking threshold (~7.4 GB) for the first time in prod**, triggering background (concurrent + mixed) collection behaviour we have not yet observed. Expected, not dangerous — but unproven under load.
- **Recommendation:** pre-emptively raise `-Xmx` from 16 GB to **24–32 GB** (the box has 188 GB), monitor live Friday, and ideally rehearse a heavy day's volume against the new build in dev this week.
- **Open input:** the desk's day-one order estimate for the SpaceX symbol on instance 20, needed to size the heap bump precisely.

---

## 1. Scope

Confirm that **instance 20** has enough capacity to absorb Friday's SpaceX IPO.

Instance 20 (shard 20) is the OMS shard configured with `symbolFilter = "S*"`, so it owns **every ticker beginning with "S"** — the SpaceX listing will route here. Note this shard already carries the full baseline load of all other S-names (SHOP, SNAP, SBUX, SQ, SLB, SCHW, …); the IPO lands *on top* of that.

## 2. Environment & topology

| Item | Value |
|---|---|
| Site | Specialized Trading EQ Zone, Barclays Cranford DC (`xce` / `amer` / `eqt` / prod) |
| Primary host | `xcelxeqt22p` |
| Backup / DR | `xcelxeqt23p` / `xpelxeqt20p` |
| Install dir | `/home/sysusetprd/bblt/shard_20` |
| Heap (`-Xmx`) | **16 GB** (min = initial = max) |
| Box | 72 cores, 188 GB RAM (also hosts shards 13 / 16b / 24b / 28) |

## 3. Method

1. **GC logs** — live `gc.log` for today's session (new stack) plus the heaviest archived `blackbird-gc.log` days (old stack), extracted on dev. Heavy days identified by ranking the GC log line count inside each daily tarball.
2. **Order / message volume** — Kibana Discover, filtered `PublishingSystemInstanceID:BBEMSLTNYKPRD20`, last five trading days.

## 4. Key finding — platform migration this week

The servers were upgraded **at the start of this week**:

| | Until ~8 Jun | From ~9 Jun (today) |
|---|---|---|
| JDK | 8u471 | 17.0.17 |
| Collector | Parallel (`+UseParallelGC` / `+UseParallelOldGC`) | G1 |
| Heap | 16 GB | 16 GB |

**Consequence:** every archived day is the *old* stack and is not a behavioural proxy for Friday. The only data on the *new* stack is today — a relatively light day. The archives remain valid for one thing: the **resident working-set size**, which is independent of collector/JDK.

## 5. GC behaviour

### 5.1 Today — JDK 17 / G1 (9 Jun)

- 52 collections, **all young pauses**; **zero concurrent cycles, zero mixed GCs, zero evacuation failures**.
- Only Full GCs = two pre-open `System.gc()` compactions during start-of-day warm-up (4.2 GB → ~1.7 GB, ~750–780 ms). Benign, before market open.
- Heap-after floor rose nearly linearly from ~4.0 GB at the open to **~6.25 GB by 15:10** (~390 MB/hour of net growth); projects to ~6.5 GB at the close.
- Young pauses **70–80 ms**; allocation rate ~4–5 MB/s.
- Old gen never reached the G1 marking threshold (~45% ≈ 7.4 GB) — which is why no background collection ran.

### 5.2 Archived heavy days — JDK 8 / Parallel

GC-log line counts are tightly clustered across the month (190–213/day), confirming uniform GC load. Heaviest sessions: **21 May (213)** and **19 May (201)**. *(Tarballs are named for the morning they were cut, i.e. trading date + 1.)*

| Day (session) | Old gen at EOD | % of old gen | Young pause range |
|---|---|---|---|
| 19 May (heaviest) | ~7.2–7.5 GB | ~55% | 220–350 ms |
| 8 Jun (normal) | ~7.0 GB | ~51% | 160–380 ms |

No allocation-failure Full GCs or evacuation failures under load — only benign metaspace-threshold Full GCs at start-of-day. (Under Parallel, "Allocation Failure" is the *normal* young-GC trigger, not a fault.)

> Side note: the migration is already a latency win — Parallel ran 160–380 ms young pauses; G1 is at 70–80 ms.

## 6. Volume (Kibana, instance 20, last 5 trading days)

| Date | Messages |
|---|---|
| 3 Jun | 7.60 M |
| 4 Jun | **8.11 M** (week high) |
| 5 Jun | 7.59 M |
| 8 Jun | 7.70 M |
| 9 Jun (partial) | 6.70 M → ~7 M projected |

Stable band of **~7.5–8.1 M messages/day**, no outliers.

> **Caveat:** total message count is *not* the memory driver. The heap floor tracks **resident order state** (orders that stay live through the session), not transient market-data / quote / cancel traffic. The better proxy for memory growth is **new-order count** (`OrderEventMessage` / new `OrdStatus`, or distinct `OrderID`s).

## 7. Capacity projection

Resident working set decomposes roughly as:

```
EOD floor  ≈  1.7 GB fixed (reference data)  +  ~5 GB order state (at ~8M-msg volume)
```

Scaling the order-state term by **M** = (instance-20 order inflow on IPO day ÷ normal):

| M (order uplift) | Projected EOD floor | Behaviour |
|---|---|---|
| 1.0 (normal) | ~6.7 GB | as today — young GC only |
| ~1.15 (+15%) | ~7.4 GB | crosses marking threshold; background GC begins |
| 1.5 | ~9.2 GB | mixed GC active; still well under ceiling |
| 2.0 | ~11.7 GB | comfortable but elevated |
| ~2.85 | ~16 GB | approaches the ceiling — unacceptable |

> First-order linear model. If the accumulated old-gen is largely *terminal* (filled/cancelled/rejected) orders, the first mixed-GC cycle will reclaim them and flatten the curve; if it is mostly live working state, only more heap helps. Which one holds is an open question (resolvable by forcing a `System.gc()` on the **DR** instance mid-session and measuring how far it compacts).

## 8. Risk assessment

- **Memory exhaustion:** low. 16 GB comfortably holds the ~7.5 GB peak seen on the busiest recent days.
- **New stack under first peak load:** elevated/unknown. Friday is the JDK 17 / G1 stack's first high-volume day in prod (~48 h old, light days only). A heavy day will likely engage concurrent + mixed GC for the first time, shifting the pause profile in ways not yet observed.
- **Unknown input:** SpaceX incremental order volume on instance 20 — sets M, and therefore how close Friday runs to the thresholds above.

## 9. Recommendations

1. **Raise `-Xmx` to 24–32 GB** (188 GB box; subject to co-resident shard reservations). Pushes both the marking threshold and the ceiling out, keeping the first peak day clear.
2. **Rehearse in dev** — replay a heavy archived day's volume against the JDK 17 / G1 build this week to observe G1 under load before Friday.
3. **Confirm the JDK 17 G1 flags are deliberate** (e.g. a `MaxGCPauseMillis` goal) rather than bare defaults.
4. **Monitor live Friday** — `gc.log`, plus runtime observation if available.
5. **Obtain the desk's day-one SpaceX order estimate** for instance 20 to finalise the `-Xmx` sizing.

## 10. Open items

- [ ] Desk estimate of day-one SpaceX order volume on instance 20.
- [ ] Decision on `-Xmx` bump (and change record).
- [ ] Optional dev load-replay against JDK 17 / G1.
- [ ] Confirm JDK 17 GC flag set.

---

## Appendix — supporting data

**Today's G1 config (`gc.log` header):**

```
Using G1
Version: 17.0.17+8-LTS-360
CPUs: 72 total, 72 available
Memory: 188G
Heap Region Size: 8M
Heap Min/Initial/Max Capacity: 16G / 16G / 16G
```

**Old-stack command line (`blackbird-gc.log` header):**

```
JRE 1.8.0_471-b26
-XX:+UseParallelGC -XX:+UseParallelOldGC
-XX:InitialHeapSize=17179869184 -XX:MaxHeapSize=17179869184   (= 16 GiB)
-XX:NewSize=3221225472 -XX:MaxNewSize=3221225472             (= 3 GiB young)
```

**GC-log line-count ranking (heaviest archived days):**

```
196 trading.log.20260519-...   (18 May session)
201 trading.log.20260520-...   (19 May session)
213 trading.log.20260522-...   (21 May session)  <- heaviest
```
