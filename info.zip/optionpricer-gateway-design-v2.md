# OptionPricer Gateway — Design (v2)

**Ticket:** BLACKBIRD-54916 · **MR:** !20858 (`feature/BLACKBIRD-54916-pr3 → release/2.348`) · **Status:** In review

_A stateless bridge between Blackbird Trading and BiFrost for option theoreticals and Greeks._

**Model:** `BB Trading <--> optionpricer ROE <--> bridge app <--> BiFrost protos over Solace <--> BiFrost`

> **Reconciliation note (read first).** This revision is written to the **current code on the work PC**. The personal-copy zip used to cross-check it is roughly one iteration behind; where they differ, this doc follows the work PC. Verify these specific points when you diff:
> - **ESMP replaces RIC.** The ROE model migrated (MR !5755): `OptionProductData` carries `ESMP` (product identity) and `UnderlyingName` (routing). The request handler reads `getESMP()` / `getUnderlyingName()` directly; the zip still shows `getRIC()` and a `deriveUnderlyingName()` strip-suffix helper.
> - **`EnvironmentPrefixTranslator`** is the current name (generic `encode` / `decode` / `isValid`); the zip still calls it `ProductIdCodec` and uses try/catch instead of an `isValid` guard.
> - **Config is flattened.** Keys sit directly under `optionPricerGateway.solace.*`; the zip still nests them under `optionPricerGateway.bifrost.solace.*`. The `BifrostAdapter.Solace.*` path constants drop the `.bifrost.` segment to match.
> - **Inbound handler signatures carry `UnderlyingName`.** The listener extracts it from the topic; `PricingResponseHandler.handle(underlyingName, response)` and `RiskProfileUpdateHandler.handle(underlyingName, productId, rp)`. The zip omits `underlyingName`.
> - **`logback.xml`** has the `logback-error-monitoring` include removed and class-level loggers for `OptionPricerGatewayApp` and `BifrostInboundListener` (the zip still has the package-level logger + a TODO).
> - **Package placement:** the zip puts `ConfigurationConstants` in `module/` and `ShutdownMessageHandler` in `server/bifrost/`; your latest project tree showed both directly under `com.barcap.eq.oms`. Use whichever your work PC currently has.

---

## 1. State

**Done.** ROE module (`optionpricer-roe`, MR !5755) merged — model, service, enums, ESMP/UnderlyingName migration. Gateway application built; 32 unit tests green. BiFrost message contract confirmed with Bapu (XML content payload, `auxRiskData.pricingDate` populated on Greeks, basic auth). Config flattened per Erb. `logback.xml` cleaned up per Erb.

**In review.** MR !20858, two approvals required (Zahidul Islam, Erb Cooper, Mark Halliday, GitLab Duo as reviewers). Outstanding review threads: topic-key hybrid (`UnderlyingName` vs `+ESMP`, Mark/Zahid). 

**Blocked / pending.** Solace **password** for basic auth (open question to Bapu — see §13). BLACKBIRD-54934 (Solace VPN bridge setup) for UAT. BLACKBIRD-55049 (EventSourcing → Stateless HA lifecycle conversion, fast-follow).

## 2. What the bridge does

A stateless, on-demand translator. It owns no reference data and holds no persistent state. Blackbird Trading passes everything required in the request; the bridge translates between the Blackbird ROE language and the BiFrost protobuf language and relays in both directions. Blackbird never sees a protobuf; BiFrost never sees an ROE.

It speaks two languages and is the only component that speaks both:

- **ROE side** (`optionpricer-roe`): the contract between Blackbird Trading and the bridge. Carried on the Blackbird VPN via the Neeve/Apex bus.
- **BiFrost side** (their protobuf via Nexus): dictated by EQ Risk; the bridge conforms to it over a separate raw JCSMP Solace session.

Statelessness comes from the **`ProductId`**: the bridge encodes the option's `ESMP` (with an environment prefix) into the `ProductId` it sends BiFrost; BiFrost echoes it back opaquely on responses and Greeks, so the bridge routes every update with no correlation registry.

## 3. End-to-end flow

Request-driven and on-demand. No interest list / start-of-day bulk subscription in scope.

1. Blackbird Trading sends an `OptionPricingSubscriptionRequestMessage` (ROE) on the Blackbird VPN. The inlined `OptionProductData` carries `ESMP`, `UnderlyingName`, strike, expiry, PutOrCall, ExerciseType, SettlementCode.
2. `SubscriptionRequestHandler` receives it via a Neeve `@EventHandler`. **Primary-only**: if the engine is not primary it drops the message. Otherwise it delegates to `PricingRequestHandler`.
3. `PricingRequestHandler` generates an environment-prefixed `CorrelationId`, encodes the `ESMP` into an environment-prefixed `ProductId`, translates the ROE into a BiFrost `PricingRequest` (protobuf), and publishes it via raw JCSMP to `Pricing/REQUEST/{UnderlyingName}/{CorrelationId}`.
4. The Solace VPN bridge (BLACKBIRD-54934) delivers the request to the BiFrost VPN. Per-environment VPN isolation plus the prefix on `CorrelationId`/`ProductId` keep environments from leaking into each other.
5. BiFrost prices the option, returns a `PricingResponse` (keyed on the round-trip), then ongoing `RiskProfile` updates every cycle.
6. `BifrostInboundListener` receives each message on the Solace I/O thread, copies the payload, and hands it to the Apex transaction thread (`Scheduler.scheduleOnce(...).immediately()`) so the downstream ROE publish runs inside a transaction.
7. `PricingResponseHandler` / `RiskProfileUpdateHandler` validate the `ProductId` prefix (dropping foreign-environment messages), decode it back to `ESMP`, translate to an `OptionPricingSnapshotMessage` (ROE), and publish back to Blackbird via the Neeve `MessageSender` (engine-managed, so the backup does not double-publish).
8. Blackbird Trading, subscribed, receives the snapshots like a market-data feed.

## 4. Sequence diagram

Paste the source below into a `/plantuml` macro.

```plantuml
@startuml
title OptionPricer Gateway — Subscription Round Trip (current)
autonumber

actor    "Blackbird\nTrading (EMS)"                         as BB
participant "SubscriptionRequestHandler\n(@EventHandler)"    as SRH
participant "PricingRequestHandler"                          as PRH
participant "PricingMessageTranslator\n(pure)"               as TR
participant "PricingRequestPublisher\n(raw JCSMP)"           as PUB
participant "Solace VPN bridge\n(BLACKBIRD-54934)"           as VPN
participant "BiFrost\n(EQ Risk)"                             as BF
participant "BifrostInboundListener\n(Solace I/O -> apex)"   as LIS
participant "PricingResponseHandler /\nRiskProfileUpdateHandler" as RESP
participant "OptionPricingSnapshotPublisher\n(Neeve MessageSender)" as SNAP

== Subscribe ==
BB  -> SRH : OptionPricingSubscriptionRequestMessage (ROE)\ninlines OptionProductData (ESMP, UnderlyingName, ...)
SRH -> SRH : isPrimary()? else drop (debug log)
SRH -> PRH : handle(request)
PRH -> PRH : correlationId = prefix.encode(uniqueId)\nproductId = prefix.encode(ESMP)
PRH -> TR  : toBifrostRequest(req, correlationId, productId, underlyingName)
TR  --> PRH : PricingRequest (protobuf)
PRH -> PUB : publish(request)
PUB -> VPN : PricingRequest\nPricing/REQUEST/{UnderlyingName}/{CorrelationId}
VPN -> BF  : cross-VPN delivery (env-isolated)

== Initial price ==
BF   -> VPN : PricingResponse\nPricing/RESPONSE/{UnderlyingName}/{CorrelationId}
VPN  -> LIS : PricingResponse (protobuf in XML payload)
LIS  -> LIS : copy bytes on I/O thread\nscheduleOnce -> apex thread
LIS  -> RESP : handle(underlyingName, response)
RESP -> RESP : per PricingResult:\nprefix.isValid(productId)? decode -> ESMP
RESP -> TR  : toRoeSnapshot(underlyingName, ESMP, riskProfile, sendingTime)
TR   --> RESP : OptionPricingSnapshotMessage (ROE)
RESP -> SNAP : publish(snapshot)
SNAP -> BB  : OptionPricingSnapshotMessage (engine-managed: primary only)

== Ongoing Greeks ==
loop every pricing cycle
  BF   -> VPN : RiskProfile\nPricing/GREEKS/{UnderlyingName}/{ProductId}
  VPN  -> LIS : RiskProfile (protobuf in XML payload)
  LIS  -> RESP : handle(underlyingName, productId, riskProfile)
  RESP -> RESP : prefix.isValid/decode -> ESMP\nsendingTime = auxRiskData.pricingDate
  RESP -> TR  : toRoeSnapshot(...)
  RESP -> SNAP : publish(snapshot)
  SNAP -> BB  : OptionPricingSnapshotMessage (ROE)
end
@enduml
```

## 5. Directory / component structure

Neeve AEP application. `com.neeve.server.Main` is the JVM entry point; **HK2 `AbstractBinder`** (not Guice) wires the beans; `@EventHandler` methods dispatch inbound ROE. The translator is pure (message in, message out, no I/O) so it unit-tests with no Solace and no infrastructure; both publishers sit behind interfaces so tests capture the would-be-published message.

```
com.barcap.eq.oms
├── OptionPricerGatewayApp          @AppHAPolicy(EventSourcing), ApexServerApplication,
│                                   FirstTransactionTask. main() (IDE only), addApplicationModules,
│                                   onFirstTransaction, starts adapter on AepEngineActiveEvent (primary only)
├── ShutdownMessageHandler          @Managed @Singleton extends AdminShutdownMessageHandler;
│                                   beforeShutdown() tears down BifrostAdapter        [pkg: see recon note]
├── ConfigurationConstants          generic @Named config keys (e.g. environment timezone) [pkg: see recon note]
│
├── module/
│   └── BiFrostAdapterModule        HK2 bindings: @Named Solace config strings, publisher
│                                   interface->impl, addActiveDescriptor for the @Managed beans.
│                                   No StaticDataBinder — stateless.
│
├── server/bifrost/
│   ├── BifrostAdapter              JCSMP session lifecycle on the BiFrost VPN; auth dispatcher
│   │                               (basic / kerberos / ssl); holds Solace.* path constants;
│   │                               setup() connects (RetryPolicy) then delegates to publisher + listener
│   ├── BifrostInboundListener      subscribes RESPONSE + GREEKS; onReceive copies bytes on the
│   │                               Solace I/O thread, scheduleOnce -> apex thread; dispatch() routes by topic
│   ├── SubscriptionRequestHandler  @EventHandler handle(OptionPricingSubscriptionRequestMessage);
│   │                               primary-only guard -> PricingRequestHandler
│   ├── PricingRequestHandler       ROE -> PricingRequest; env-prefixes CorrelationId and ProductId(ESMP)
│   ├── PricingResponseHandler      PricingResponse -> per-result snapshot(s); prefix isValid/decode guard
│   ├── RiskProfileUpdateHandler    per-cycle RiskProfile -> snapshot; sendingTime = auxRiskData.pricingDate
│   ├── PricingMessageTranslator    PURE ROE <-> protobuf; enum + BiFrost Date{timestamp,tz} translation
│   ├── EnvironmentPrefixTranslator encode / decode / isValid for {prefix}_{id} (was ProductIdCodec)
│   ├── PricingRequestPublisher     interface (mockable)
│   │   └── PricingRequestPublisherImpl   raw JCSMP publish to Pricing/REQUEST/...
│   └── OptionPricingSnapshotPublisher    interface (mockable)
│
└── service/
    └── OptionPricingSnapshotPublisherImpl  ROE publish via Neeve MessageSender (engine-managed)

Referenced platform/shared: com.barcap.eq.oms.shared.SystemStartTimeService,
com.barcap.eq.oms.util.idgenerator.IdGenerator, com.barcap.eq.oms.util.RetryPolicy.

Config: config/environment.conf (per-env values), config/static.conf (structural), logback.xml.
Smaller than stockloan-gateway: single outbound ROE type, no XML/JDOM, no static-data loading.
```

## 6. Message contract & field mapping

`OptionProductData` (inbound ROE) carries `ESMP` (product identity, required) and `UnderlyingName` (routing, required). `OptionPricingSnapshotMessage` (outbound ROE) carries `ESMP`, `UnderlyingName`, `SendingTime`, plus the inlined `OptionPricingData` Greeks.

The translator is the heart of the app and is pure and fully unit-tested. Both directions:

- **Inbound** `OptionProductData` (ROE) → `ProductData` (proto): strike, expiry, PutOrCall→OptionType, ExerciseType→OptionStyle, SettlementCode→SettlementType, UnderlyingName→UnderlyingName; the generated env-prefixed `ProductId` (encoding `ESMP`) → `ProductData.ProductId`.
- **Outbound** `RiskProfile` (proto) → `OptionPricingData` (ROE): use the **plain headline Greeks** — `firstOrderGreeks` (Delta, Vega, Theta, CashRho, BorrowRho, DivRho), `secondOrderGreeks.gamma`, and `RiskProfile.tv` for TheoValue. Avoid the Vol/Dyn/User and dollar/variance variants. (Confirmed via the decompiled getters.)
- **Date** is BiFrost's `{timestamp, tz}` object, not a scalar; the translator builds it from the ROE timestamp + the configured `timezone`.

## 7. Solace topics & VPN

```
Publish (BB -> BiFrost):
  Pricing/REQUEST/{UnderlyingName}/{CorrelationId}     PricingRequest

Subscribe (BiFrost -> BB):
  Pricing/RESPONSE/>     -> PricingResponse   (handled by PricingResponseHandler)
  Pricing/GREEKS/>       -> RiskProfile        (handled by RiskProfileUpdateHandler)

VPN (non-PROD):  vpn=flowvol_nyk_uat  host=flowvol-nyk-uat-sol  username=flowvol_nyk_uat
VPN (PROD):      vpn=flowvol_nyk_prd  host=flowvol-nyk-prd-sol  username=flowvol_nyk_prd
```

The app subscribes with broad `>` wildcards; **per-environment isolation is enforced by the Solace VPN bridge plus the environment prefix** on `CorrelationId`/`ProductId`. The decode guard (`isValid`) drops any message whose `ProductId` prefix is not this environment's, as defence in depth.

> **Topic-key thread (open):** the snapshot/topic key on the ROE service side is keyed on `UnderlyingName`; a hybrid `…/{UnderlyingName}/{ESMP}` was proposed (mirrors BiFrost's `GREEKS/{UnderlyingName}/{ProductId}`) to remove same-underlying collisions. Pending Mark/Zahid — do not change the service.xml key until settled.

## 8. Configuration

**`environment.conf`** (per-environment values — DEV shown; PROD swaps the VPN row):

```hocon
environment { name = DEV   region = AMER   location = NYK }

optionPricerGateway {
    environmentPrefix = "bb_dev"
    timezone          = "America/New_York"
    solace {
        authType = "basic"
        host     = "flowvol-nyk-uat-sol"
        vpn      = "flowvol_nyk_uat"
        username = "flowvol_nyk_uat"
    }
}

shard { 1 { primary.host = host } }
```

**`static.conf`** (structural / shared): `apex` engine settings — `instance = ${?shard}`, `ha.role`, `transactionlog.path = "data/optionpricer-gateway/rdat"` (required by EventSourcing), the Apex bus, and the BiFrost topic patterns:

```hocon
optionPricerGateway.solace.topics {
    requestPattern       = "Pricing/REQUEST/{UnderlyingName}/{CorrelationId}"
    responseSubscription = "Pricing/RESPONSE/>"
    greeksSubscription   = "Pricing/GREEKS/>"
}
```

> **Watch-out — timezone key casing.** This app's conf uses `environment.timezone` (lowercase `z`) in one path and `environment.timeZone` (capital `Z`) in another; the module binds one and `ConfigurationConstants` reads the other. HOCON keys are case-sensitive — a mismatch silently misses. Reconcile to one before deploy. Confirm the `@Named("...timezone")` binding for `PricingMessageTranslator` matches.

## 9. HA & primary/backup behaviour

Current `@AppHAPolicy` is **EventSourcing** (the template policy). The genuinely-correct stateless model is the **BLACKBIRD-55049** fast-follow; this MR stays scoped.

Duplicate-send safety is handled on three fronts, so the backup never emits twice:

1. **Adapter start is primary-only.** `startBifrostAdapter()` returns early on backup/DR, so the backup has no BiFrost Solace session at all.
2. **Inbound request is primary-guarded.** `SubscriptionRequestHandler` drops the message unless `isPrimary()`. `PricingRequestHandler` (the BiFrost publish) is only reachable through it.
3. **Snapshot publish is engine-managed.** `OptionPricingSnapshotPublisherImpl` sends via the Neeve `MessageSender`, which suppresses backup outbound automatically.

> Confirm `PricingRequestHandler.handle` is a plain delegate, **not** also an `@EventHandler` for the same message — otherwise the engine would invoke it unguarded.

On failover, `AepEngineActiveEvent` fires on the new primary and starts its adapter.

## 10. Deployment strategy

**Runtime shape.** Neeve AEP app launched by `com.neeve.server.Main`, one shard (`shard=1`), EventSourcing HA with a transaction log under `data/optionpricer-gateway/rdat`, primary + backup members. JMX on `jmxPort = 8141`. Deploy artifacts: the `shell/` launch scripts (`start`, `restart`, `java8/start`, `tlt.sh`).

**Two independent connections.** (a) the Apex/Neeve bus on the **Blackbird VPN** for ROE in/out; (b) a separate raw JCSMP **BiFrost** Solace session (`BifrostAdapter`) to `flowvol_nyk_uat` (non-prod) / `flowvol_nyk_prd` (prod), **basic auth**. The BiFrost session exists only on the primary.

**Environment isolation.** Each environment uses its own `environmentPrefix` (`bb_dev_`, `bb_qa_`, …), applied to both `CorrelationId` and `ProductId`. All non-prod Blackbird environments share one BiFrost UAT VPN; the per-environment Solace VPN bridges (BLACKBIRD-54934) plus the prefix keep traffic from crossing. The CR subscription prefix strings **must byte-match** the gateway's emitted prefix or routing silently fails.

**Promotion path.** non-prod (DEV/QA/SIT/UATF) on the UAT VPN → pilot prod → prod, using the BLACKBIRD-54934 bridge setup and the CR template for prod cutover. PROD `environment.conf` swaps to the `flowvol_nyk_prd` row.

## 11. Testing strategy — how to proceed now

**Stage 0 — Unit (done).** Pure translator, handlers, codec, listener dispatch — 32 tests green, no infrastructure. Keep these as the regression net through the changes below.

**Stage 1 — Single-instance smoke test (next).** One primary, `shard=1`, pointed at BiFrost UAT. Gating prerequisites:
- **Solace password** for basic auth wired (currently the basic path sends an empty password — see §13). **This is the hard blocker** — without it `bifrostAdapter.setup()` fails, the catch calls `setAsLastTransaction`, and the app exits.
- **`AepEngineActiveEvent` confirmed to fire on initial primary startup** (not just failover). If not, add a guarded `startBifrostAdapter()` call in `onFirstTransaction()`. Otherwise the app boots but never connects — a silent no-op.
- BiFrost UAT VPN reachable and the BLACKBIRD-54934 bridge in place for this environment.

  Verify: app boots → "BiFrost solace session established" → "inbound listener started, subscriptions: […]" → send one subscription request → see `PricingRequest` published → BiFrost responds → snapshot published back to Blackbird. This exercises the happy path but **not** HA.

**Stage 2 — HA test.** Primary + backup. Confirm the backup does not double-publish (guards + `MessageSender`), and that failover starts the adapter on the new primary. This is where the §9 items actually get exercised — they will not show up in Stage 1.

**Stage 3 — End-to-end UAT.** Full round-trip against BiFrost UAT with Trading once 54934 is fully up; validate Greeks values field-by-field against an independent source.

**Stage 4 — Pilot prod** after the compliance gate (prod CR).

## 12. Open items / blockers

1. **Solace password (BLOCKER).** `createBasicProperties()` currently sets `PASSWORD = ""`. Open question to Bapu: confirm basic auth, how the password is supplied (vault / credential file / shared secret), and whether transport is TLS (which needs a trust store, distinct from the SSL keystore the cert path uses).
2. **`AepEngineActiveEvent` on initial startup** — confirm with platform/Erb, or add the `onFirstTransaction()` fallback. (TODO in `OptionPricerGatewayApp`.)
3. **Timezone key casing** — reconcile `environment.timezone` vs `environment.timeZone` (§8 watch-out).
4. **Topic-key hybrid** (`UnderlyingName` vs `+ESMP`) — pending Mark/Zahid; do not touch `service.xml` until settled.
5. **`ShutdownMessageHandler` TODO** — `beforeShutdown()` teardown moves to a `LastTransactionTask` once Apex shutdown is used; tracked with the §13 lifecycle work.
6. **BLACKBIRD-55049** — EventSourcing → Stateless HA conversion (fast-follow, separate MR).
7. **BLACKBIRD-54934** — Solace VPN bridge readiness for UAT.
8. **MR !20858** — two approvals; resolve the open review threads.

## 13. Related tickets

- **BLACKBIRD-54934** — Solace queue / VPN bridge setup (infra dependency for UAT).
- **BLACKBIRD-55049** — EventSourcing → Stateless HA lifecycle conversion (fast-follow).
- **BLACKBIRD-55029** — Flex / non-RIC symbology (the rationale for the ESMP / UnderlyingName move).
- **BLACKBIRD-54921** — Greeks consumed by Blackbird (downstream).
- **MR !5755** — `optionpricer-roe` model/service (merged).
