# Shard 20 — Off-Heap / RSS Footprint Check (pre `-Xmx` bump)

> **Paste into Confluence via the Markdown macro.** Companion to the GC capacity analysis.

## Why

The GC analysis confirmed the **heap** working set is ~7 GB of 16 GB. But heap is only part of the process. Per Greg's caveat, the real ceiling is **total process memory** = heap **+ off-heap** (Neeve, Chronicle/WASP binary logger, direct byte buffers), and off-heap reads as "free" in heap tools while it isn't. Before bumping `-Xmx` 16 → 24 GB we must confirm the **RSS** (Resident Set Size — actual physical RAM used) of each shard and the box's true free memory.

**Key fact:** `-XX:+AlwaysPreTouch` is set, so the 16 GB heap is fully resident from startup. A bump to 24 GB therefore adds the **full +8 GB to RSS immediately** at restart — not gradually.

## Prereqs

- Host: `xcelxeqt22p` (shard 20 primary). Box also hosts shards 13 / 16b / 24b / 28.
- Re-grep the shard 20 PID first (it may have restarted): `ps -ef | grep shard_20 | grep -v grep`.
- Permissions: `free`, `ps`, `vmstat`, `/proc/*/status` run as `sysusetro`. `pmap` detail, `lsof`, and `jcmd` need `sysusetprd` or root.

---

## Step 1 — Box memory + all shards' real footprint

```
free -g
ps -eo pid,rss,args --sort=-rss | grep -i shard | grep -v grep
```

- `free -g` → total / used / **available** RAM and swap. **Any swap usage = thrashing.**
- `ps` → every shard JVM with its **RSS** (KB), biggest first. Sum the RSS column — that, not 5 × 16 GB of heap, is what the box is actually carrying.

## Step 2 — Shard 20: heap vs off-heap

```
ps -o pid,rss,args -p <pid20>
```

- RSS − 16 GB (the pre-touched heap) ≈ off-heap overhead (Neeve + Chronicle/WASP + direct buffers + metaspace + thread stacks + code cache).

## Step 3 — Off-heap breakdown

```
jcmd <pid20> VM.native_memory summary
pmap -x <pid20> | sort -k3 -n | tail
lsof -p <pid20> | grep -Ei 'cq4|chronicle|wasp'
```

- `VM.native_memory` → JVM-managed native breakdown. **NMT was not in the launch flags**, so this will likely report "not enabled." Note for a future restart — **do not restart prod for it before the IPO.**
- `pmap` → biggest mappings. Large anonymous ≈ heap + direct buffers; file-backed ≈ Chronicle mmap (reclaimable page cache).
- `lsof` → confirms the memory-mapped off-heap files.

## Step 4 — Thrashing check

```
vmstat 1 5
grep -E 'VmRSS|VmSwap' /proc/<pid20>/status
```

- `vmstat` → watch `si` / `so` (swap in/out). Nonzero, especially under load, = swapping.
- `VmSwap > 0` → this process is already being paged out.

## Step 5 — Decide

- Is box `available` (from `free`) ≥ **8 GB** + a healthy margin? (the bump commits 8 GB at once)
- Does **Σ RSS (all shards) + 8 GB + OS headroom** stay under MemTotal, with swap at 0?
- **Yes** → 16 → 24 GB is safe.
- **Tight** → smaller bump, or loop in the Neeve / SIR platform team per Greg.

---

## Results (fill in)

| Metric | Value |
|---|---|
| Box MemTotal | |
| Box available | |
| Box swap used | |
| Shard 13 RSS | |
| Shard 16b RSS | |
| Shard 20 RSS | |
| Shard 24b RSS | |
| Shard 28 RSS | |
| **Σ RSS (all shards)** | |
| Shard 20: RSS − 16 GB heap (≈ off-heap) | |
| Swap activity under load (si/so) | |
| **Decision** | 24 GB safe / smaller bump / consult platform |

## Notes

- RSS is ground truth for footprint; the heap number alone understates it.
- mmap'd Chronicle/WASP files count in RSS but are reclaimable page cache, so `NMT + RSS` together separate **pinned** off-heap from **evictable**.
- Direct memory (`-XX:MaxDirectMemorySize`) was not set on the launch line; unset, it defaults to ≈ `-Xmx`, so direct buffers can grow — worth confirming if RSS looks high.
