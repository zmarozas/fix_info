package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;
import com.barclays.eq.roe.optionpricer.OptionPricerFactory;
import com.barcap.eq.integration.common.xplatform.PutOrCall;
import com.barcap.eq.integration.common.xplatform.ExerciseType;
import com.barcap.eq.integration.common.xplatform.SettlementCode;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;
import protobuf.com.barcap.eq.risk.flow.PricingData.ProductData;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.FirstOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.SecondOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionStyle;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.SettlementType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.SecurityType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.Date;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

import static protobuf.com.barcap.eq.risk.flow.ProductData.StrikeType.STRIKE_ABSOLUTE;

/**
 * Pure translator between Blackbird Trading ROE and BiFrost protobuf messages.
 * No I/O, no clock - caller supplies correlationId, productId and timestamps.
 */
@Singleton
public final class PricingMessageTranslator {

    private final String timezone;

    @Inject
    public PricingMessageTranslator(@Named("bifrost.timezone") String timezone) {
        if (timezone == null || timezone.isEmpty()) {
            throw new IllegalArgumentException("timezone must not be null or empty");
        }
        this.timezone = timezone;
    }

    /**
     * SecurityType and StrikeType are hardcoded - bridge only serves vanilla listed equity options.
     */
    public PricingRequest toBifrostRequest(IOptionPricingSubscriptionRequestMessage req,
                                           String correlationId,
                                           String productId,
                                           String underlyingName) {
        ProductData product = ProductData.newBuilder()
                .setProductId(productId)
                .setSecurityType(SecurityType.LISTED_OPTION)
                .setUnderlyingName(underlyingName)
                .setUnderlyingRic(req.getUnderlyingRIC())
                .setStrike(req.getOptionStrikePrice())
                .setStrikeType(STRIKE_ABSOLUTE)
                .setExpiry(toBifrostDate(req.getExpireDateAsTimestamp()))
                .setOptionType(toBifrostOptionType(req.getPutOrCall()))
                .setOptionStyle(toBifrostOptionStyle(req.getExerciseType()))
                .setSettlementType(toBifrostSettlementType(req.getSettlementCode()))
                .build();

        return PricingRequest.newBuilder()
                .setCorrelationId(correlationId)
                .setSendingTime(toBifrostDate(req.getSendingTimeAsTimestamp()))
                .addProducts(product)
                .build();
    }

    public IOptionPricingSnapshotMessage toRoeSnapshot(String ric, RiskProfile rp, long sendingTimeMillis) {
        IOptionPricingSnapshotMessage snap = OptionPricerFactory.createOptionPricingSnapshotMessage();
        snap.setRIC(ric);
        snap.setSendingTimeAsTimestamp(sendingTimeMillis);
        snap.setTheoValue(rp.getTv());

        FirstOrdGreeks g1 = rp.getFirstOrderGreeks();
        snap.setDelta(g1.getDelta());
        snap.setVega(g1.getVega());
        snap.setTheta(g1.getTheta());
        snap.setCashRho(g1.getCashRho());
        snap.setBorrowRho(g1.getBorrowRho());
        snap.setDivRho(g1.getDivRho());

        SecondOrdGreeks g2 = rp.getSecondOrderGreeks();
        snap.setGamma(g2.getGamma());

        return snap;
    }

    private static OptionType toBifrostOptionType(PutOrCall src) {
        switch (src) {
            case Put:  return OptionType.PUT;
            case Call: return OptionType.CALL;
            default:   throw new IllegalArgumentException("Unsupported PutOrCall: " + src);
        }
    }

    private static OptionStyle toBifrostOptionStyle(ExerciseType src) {
        switch (src) {
            case AMERICAN: return OptionStyle.AMERICAN;
            case EUROPEAN: return OptionStyle.EUROPEAN;
            default:       throw new IllegalArgumentException("Unsupported ExerciseType: " + src);
        }
    }

    private static SettlementType toBifrostSettlementType(SettlementCode src) {
        switch (src) {
            case PHYSICAL: return SettlementType.PHYSICAL;
            case CASH:     return SettlementType.CASH;
            default:       throw new IllegalArgumentException("Unsupported SettlementCode: " + src);
        }
    }

    private Date toBifrostDate(long timestampMillis) {
        return Date.newBuilder()
                .setTimestamp(timestampMillis)
                .setTz(timezone)
                .build();
    }
}
