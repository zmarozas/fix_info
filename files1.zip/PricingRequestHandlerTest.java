package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barcap.eq.oms.util.idgenerator.IdGenerator;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;
import protobuf.com.barcap.eq.risk.flow.PricingData.ProductData;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PricingRequestHandlerTest extends BifrostTestSetup {

    private static final String FAKE_CORRELATION_ID = "corr-001";

    @Mock private IdGenerator idGenerator;
    @Mock private PricingRequestPublisher publisher;

    private PricingRequestHandler handler;

    @Before
    public void setUp() {
        when(idGenerator.createUniqueId()).thenReturn(FAKE_CORRELATION_ID);
        handler = new PricingRequestHandler(
                idGenerator,
                new ProductIdCodec(ENV_PREFIX),
                new PricingMessageTranslator(DEFAULT_TZ),
                publisher);
    }

    @Test
    public void testHandlePublishesBifrostRequestWithEncodedProductId() {
        IOptionPricingSubscriptionRequestMessage req = buildRoeRequest("AAPL.O", "AAPL.O");

        handler.handle(req);

        ArgumentCaptor<PricingRequest> captor = ArgumentCaptor.forClass(PricingRequest.class);
        verify(publisher).publish(captor.capture());
        PricingRequest out = captor.getValue();

        assertEquals(FAKE_CORRELATION_ID, out.getCorrelationId());
        assertEquals(1, out.getProductsCount());

        ProductData p = out.getProducts(0);
        assertEquals("bb_dev_AAPL.O", p.getProductId());
        assertEquals("AAPL", p.getUnderlyingName());
        assertEquals("AAPL.O", p.getUnderlyingRic());
    }

    @Test
    public void testHandleEncodesRicIntoProductIdForStatelessRouting() {
        IOptionPricingSubscriptionRequestMessage req = buildRoeRequest("MSFT.OQ", "MSFT.OQ");

        handler.handle(req);

        ArgumentCaptor<PricingRequest> captor = ArgumentCaptor.forClass(PricingRequest.class);
        verify(publisher).publish(captor.capture());
        ProductData p = captor.getValue().getProducts(0);

        assertEquals("bb_dev_MSFT.OQ", p.getProductId());
        assertEquals("MSFT.OQ", new ProductIdCodec(ENV_PREFIX).decode(p.getProductId()));
    }
}
