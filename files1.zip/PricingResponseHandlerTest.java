package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class PricingResponseHandlerTest extends BifrostTestSetup {

    @Mock private OptionPricingSnapshotPublisher publisher;

    private PricingResponseHandler handler;

    @Before
    public void setUp() {
        handler = new PricingResponseHandler(
                new ProductIdCodec(ENV_PREFIX),
                new PricingMessageTranslator(DEFAULT_TZ),
                publisher);
    }

    @Test
    public void testHandlePublishesOneSnapshotPerPricingResult() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O",  7.50, 0.55, 0.03))
                .addPricingResult(buildPricingResult(1, "bb_dev_MSFT.OQ", 12.30, 0.60, 0.04))
                .build();

        handler.handle(response);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher, times(2)).publish(captor.capture());

        List<IOptionPricingSnapshotMessage> snapshots = captor.getAllValues();
        assertEquals("AAPL.O", snapshots.get(0).getRIC());
        assertEquals(7.50, snapshots.get(0).getTheoValue(), EPSILON);
        assertEquals("MSFT.OQ", snapshots.get(1).getRIC());
        assertEquals(12.30, snapshots.get(1).getTheoValue(), EPSILON);
    }

    @Test
    public void testHandleDecodesProductIdToRecoverRic() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O", 7.50, 0.55, 0.03))
                .build();

        handler.handle(response);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher).publish(captor.capture());

        assertEquals("AAPL.O", captor.getValue().getRIC());
    }

    @Test
    public void testHandleSkipsPublishWhenTopLevelErrorPresent() {
        PricingResponse response = PricingResponse.newBuilder()
                .setError("BiFrost: invalid request")
                .setSendingTime(buildDate(SENDING_MILLIS))
                .build();

        handler.handle(response);

        verify(publisher, never()).publish(any());
    }

    @Test
    public void testHandleSkipsPublishWhenResultListEmpty() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .build();

        handler.handle(response);

        verify(publisher, never()).publish(any());
    }

    @Test
    public void testHandleSkipsResultWithPerResultError() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O",  7.50, 0.55, 0.03, "pricing failed", ""))
                .addPricingResult(buildPricingResult(1, "bb_dev_MSFT.OQ", 12.30, 0.60, 0.04))
                .build();

        handler.handle(response);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher, times(1)).publish(captor.capture());

        assertEquals("MSFT.OQ", captor.getValue().getRIC());
    }

    @Test
    public void testHandlePublishesResultWithWarningButNoError() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O", 7.50, 0.55, 0.03, "", "stale market data"))
                .build();

        handler.handle(response);

        verify(publisher, times(1)).publish(any());
    }
}
