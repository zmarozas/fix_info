# Store and Forward — 9:00 PM Trading Session Enhancement

**Status:** Draft requirements for review  
**Source:** Team discussion, spreadsheet screenshots, and Kibana order example, November 12, 2026  
**System:** Blackbird OMS / existing Store and Forward (STF) processing  
**Priority:** High — described in the meeting as blocking other work

> **Important:** This document distinguishes requirements expressed in the meeting from implementation assumptions and unresolved questions. The initial spreadsheet showed **`S4?`**, but a later part of the meeting explicitly confirmed **`S4` as the target session code**. A subsequent clarification confirmed that the rule applies whenever `S4` appears among the values in `LehTradingSession`, including multi-session strings. Other predicate and operational questions remain open.

## 1. Purpose and business context

Extend the existing configurable Store and Forward capability to support an additional group of orders that should become eligible for forwarding at **9:00 PM**. This coincides with a revised evening application restart schedule intended to support trading at 9:00 PM.

The new behavior must not change the forwarding schedule of orders that do **not** match the new trading-session rule.

## 2. Current behavior

Blackbird already supports multiple Store and Forward groups with order-specific criteria and different forwarding times. The meeting's spreadsheet showed the following examples:

| Existing forwarding time (as displayed) | Order group / description |
| --- | --- |
| 1:30 | Existing group — criteria not specified |
| 4:00 | ARC |
| 6:00 | US |
| 7:00 | CAD |

**Note:** AM/PM and timezone were not identified for these existing schedule entries. The existing schedule must be taken from the actual configuration, not inferred from the spreadsheet.

An existing order retains the forwarding time dictated by its own rule even when it arrives outside the new 7:00–9:00 PM window. For example, an order scheduled for the existing 6:00 batch should remain stored for that batch rather than being released at 9:00 PM.

## 3. New functional requirements

### FR-01 — Identify the new eligible order group

- Introduce a new Store and Forward selection rule using the order field **`LehTradingSession`**.
- **Confirmed requirement (subsequent clarification):** an order qualifies whenever `LehTradingSession` contains the session code **`S4` as one of its values**, regardless of its position. Exact-field equality is **not sufficient**.
- The Kibana example demonstrated that the field can contain multiple session codes separated by `|` (for example, `S1|S2`). Qualifying examples include `S4`, `S1|S4`, `S4|S2`, and `S1|S2|S4`.
- Implement session-code membership using the established field delimiter: split, trim if appropriate, then compare complete tokens to `S4`. Do not use an unrestricted substring test such as `contains("S4")` if that would mistakenly accept `S40` or `XS4`. Confirm delimiter/casing conventions in the existing data contract.
- Orders not matching this rule must continue to follow existing Store and Forward rules.

### FR-02 — Store eligible orders before 9:00 PM

- Eligible orders received during the **7:00 PM–9:00 PM** evening interval should be **stored rather than forwarded immediately**.
- The implementation must preserve these orders until the eligible forwarding time, across any applicable restart/replay boundary.
- The meeting did not settle how orders can be ingested or retained while affected applications are down; this is an explicit integration/design question (see §7).

### FR-03 — Forward eligible orders at 9:00 PM

- Eligible stored orders should be forwarded **at or after 9:00 PM**, when the necessary systems are operational.
- The business expectation is that the newly enabled trading flow can trade from **9:00 PM**.
- If the application or destination is not ready at exactly 9:00 PM, forwarding must respect existing operational safety/retry rules. The detailed mechanism is to be confirmed.

### FR-04 — Preserve existing rules for all other orders

- Nonmatching orders must **not** be forwarded at 9:00 PM merely because the system has restarted.
- Existing US, CAD, ARC, and other Store and Forward groups retain their established matching logic, schedules, and next-day holding behavior.
- The discussion specifically referenced regular **GTC/GTT** orders as continuing to be paused/held under their existing logic, rather than being released with the 9:00 PM group.

### FR-05 — Avoid client-specific hard-coding

- The spreadsheet mentioned **Talon** and **BCI Client** as examples of clients involved.
- The discussion clarified that Store and Forward behavior should **not depend solely on whether the order is from Talon or another client**.
- Determine eligibility through the agreed order attributes/rule configuration, not a Talon-only special case.

### FR-06 — Reuse the existing Store and Forward framework

- Prefer extending the current rule matching and multi-schedule capabilities introduced by earlier refactoring.
- Review the original design and current implementation before deciding whether this needs code changes, configuration only, or both.
- Do not introduce an unrelated forwarding path unless the current framework cannot support the new group safely.

## 4. Operational / scheduling requirements

| Operation | Previously described | New target |
| --- | --- | --- |
| Application shutdown | 8:00 PM | **7:00 PM** |
| Application restart | Some applications currently restart around 1:20–1:50 AM (as described verbally) | **All applications needed for evening trading available by 9:00 PM** |
| New STF release time | No dedicated rule for this session | **9:00 PM** |

- These startup/shutdown changes were presented as part of the broader evening trading initiative; **ownership and exact scope are not yet assigned in these notes**.
- Application availability and Store and Forward release are distinct dependencies and must be coordinated.
- **AutoSys** was mentioned speculatively in the discussion; confirm which scheduler and job actually control forwarding and restarts.
- The **transaction cache** was mentioned during the discussion, but whether its schedule/configuration must change was not resolved.

## 5. Attributes shown in spreadsheet

The screenshot listed the following attributes alongside the new 9:00 PM scenario:

| Attribute | Screenshot value | Interpretation / status |
| --- | --- | --- |
| Trading session | Initially `LehTradingSession: S4?`; subsequently discussed as `S4` | **Confirmed token membership:** `S4` may appear in a single- or multi-session value |
| AutoSliceType | `AutoClose` | Shown as contextual information; **not confirmed** as a required STF predicate |
| Clients | Talon; BCI Client | Business examples; **not confirmed** as a fixed client allowlist |
| Stocks | US-listed | Business scope shown; **not confirmed** as a hard eligibility filter |

**Do not hard-code `AutoClose`, client IDs, or US-listed eligibility without explicit confirmation of their role in the matching rule.**

### Kibana evidence and rule-matching clarification (later meeting segment)

The order document displayed in Kibana contained a multi-session field resembling:

```json
{"LehTradingSession": "S1|S2"}
```

The subsequent clarification established that **an order qualifies if `S4` is present anywhere among the field's session values**. Therefore, tokenized membership is required, not optional:

```java
boolean isS4 = lehTradingSession != null
    && Arrays.stream(lehTradingSession.split("\\|"))
             .map(String::trim)
             .anyMatch("S4"::equals);
```

This is illustrative Java only; use the application's established parsing conventions and verify the delimiter in the canonical field definition. Full-token matching excludes `S40` while recognizing `S1|S4` and `S4|S2`.


## 6. Expected scenarios / acceptance criteria

| ID | Scenario | Expected result |
| --- | --- | --- |
| AC-01 | An otherwise eligible new-session order is received between 7:00 PM and 9:00 PM | It is stored and not forwarded before the 9:00 PM release condition is satisfied. |
| AC-02 | 9:00 PM arrives, the required applications/destination are ready, and eligible orders are stored | The eligible stored orders are forwarded using the established STF mechanism. |
| AC-03 | An order received at 8:00 PM matches an existing 6:00 forwarding rule but does not match the new session | It remains assigned to its existing forwarding schedule, not 9:00 PM. |
| AC-04 | An order does not match the new trading-session value | Existing matching, storage, and forwarding behavior is unchanged. |
| AC-05 | Applications restart at 9:00 PM while regular next-day orders are stored | Only orders eligible for the 9:00 PM rule are released; other orders remain held. |
| AC-06 | Two otherwise identical orders come from Talon and BCI, both meeting the confirmed new rule | They receive the same STF treatment unless a separate *existing* business restriction applies. |
| AC-07 | The new session's forwarding destination or required applications are unavailable at release time | Orders are not lost or incorrectly released; recovery/retry follows the agreed existing process (**details to confirm**). |
| AC-08 | A matching order is received after 9:00 PM | **Expected behavior not confirmed** — define whether immediate forwarding or another schedule applies. |
| AC-09 | An order matches both the new trading-session rule and an existing STF rule | **Rule precedence not confirmed** — agree and test the intended winner. |
| AC-10 | Orders are persisted or replayed across the evening shutdown/restart | No missing or duplicate downstream forwarding; exact persistence/replay guarantees must be validated against the existing design. |
| AC-11 | `LehTradingSession` is exactly `S4`, all other established eligibility conditions met | The new 9:00 PM STF rule applies. |
| AC-12 | `LehTradingSession` is `S1|S2` without `S4` | The new 9:00 PM STF rule does not apply; legacy matching is preserved. |
| AC-13 | `LehTradingSession` contains a longer nonmatching code such as `S40` | Do not treat it as `S4`; avoid substring-based false positives. |
| AC-14 | `LehTradingSession` contains multiple values including `S4`, regardless of position | **The new 9:00 PM STF rule applies**, assuming other established eligibility conditions are met. |
| AC-15 | `LehTradingSession` is `S1|S4`, `S4|S2`, or `S1|S2|S4` | All qualify for the new rule. |

## 7. Open questions requiring confirmation

1. **Trading-session representation (technical check only):** Membership of `S4` in a multi-value field is confirmed. Verify the authoritative delimiter, whitespace conventions, and case sensitivity in the schema/implementation.
2. **Rule predicates:** Is the session value alone sufficient, or are `AutoSliceType=AutoClose` and/or US-listed securities also required? Are those only examples?
3. **Rule precedence:** If an order matches S4 and a legacy US/CAD/ARC rule, which schedule takes priority?
4. **After 9:00 PM:** Are newly arriving eligible orders forwarded immediately, stored for another cycle, or managed according to a distinct session-open condition?
5. **7:00–9:00 PM downtime:** Which component receives and durably stores orders while applications are down? Is the shutdown partial, or does upstream buffering handle incoming orders?
6. **Scheduler:** Which AutoSys (or other) jobs control app shutdown, startup, and STF release? Is the release event time-based, startup-based, or both?
7. **Readiness:** What if applications are not fully available by 9:00 PM? What confirms downstream readiness before release?
8. **Time basis:** Which timezone and calendar apply? How are weekends, holidays, DST transitions, and order arrival exactly at 7:00/9:00 PM handled?
9. **Order lifecycle:** Are cancel/replace, expiry, held GTC/GTT orders, and recovery/replay already covered by existing STF semantics, or does the new group need explicit handling?
10. **Operational ownership:** Who implements/validates the restart timing, Store and Forward configuration, transaction-cache dependencies, and production rollout?

## 8. Suggested implementation and validation approach

1. Review the existing Store and Forward design, rule ordering, schedule configuration, persistence, and replay/startup behavior.
2. Implement the confirmed `S4` **token-membership** selection for `LehTradingSession` (including multi-session strings) and confirm whether any additional eligibility predicates are mandatory.
3. Add the new 9:00 PM rule using existing STF extension points; preserve all other rules.
4. Coordinate the 7:00 PM shutdown / by-9:00 PM startup dependency with application operations and scheduling owners.
5. Add targeted tests for eligibility, nonmatching legacy orders, overlapping rules, boundary times, restart/replay, and failure/retry.
6. Validate in a nonproduction environment with representative Talon and BCI orders and ordinary US/CAD/GTC/GTT orders.
7. Document the production configuration, monitoring, rollback path, and a runbook for stuck or delayed stored orders.

## 9. Priority and delivery context

- The meeting called the new **Store and Forward change a current blocker** and requested that it be prioritized.
- **Lookup** was described as less urgent for that day, with an indicated requirement to be in production **before December 6**. This date was discussed for Lookup, **not established as the release date for the 9:00 PM Store and Forward enhancement**.

---

**Ready-for-development condition:** The target session code `S4` and its membership-based matching are confirmed, but rule precedence, any additional eligibility predicates, 7:00–9:00 PM ingestion during shutdown, and behavior after 9:00 PM still need agreement. Until then, the above remains a draft reflecting the meeting rather than an approved implementation specification.
