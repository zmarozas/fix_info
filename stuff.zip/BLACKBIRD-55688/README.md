# BLACKBIRD-55688 - optionpricer-gateway SSL (consolidated changes)

Combines Erb's review (defaults at ${user.home}/.cert/${user.name}.*, one name per setting)
and Greg's em precedent (defaults computed in code, optional config override).
No truststore lookup: SSL_VALIDATE_CERTIFICATE=false, so it isn't needed.

## Files
1. BifrostAdapter-changes.java   - Java edits (constants, createSSLProperties, new sslFile method)
2. static.conf-changes.conf      - bus block (unchanged, reference) + new optionPricerGateway block
3. environment-NYK_SIT-BBOPT.conf - SIT env block after change (auth.ssl removed)
4. retest-commands.txt           - SIT retest + pilot pre-flight
5. mr-replies.txt                - replies to Erb and Greg + commit message

## Apply order
1. Java edits in BifrostAdapter (file 1).
2. static.conf: replace optionPricerGateway block (file 2). Bus block stays as is.
3. Config repo NYK_SIT BBOPT: remove auth.ssl block (file 3). Also on the box if hand-edited.
4. Build, deploy, restart on xcrlxeqt81t (primary).
5. Retest (file 4). Expect keystore log line + "session established".
6. Reply on MR !21416 (file 5).

## Environment summary
| Env            | Change |
|----------------|--------|
| NYK_SIT BBOPT  | Remove auth.ssl block; defaults = /local/1/home/syseqnps/.cert/syseqnps.jks/.passphrase (confirmed present) |
| NYK_QA BBOPT   | None - runs basic, SSL path not executed |
| NYK_PILOT BBOPT| None, IF /local/1/home/sysbbprd/.cert/sysbbprd.jks and .passphrase exist on 33p/32p (UNCONFIRMED) |

## Checks before commit
- Ctrl+click `Config` (applicationConfig field type): confirm com.typesafe.config.Config (hasPath). Likely, not verified.
- Paths is already imported (used by readPassword).
- Run module unit tests (any SSL-path test that expected ConfigException on missing keys will now get defaults).

## Confirmed vs inference
- Confirmed (SIT logs): Apex bus on client-cert SSL; JCSMP session established with tcps:// prefix,
  default port 55443; inbound consumer started on SOLQIN.BB.OPG.OPT.1.AMM; env-set
  optionPricerGateway.solace.auth.ssl.keyStore is read directly (no static.conf line needed).
- Inference: pilot solace.server is a bare hostname; pilot SSL port 55443; sysbbprd home = /local/1/home/sysbbprd.
- Not yet proven: full round trip (BiFrost responses/greeks back) in SIT.
