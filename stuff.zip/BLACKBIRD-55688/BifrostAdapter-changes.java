// =====================================================================
// BifrostAdapter.java - BLACKBIRD-55688 changes
// Path: option/optionpricer-gateway/src/main/java/com/barcap/eq/oms/server/bifrost/BifrostAdapter.java
// =====================================================================

// ---------------------------------------------------------------------
// (A) Solace class: UNCHANGED. Make sure SSL_HOST is removed.
//     SSL_KEY_STORE / SSL_KEY_STORE_PASSWORD_FILE stay (now optional overrides):
//
//     public static final String SSL_KEY_STORE               = "optionPricerGateway.solace.auth.ssl.keyStore";
//     public static final String SSL_KEY_STORE_PASSWORD_FILE = "optionPricerGateway.solace.auth.ssl.keyStorePasswordFile";
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// (B) ADD with the other private constants (after EMPTY_STRING)
// ---------------------------------------------------------------------
private static final String TCPS_PREFIX = "tcps://";
private static final String CERT_DIR = ".cert";
private static final String KEY_STORE_EXTENSION = ".jks";
private static final String PASSPHRASE_EXTENSION = ".passphrase";

// ---------------------------------------------------------------------
// (C) REPLACE createSSLProperties() entirely
// ---------------------------------------------------------------------
private JCSMPProperties createSSLProperties() {
    logger.debug("Creating Solace properties for Client certificate authentication");

    String keyStore = sslFile(Solace.SSL_KEY_STORE, KEY_STORE_EXTENSION);
    String passwordFile = sslFile(Solace.SSL_KEY_STORE_PASSWORD_FILE, PASSPHRASE_EXTENSION);
    logger.info("BiFrost SSL keystore: {}, password file: {}", keyStore, passwordFile);

    JCSMPProperties properties = new JCSMPProperties();
    properties.setProperty(JCSMPProperties.HOST, TCPS_PREFIX + applicationConfig.getString(Solace.HOST));
    properties.setProperty(JCSMPProperties.VPN_NAME, applicationConfig.getString(Solace.VPN));
    properties.setProperty(JCSMPProperties.USERNAME, applicationConfig.getString(Solace.VPN));
    properties.setProperty(JCSMPProperties.AUTHENTICATION_SCHEME, JCSMPProperties.AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE);
    properties.setProperty(JCSMPProperties.SSL_KEY_STORE, keyStore);
    properties.setProperty(JCSMPProperties.SSL_KEY_STORE_PASSWORD, readPassword(passwordFile));
    properties.setProperty(JCSMPProperties.SSL_KEY_STORE_FORMAT, "JKS");
    properties.setProperty(JCSMPProperties.SSL_CONNECTION_DOWNGRADE_TO, JCSMPProperties.TRANSPORT_PROTOCOL_PLAIN_TEXT);
    properties.setProperty(JCSMPProperties.SSL_VALIDATE_CERTIFICATE, false);
    properties.setProperty(JCSMPProperties.CLIENT_NAME, getClientName());
    return properties;
}

// ---------------------------------------------------------------------
// (D) ADD new method (next to readPassword)
// ---------------------------------------------------------------------
// Default: ${user.home}/.cert/${user.name}<extension>; env config may override via configKey
private String sslFile(String configKey, String extension) {
    if (applicationConfig.hasPath(configKey)) {
        return applicationConfig.getString(configKey);
    }
    return Paths.get(System.getProperty("user.home"), CERT_DIR,
            System.getProperty("user.name") + extension).toString();
}

// ---------------------------------------------------------------------
// Everything else UNCHANGED: constructor, setup(), shutdown(),
// createKerberosProperties(), createBasicProperties(),
// createSolaceConnectionProperties(), getClientName(), getHostname(), readPassword().
// ---------------------------------------------------------------------
