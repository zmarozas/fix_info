#!/usr/bin/env bash
# fixcheck.sh - BLACKBIRD-55756
# Compare a FAILED vs GOOD BB OPT trading start to find where FIX session
# startup diverges. Read-only: never touches the logs; archives are extracted
# to /tmp and removed on exit.
#
# Usage:
#   ./fixcheck.sh [FAILED] [GOOD]
#   FAILED / GOOD = a log directory OR a trading.log.*.tar.gz archive
#
# Defaults (edit if your paths differ):
#   FAILED = ~/ems-opt/shard_1/log/trading/archive/zil   (2.356 run, 2026-10-15 09:34)
#   GOOD   = ~/ems-opt/shard_1/log/trading               (current run)
#
# Examples:
#   ./fixcheck.sh
#   ./fixcheck.sh archive/zil .
#   ./fixcheck.sh archive/trading.log.20261015-093338.tar.gz .
#
# Output is printed and saved to ./fixcheck-<host>-<timestamp>.txt

set -u

FAILED_IN="${1:-$HOME/ems-opt/shard_1/log/trading/archive/zil}"
GOOD_IN="${2:-$HOME/ems-opt/shard_1/log/trading}"
REPORT="$PWD/fixcheck-$(hostname -s)-$(date +%Y%m%d-%H%M%S).txt"
TMPROOT=$(mktemp -d /tmp/fixcheck.XXXXXX) || exit 1
trap 'rm -rf "$TMPROOT"' EXIT

ERR_RE='Exception|Caused by|ERROR|FATAL'
FIX_RE='PoolInitializer|MarketMessagePool|FixEngineModule|XFixEngine|FastpathMessageHandler|[Mm]arket[ _.-]?[Rr][Oo][Ee]|FixSession'

# Normalise a log line for cross-run comparison: drop date/time + thread, mask digits
NORM='function norm(l) { sub(/^[0-9:., -]+\[[^]]*\] */, "", l); gsub(/[0-9]+/, "#", l); return substr(l, 1, 160) }'

LAST_APP=""

hdr() { printf '\n==================== %s ====================\n' "$*"; }

# Directory or .tar.gz -> directory
resolve() {
  local in="$1" d
  if [ -d "$in" ]; then echo "$in"; return 0; fi
  if [ -f "$in" ] && [[ "$in" == *.tar.gz ]]; then
    d="$TMPROOT/$(basename "$in" .tar.gz)"
    mkdir -p "$d" && tar -xzf "$in" -C "$d" && { echo "$d"; return 0; }
  fi
  return 1
}

# Newest file matching a pattern: top level first, then up to 3 levels down
newest() {
  local f
  f=$(find "$1" -maxdepth 1 -type f -name "$2" -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)
  [ -z "$f" ] && f=$(find "$1" -maxdepth 3 -type f -name "$2" -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)
  echo "$f"
}

analyze() {
  local label="$1" dir="$2" app d stamp apex alert uncat f n
  app=$(newest "$dir" 'application-*-trading.log')
  if [ -z "$app" ]; then
    echo "!! $label: no application-*-trading.log under $dir"
    LAST_APP=""
    return 1
  fi
  LAST_APP="$app"
  d=$(dirname "$app")
  stamp=$(basename "$app"); stamp=${stamp#application-}; stamp=${stamp%-trading.log}
  apex="$d/apex-$stamp-trading.log"
  alert="$d/alert-$stamp-trading.log"
  uncat="$d/uncategorized-$stamp-trading.log"

  hdr "$label | 0. files"
  echo "dir:        $d"
  echo "run start:  $stamp"
  ls -l "$app" "$apex" "$alert" "$uncat" "$d"/*.err "$d"/start-*.out 2>/dev/null | awk '{print $5, $6, $7, $8, $9}'

  hdr "$label | 1. version strings (confirm 2.355 vs 2.356)"
  grep -h -o -E '[A-Za-z0-9_./-]*2\.3[0-9]{2}[0-9A-Za-z._-]*' "$app" "$d"/*.out 2>/dev/null \
    | sort | uniq -c | sort -rn | head -15

  hdr "$label | 2. FIX gate: is fastpath.fixSession.config set?"
  grep -n -E 'fixSession\.config|fixSession \{|config="config/fastpath' "$app" | head -10 | cut -c1-220
  if [ -f "$apex" ]; then
    echo "-- apex effective config (lines above should show it under \"fastpath\"):"
    grep -n -B5 '"fixSession"' "$apex" | head -20 | cut -c1-220
  fi

  hdr "$label | 3. session file loaded? (fixSession.properties tracer lines)"
  n=$(grep -c 'fixSession\.properties:' "$app")
  echo "count: $n    (good run = dozens; 0 = session file never loaded)"
  grep -n 'fixSession\.properties:' "$app" | head -3 | cut -c1-220
  echo "-- ListenAddress lines:"
  grep -n 'ListenAddress' "$app" | head -10 | cut -c1-220

  hdr "$label | 4. FIX engine / pool initializers / market ROE"
  for f in "$app" "$uncat"; do
    [ -f "$f" ] || continue
    echo "-- $(basename "$f"): $(grep -c -E "$FIX_RE" "$f") lines; first 30:"
    grep -n -E "$FIX_RE" "$f" | head -30 | cut -c1-250
  done

  hdr "$label | 5. errors"
  for f in "$app" "$uncat" "$alert"; do
    [ -f "$f" ] || continue
    echo "-- $(basename "$f"): $(grep -c -E "$ERR_RE" "$f") lines; first 25:"
    grep -n -E "$ERR_RE" "$f" | head -25 | cut -c1-250
  done
  echo "-- non-empty .err files:"
  for f in "$d"/*.err; do
    [ -s "$f" ] || continue
    echo "## $(basename "$f")"
    head -20 "$f" | cut -c1-250
  done

  hdr "$label | 6. startup milestones / HA role (thread name stripped)"
  sed -E 's/^([0-9:., -]+)\[[^]]*\] */\1/' "$app" \
    | grep -n -i -E 'became (primary|backup)|ha.?role|role *[=:]|\bDR\b|(engine|app|application).*(started|activ|opened|ready)' \
    | head -25 | cut -c1-250
}

row() {
  printf '%-34s %10s %10s\n' "$1" "$(grep -c -E "$2" "$FAILED_APP")" "$(grep -c -E "$2" "$GOOD_APP")"
}

main() {
  local FAILED GOOD first start key ln
  echo "fixcheck.sh | host $(hostname -s) | $(date)"
  FAILED=$(resolve "$FAILED_IN") || { echo "!! FAILED input not found: $FAILED_IN"; exit 1; }
  GOOD=$(resolve "$GOOD_IN")     || { echo "!! GOOD input not found: $GOOD_IN"; exit 1; }
  echo "FAILED input: $FAILED_IN"
  echo "GOOD input:   $GOOD_IN"

  analyze "FAILED" "$FAILED"; FAILED_APP="$LAST_APP"
  analyze "GOOD" "$GOOD";     GOOD_APP="$LAST_APP"
  { [ -n "$FAILED_APP" ] && [ -n "$GOOD_APP" ]; } || exit 1

  hdr "7. divergence: GOOD lines (200 before session load) MISSING from FAILED"
  first=$(grep -n -m1 'fixSession\.properties:' "$GOOD_APP" | cut -d: -f1)
  if [ -z "$first" ]; then
    echo "GOOD log has no session load either - pass a different GOOD log"
  else
    start=$(( first > 200 ? first - 200 : 1 ))
    awk -v s="$start" -v e="$first" "$NORM"'
      FNR == NR { seen[norm($0)] = 1; next }
      FNR >= s && FNR <= e { k = norm($0); if (k in seen) found++; else { miss++; if (miss <= 40) printf "MISSING %6d  %s\n", FNR, substr($0, 1, 200) } }
      END { printf "-- window GOOD lines %d-%d: %d found in FAILED, %d missing (first 40 shown)\n", s, e, found, miss }
    ' "$FAILED_APP" "$GOOD_APP"

    key=$(awk -v s="$start" -v e="$first" "$NORM"'
      FNR == NR { seen[norm($0)] = 1; next }
      FNR >= s && FNR <= e { k = norm($0); if (k in seen) last = k }
      END { print last }
    ' "$FAILED_APP" "$GOOD_APP")
    if [ -n "$key" ]; then
      ln=$(KEY="$key" awk "$NORM"' norm($0) == ENVIRON["KEY"] { print FNR; exit }' "$FAILED_APP")
      if [ -n "$ln" ]; then
        echo
        echo "-- FAILED log after the last common line (line $ln, first occurrence), next 40 lines:"
        sed -n "${ln},$((ln + 40))p" "$FAILED_APP" | cut -c1-250
      fi
    fi
  fi

  hdr "8. summary"
  printf '%-34s %10s %10s\n' "check" "FAILED" "GOOD"
  row "fixSession.properties loaded"   'fixSession\.properties:'
  row "ListenAddress lines"            'ListenAddress'
  row "FIX engine / pool / market ROE" "$FIX_RE"
  row "errors / exceptions"            "$ERR_RE"
  echo
  echo "Report saved: $REPORT"
}

main 2>&1 | tee "$REPORT"
