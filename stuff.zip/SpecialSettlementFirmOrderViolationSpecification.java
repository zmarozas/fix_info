package com.barcap.eq.oms.domain.validation.specifications;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import com.barcap.eq.oms.domain.order.DeskOrder;
import com.barcap.eq.oms.domain.specification.SpecialSettlTypeSpecification;
import com.barcap.eq.oms.domain.specification.routing.region.AmerToEmeaFundingTradeOrderSpecification;
import com.barcap.eq.oms.domain.validation.violations.ConstraintViolationFactory;
import com.barcap.eq.oms.domain.validation.violations.TradingViolation;

/**
 * Validates Special Settlement rules for high-touch firm-order slicing.
 *
 * Business rules:
 * 1. A firm order with non-regular settlement may only be sliced through the
 *    AMER -> EMEA Funding Trade workflow.
 * 2. For an allowed Funding Trade slice, the SettlType on the slice must match
 *    the SettlType on the root order.
 *
 * This specification is intended to be invoked from the relevant high-touch
 * CreateSliceOrderAndRoute validation path.
 */
@Singleton
public class SpecialSettlementFirmOrderViolationSpecification {

    @Inject
    private SpecialSettlTypeSpecification specialSettlTypeSpecification;

    @Inject
    private AmerToEmeaFundingTradeOrderSpecification amerToEmeaFundingTradeOrderSpecification;

    public List<TradingViolation> validate(DeskOrder slice) {
        List<TradingViolation> violations = new ArrayList<>();

        if (!isApplicable(slice)) {
            return violations;
        }

        DeskOrder rootOrder = slice.getRootOrder();

        if (isRegularSettlement(rootOrder)) {
            return violations;
        }

        if (!amerToEmeaFundingTradeOrderSpecification.isSatisfiedBySourceOMS(slice)) {
            violations.add(
                    ConstraintViolationFactory.createSpecialSettlementFirmOrderNonFundingTradeViolation());
            return violations;
        }

        if (!hasMatchingSettlType(rootOrder, slice)) {
            violations.add(
                    ConstraintViolationFactory.createSpecialSettlementSettlTypeMismatchViolation());
        }

        return violations;
    }

    private boolean isApplicable(DeskOrder slice) {
        return slice != null && slice.getRootOrder() != null;
    }

    private boolean isRegularSettlement(DeskOrder rootOrder) {
        return specialSettlTypeSpecification.isRegularSettlType(
                rootOrder.getProduct(),
                rootOrder.getSettlType());
    }

    private boolean hasMatchingSettlType(DeskOrder rootOrder, DeskOrder slice) {
        /*
         * If Batman's slice SettlType is mapped to clientSettlType rather than
         * settlType in DeskOrder, replace slice.getSettlType() below with
         * slice.getClientSettlType().
         */
        return rootOrder.getSettlType() == slice.getSettlType();
    }
}
