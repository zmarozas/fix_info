package com.barcap.eq.oms.domain.validation.specifications;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import com.barcap.eq.oms.domain.order.DeskOrder;
import com.barcap.eq.oms.domain.specification.SpecialSettlTypeSpecification;
import com.barcap.eq.oms.domain.specification.routing.region.AmerToEmeaFundingTradeOrderSpecification;
import com.barcap.eq.oms.domain.validation.violations.ConstraintViolationFactory;
import com.barcap.eq.oms.domain.validation.violations.TradingViolation;

import static com.barcap.eq.integration.common.platform.ViolationType.CannotRoute;

/**
 * Validates Special Settlement firm-order slicing rules in AMER high touch.
 *
 * Business rules:
 * 1. A Special Settlement firm order may only be sliced through the AMER -> EMEA
 *    Funding Trade workflow.
 * 2. For a Funding Trade slice, the SettlType on the slice must match the
 *    SettlType on the root order.
 *
 * This specification is intended to be invoked only from the relevant
 * high-touch slice-and-route validation path.
 */
@Singleton
public class SpecialSettlementFirmOrderViolationSpecification {

    private static final String FUNDING_TRADE_ONLY_MESSAGE =
            "Special Settlement firm orders can only be routed through the Funding Trade workflow";

    private static final String SETTL_TYPE_MISMATCH_MESSAGE =
            "Slice SettlType must match SettlType on the root order";

    @Inject
    private SpecialSettlTypeSpecification specialSettlTypeSpecification;

    @Inject
    private AmerToEmeaFundingTradeOrderSpecification amerToEmeaFundingTradeOrderSpecification;

    public List<TradingViolation> validate(DeskOrder slice) {
        List<TradingViolation> violations = new ArrayList<>();

        if (!isApplicable(slice)) {
            return violations;
        }

        DeskOrder rootOrder = slice.getRootOrder();

        if (!isSpecialSettlement(rootOrder)) {
            return violations;
        }

        if (!amerToEmeaFundingTradeOrderSpecification.isSatisfiedBySourceOMS(slice)) {
            violations.add(createViolation(FUNDING_TRADE_ONLY_MESSAGE));
            return violations;
        }

        if (!hasMatchingSettlType(rootOrder, slice)) {
            violations.add(createViolation(SETTL_TYPE_MISMATCH_MESSAGE));
        }

        return violations;
    }

    /**
     * Keep this predicate narrowly scoped to the firm-order/high-touch order type
     * covered by BLACKBIRD-55628.
     *
     * If the caller already guarantees that scope, this method can simply check
     * rootOrder != null, or be removed altogether.
     */
    private boolean isApplicable(DeskOrder slice) {
        return slice != null && slice.getRootOrder() != null;
    }

    private boolean isSpecialSettlement(DeskOrder rootOrder) {
        return !specialSettlTypeSpecification.isRegularSettlType(
                rootOrder.getProduct(),
                rootOrder.getSettlType());
    }

    private boolean hasMatchingSettlType(DeskOrder rootOrder, DeskOrder slice) {
        return rootOrder.getSettlType() == slice.getSettlType();
    }

    private TradingViolation createViolation(String message) {
        return ConstraintViolationFactory.createViolationDetail(
                message.hashCode(),
                CannotRoute,
                message);
    }
}
