/*
 * BLACKBIRD-55628 additions for ConstraintViolationFactory.
 *
 * Add these methods to the existing ConstraintViolationFactory class.
 *
 * They intentionally use InvalidFieldValue / Blocked / OTHER because these
 * failures represent an invalid settlement/routing combination and must stop
 * the slice operation.
 *
 * Assumes the existing class already has access/imports for:
 *   ViolationType.InvalidFieldValue
 *   ViolationStatus.Blocked
 *   ViolationCause.OTHER
 *   TradingViolation
 */

public static TradingViolation createSpecialSettlementFirmOrderNonFundingTradeViolation() {
    return TradingViolation.builder(InvalidFieldValue, Blocked, OTHER)
            .message("Special Settlement firm orders can only be routed through the Funding Trade workflow")
            .build();
}

public static TradingViolation createSpecialSettlementSettlTypeMismatchViolation() {
    return TradingViolation.builder(InvalidFieldValue, Blocked, OTHER)
            .message("Slice SettlType must match SettlType on the root order")
            .build();
}
