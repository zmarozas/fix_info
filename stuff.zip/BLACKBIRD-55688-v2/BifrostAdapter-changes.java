// =====================================================================
// BifrostAdapter.java - BLACKBIRD-55688 v2 (truststore / broker cert validation)
// Path: option/optionpricer-gateway/src/main/java/com/barcap/eq/oms/server/bifrost/BifrostAdapter.java
// Already committed (02620874): TCPS_PREFIX, CERT_DIR, KEY_STORE_EXTENSION,
// PASSPHRASE_EXTENSION, sslFile(), keystore defaults, USERNAME, tcps host.
// =====================================================================

// ---------------------------------------------------------------------
// (A) Solace class: ADD two override keys
// ---------------------------------------------------------------------
public static final String SSL_TRUST_STORE               = "optionPricerGateway.solace.auth.ssl.trustStore";
public static final String SSL_TRUST_STORE_PASSWORD_FILE = "optionPricerGateway.solace.auth.ssl.trustStorePasswordFile";

// ---------------------------------------------------------------------
// (B) Private constants: ADD
// ---------------------------------------------------------------------
private static final String TRUST_STORE_PREFIX = "TrustStore";

// ---------------------------------------------------------------------
// (C) REPLACE createSSLProperties() entirely (full final version)
// ---------------------------------------------------------------------
private JCSMPProperties createSSLProperties() {
    logger.debug("Creating Solace properties for Client certificate authentication");

    String keyStore = sslFile(Solace.SSL_KEY_STORE, KEY_STORE_EXTENSION);
    String passwordFile = sslFile(Solace.SSL_KEY_STORE_PASSWORD_FILE, PASSPHRASE_EXTENSION);
    String trustStore = trustStoreFile();
    String trustStorePasswordFile = applicationConfig.hasPath(Solace.SSL_TRUST_STORE_PASSWORD_FILE)
            ? applicationConfig.getString(Solace.SSL_TRUST_STORE_PASSWORD_FILE)
            : trustStore.replaceFirst("\\.jks$", PASSPHRASE_EXTENSION);
    logger.info("BiFrost SSL keystore: {}, password file: {}, truststore: {}, truststore password file: {}",
            keyStore, passwordFile, trustStore, trustStorePasswordFile);

    JCSMPProperties properties = new JCSMPProperties();
    properties.setProperty(JCSMPProperties.HOST, TCPS_PREFIX + applicationConfig.getString(Solace.HOST));
    properties.setProperty(JCSMPProperties.VPN_NAME, applicationConfig.getString(Solace.VPN));
    properties.setProperty(JCSMPProperties.USERNAME, applicationConfig.getString(Solace.VPN));
    properties.setProperty(JCSMPProperties.AUTHENTICATION_SCHEME, JCSMPProperties.AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE);
    properties.setProperty(JCSMPProperties.SSL_KEY_STORE, keyStore);
    properties.setProperty(JCSMPProperties.SSL_KEY_STORE_PASSWORD, readPassword(passwordFile));
    properties.setProperty(JCSMPProperties.SSL_KEY_STORE_FORMAT, "JKS");
    properties.setProperty(JCSMPProperties.SSL_CONNECTION_DOWNGRADE_TO, JCSMPProperties.TRANSPORT_PROTOCOL_PLAIN_TEXT);
    properties.setProperty(JCSMPProperties.SSL_VALIDATE_CERTIFICATE, true);
    properties.setProperty(JCSMPProperties.SSL_TRUST_STORE, trustStore);
    properties.setProperty(JCSMPProperties.SSL_TRUST_STORE_PASSWORD, readPassword(trustStorePasswordFile));
    properties.setProperty(JCSMPProperties.SSL_TRUST_STORE_FORMAT, "JKS");
    // If SIT fails with host/cert mismatch: use FQDN host, or disable host validation like Apex
    // (check JCSMPProperties for the host-validation constant - not guessed here).
    properties.setProperty(JCSMPProperties.CLIENT_NAME, getClientName());
    return properties;
}

// ---------------------------------------------------------------------
// (D) ADD new method (next to sslFile)
// ---------------------------------------------------------------------
// Default: the single TrustStore*.jks in ${user.home}/.cert; env config may override
private String trustStoreFile() {
    if (applicationConfig.hasPath(Solace.SSL_TRUST_STORE)) {
        return applicationConfig.getString(Solace.SSL_TRUST_STORE);
    }
    Path certDir = Paths.get(System.getProperty("user.home"), CERT_DIR);
    try (Stream<Path> files = Files.list(certDir)) {
        List<Path> matches = files
                .filter(p -> p.getFileName().toString().startsWith(TRUST_STORE_PREFIX)
                        && p.getFileName().toString().endsWith(KEY_STORE_EXTENSION))
                .collect(Collectors.toList());
        if (matches.size() != 1) {
            throw new IllegalStateException("Expected one " + TRUST_STORE_PREFIX + "*" + KEY_STORE_EXTENSION
                    + " in " + certDir + ", found " + matches + "; set " + Solace.SSL_TRUST_STORE);
        }
        return matches.get(0).toString();
    } catch (IOException e) {
        throw new IllegalStateException("Cannot list " + certDir, e);
    }
}

// ---------------------------------------------------------------------
// (E) Imports - JDK only, likely new:
//     java.nio.file.Path, java.util.List, java.util.stream.Collectors
//     Already imported (used by readPassword): Files, Paths, Stream, IOException
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// (F) Optional nit: readPassword()'s messages say "Keystore password file";
//     now also used for the truststore passphrase. Consider "SSL password file".
// ---------------------------------------------------------------------

// Everything else UNCHANGED.
