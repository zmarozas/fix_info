# BLACKBIRD-55688 - optionpricer-gateway SSL (v2: adds broker cert validation)

## Status
- DONE + committed (02620874): tcps:// host, USERNAME = vpn, keystore/passphrase defaults
  ${user.home}/.cert/${user.name}.jks|.passphrase. Validated in SIT (no env overrides):
  session established, consumer started on SOLQIN.BB.OPG.OPT.1.AMM, live pricing updates flowing.
- NEW (Erb review): validate the broker certificate with a truststore. Until now
  SSL_VALIDATE_CERTIFICATE=false = encrypted but broker identity not verified. Apex's own
  session on the same box validates (SESSION_SSL_VALIDATE_CERTIFICATE=1, trust dir signer_certs).

## Files
1. BifrostAdapter-changes.java  - all Java changes, incl. full final createSSLProperties()
2. static.conf-final.conf       - final optionPricerGateway block (no change since last commit)
3. environment-changes.txt      - none (config PR closed); optional override keys listed
4. retest-commands.txt          - SIT retest (2 commands)
5. messages.txt                 - reply to Erb, Shubham message (pilot), commit message

## Keystore vs truststore (one-liner)
- Keystore   = OUR identity (client cert + key) -> broker knows who we are. Have it.
- Truststore = CAs WE trust -> we verify the broker is the real broker (no MITM). Adding now.

## Defaults after this change
| Setting                  | Default                                              | Override key (optional) |
|--------------------------|------------------------------------------------------|-------------------------|
| keyStore                 | ${user.home}/.cert/${user.name}.jks                  | optionPricerGateway.solace.auth.ssl.keyStore |
| keyStorePasswordFile     | ${user.home}/.cert/${user.name}.passphrase           | optionPricerGateway.solace.auth.ssl.keyStorePasswordFile |
| trustStore               | the single ${user.home}/.cert/TrustStore*.jks        | optionPricerGateway.solace.auth.ssl.trustStore |
| trustStorePasswordFile   | same name as truststore, .passphrase                 | optionPricerGateway.solace.auth.ssl.trustStorePasswordFile |

SIT (confirmed from 80t listing, 9/28): TrustStoreNonProd.jks + TrustStoreNonProd.passphrase.
81t presumed same (unconfirmed - retest will show). Pilot/prod name UNKNOWN - ask Shubham.

## Risk: hostname validation
With validation on, JCSMP may also check the host name against the broker cert.
If SIT connect fails with a host/certificate mismatch, either:
- use the FQDN (append ".barcapint.com", as the em snippet in the MR thread does), or
- turn host validation off like Apex (VALIDATE_CERTIFICATE_HOST=0) - check JCSMPProperties.class
  for the exact constant name (not guessed here).

## Decided / out of scope
- SchedulerImpl "Running Scheduler from non-transaction thread" INFO lines (~1 per pricing update):
  Erb wants it fixed in Apex (demote to debug). Left to Erb; NO logback change in 55688.
- Env config PR closed: no environment.conf changes needed anywhere.

## Apply order
1. Java changes (file 1). Build + module tests.
2. Commit (message in file 5), push.
3. Deploy SIT, restart on xcrlxeqt81t, retest (file 4).
4. Reply to Erb (file 5). Send Shubham message (file 5).
