# Questions for Special Settlement Funding Trade

1. **Current Blackbird behavior blocks `sliceSpecialSettlement()` for Octon orders.**  
   For this requirement, should Special Settlement be enabled only for **Funding Trade Octon orders**, or for **Octon orders generally**?

2. **If this is Funding-Trade-specific, what should Blackbird use to identify an eligible order?**  
   For example, should eligibility be based on the Funding Trade classification, the London funding desk / `LDN-EFS-PIII`, or some other attribute?

3. **Should Special Settlement Funding Trade reuse the existing Special Settlement workflow, or remain a Funding Trade order with settlement attributes added to it?**

4. **Does the whole Funding Trade basket have to use the same settlement instructions, or can individual orders have different settlement instructions?**
