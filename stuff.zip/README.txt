BLACKBIRD-55628 integration notes
=================================

Files in this bundle
--------------------
1. SpecialSettlementFirmOrderViolationSpecification.java
   Full refactored specification.

2. ConstraintViolationFactory_BLACKBIRD_55628_Additions.java
   Add only these two methods to the existing ConstraintViolationFactory.
   Do NOT replace the full factory class with this file.

Important check before committing
---------------------------------
Confirm where Batman's SettlType on CreateSliceOrderAndRoute ends up in DeskOrder.

If it is:
    slice.getSettlType()
leave the code as-is.

If it is:
    slice.getClientSettlType()
change hasMatchingSettlType() to:

    return rootOrder.getSettlType() == slice.getClientSettlType();

Expected validation behavior
----------------------------
- Root regular settlement:
    No new Funding Trade restriction.

- Root non-regular + non-Funding-Trade target:
    BLOCK with:
    "Special Settlement firm orders can only be routed through the Funding Trade workflow"

- Root non-regular + Funding Trade target + matching slice SettlType:
    PASS this specification.

- Root non-regular + Funding Trade target + mismatching slice SettlType:
    BLOCK with:
    "Slice SettlType must match SettlType on the root order"

- Slice SettlType null:
    Existing required-field validation should continue to reject it.
    Do not duplicate that rule here unless the integration contract changes.

Wiring
------
Invoke this specification only from the relevant AMER high-touch
CreateSliceOrderAndRoute validation path, after the slice/root order objects
have been populated sufficiently for:
    - root lookup
    - target desk/Funding Trade identification
    - SettlType comparison
