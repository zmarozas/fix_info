# Self Evaluation 2026 — paste-ready text

Paste the text under each heading. Workday won't render markdown, so the hyphen bullets are plain text; use Workday's bullet button if you prefer.

---

## Box 1 — The What (what has been delivered)

Delivered across high-touch options, desk workflows, overnight orders and new infrastructure, alongside ongoing production support:

- High-touch options client flows (STOMP decommission): implemented core Blackbird Options functionality for single- and multi-leg client orders from FIRST and Batman, including order creation, amend and cancel, external routing and slicing on the Sales desk. This moves HT options client flow off TIGER/STOMP and supports the 2026 decommissioning plan.
- Partial Out for low-touch algo orders: delivered handling for client cancels and amends after the closing-auction cut-off. Only the portion not yet staged for the auction is cancelled, so auction-committed slices stay intact. Released globally.
- Overnight and pre-open orders: go-to owner for overnight order issues and requirements. Designed and delivered country-specific Store & Forward hold-back and late release (CAD, LATAM), config-driven so new countries need no code changes.
- Desk workflows: stopped-order workflow for the HT Sales desk, delivered with the Batman team. Liquid Finance funding-trade workflow between the AMER swap and EMEA funding desks.
- Option pricer gateway: designed and built a new service connecting Blackbird options trading to the firm's options pricing platform, with durable queuing, HA failover, correlation logging and SSL. [Now in pilot / prod — pick one]
- Production support: took hard production defects end to end, from root cause in journal data to reproduction in automated tests to fix. Examples: trade busts on cancelled orders, and investment-decision reporting on amended slices.
- Architecture proposals: authored the Transaction Cache V3 design (tiered Neeve + Hazelcast, targeting 60GB+ down to ~10GB heap with no changes for consuming apps). Also authored an options order-trace toolkit (SQL over already-retained journals ahead of SpiderRock volume growth), demoed to leadership.

---

## Box 2 — Precision (risk and control)

- Risk controls: implemented multi-leg net options pricing for client risk control checks RCO6 and RCO9.
- Regulatory reporting: reproduced and fixed a defect where the investment-decision field on DRV trades was overwritten after an affiliate slice amend, matching a production case raised by trade reporting.
- Trade busts on cancelled orders: identified a control gap that left busted quantity showing as working with no route to market. Reproduced it in automated tests (a previously uncovered scenario) and scoped a state-aware fix.
- Closing auction: Partial Out prevents late client cancels from disturbing orders already committed to the auction.
- Funding trades: correct trade type and clearing details on each leg, so booking reflects the right book and legal entity.
- Store & Forward: replaced a string-encoded workaround with structured, validated forwarding rules. Scheduled reruns are safe against missed or duplicate forwards.
- Security and resilience: flagged and fixed the pricing gateway's Solace authentication default (basic to SSL). Right-sized options shard memory after an out-of-memory outage.

---

## Next page — The How (PROVISIONAL: fields not seen yet)

- Design-first delivery: authored design documents for major work (Store & Forward, OptionPricer Gateway, Transaction Cache V3, order-trace toolkit), so reviewers, QA and support work from one reference. Following mid-year feedback, I now pair detailed designs with a short executive summary for readers outside the team.
- Ownership: first point of contact for overnight order issues. I take production defects from triage through to a tested fix.
- Challenging the status quo: proposed two self-initiated designs to address scaling risks before they become incidents.
- Collaboration: worked across the Batman, pricing (BiFrost), trade reporting, EMEA funding desk and Prague teams.

---

## Verify before pasting (do not paste)

1. Option pricer gateway: pilot or prod today? Fix the bracket in Box 1.
2. Trade-bust fix (BLACKBIRD-55358): merged? If yes, change "scoped a state-aware fix" to "delivered a state-aware fix".
3. Partial Out: confirm BLACKBIRD-54554 / 54555 were assigned to you.
4. Funding trade (BLACKBIRD-55472): assignee was not visible in the screenshot; confirm.
5. Optional, but strong: add counts, e.g. Jiras delivered, incidents supported, design docs authored.
6. The How fields are unseen; adjust once you're on that page.
