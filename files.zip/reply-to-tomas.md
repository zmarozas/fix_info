Hi Tomas,

Thanks for the careful read — your understanding is correct. Short version: yes, EOD conversion of the options RDAT + Bedrock journal archives to Parquet, queried in place; space will be measured on the largest production shard and I expect single-digit GB/day (scope is the Blackbird options journals only — not MSE's firmwide 500GB/day); nothing replaces Kibana/MSE for existing workflows — this is additive for what MSE can't do: options coverage and >7-day retention. Details below.

**Space:** we already keep many months of the zipped RDAT and fastpath journal archives on the Golden Host today — the storage precedent exists and we can evidently afford it. Parquet stores the same data very efficiently (columnar + zstd compression), so the additional files should not be much bigger than the zipped archives, and likely smaller. In other words: if the zip history is affordable, the Parquet copy on top of it is not a material ask.

**"Not 1:1 with Kibana":** correct, and deliberate — no one's workflow changes. Equities, BA state checks, QA/ZTBB/BIMS/LMX all keep using MSE. At the data level nothing is lost: every journal field is carried (search columns + attributes map with all remaining fields + raw message), and non-order messages (Request<>Response etc.) are queryable by message type. What's different initially is presentation: CLI/SQL first, no UI. If the CLI proves value, a lightweight UI is easy to add — DuckDB exposes standard JDBC.

**Your MSE suggestions** (journal feeder, disk-heavy nodes, split indexes) all work technically — but they all grow an always-on cluster: more nodes to buy, patch, and run 24/7. The main problem with MSE isn't capability, it's economics and retention. This proposal consumes only disk on hosts we already run and needs no approvals to try. The two aren't exclusive — even with a future MSE feeder, the Parquet copy remains valuable for year-long retention and SQL analytics a search index can't do.

**Scope:** starting point is Blackbird options (Bedrock journals + RDATs). If it proves out, the same pipeline extends naturally to Blackbird equities — same journal formats, same tooling — but that's a later decision, and it stays within Blackbird either way, not other components.

Zil
