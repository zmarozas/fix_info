package com.barcap.eq.oms.server.bifrost;

import com.solacesystems.jcsmp.BytesXMLMessage;
import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.JCSMPFactory;
import com.solacesystems.jcsmp.JCSMPSession;
import com.solacesystems.jcsmp.JCSMPStreamingPublishEventHandler;
import com.solacesystems.jcsmp.Topic;
import com.solacesystems.jcsmp.XMLMessageProducer;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

/**
 * Outbound publisher: serializes PricingRequest to bytes and sends to BiFrost
 * on a per-message topic templated from requestTopicPattern.
 * Pattern: Pricing/REQUEST/{UnderlyingName}/{CorrelationId}
 */
@Singleton
public class PricingRequestPublisherImpl implements PricingRequestPublisher {

    private static final String UNDERLYING_NAME_PLACEHOLDER = "{UnderlyingName}";
    private static final String CORRELATION_ID_PLACEHOLDER  = "{CorrelationId}";

    private final Logger logger = LoggerFactory.getLogger(PricingRequestPublisherImpl.class);

    @Inject @Named(BifrostAdapter.Solace.REQUEST_TOPIC_PATTERN)
    private String requestTopicPattern;

    private XMLMessageProducer bifrostProducer;

    @Override
    public void setup(JCSMPSession session) throws JCSMPException {
        bifrostProducer = session.getMessageProducer(
                new JCSMPStreamingPublishEventHandler() {
                    @Override
                    public void responseReceived(String messageID) {
                        logger.debug("BiFrost solace producer ack for msg ID #{}", messageID);
                    }
                    @Override
                    public void handleError(String messageID, JCSMPException e, long timestamp) {
                        logger.error("BiFrost solace producer error for msg ID #{}", messageID, e);
                    }
                });

        logger.info("BiFrost solace pricing request publisher started.");
    }

    @Override
    public void publish(PricingRequest request) throws JCSMPException {
        String underlyingName = request.getProducts(0).getUnderlyingName();
        String correlationId  = request.getCorrelationId();

        String topicName = requestTopicPattern
                .replace(UNDERLYING_NAME_PLACEHOLDER, underlyingName)
                .replace(CORRELATION_ID_PLACEHOLDER, correlationId);
        Topic topic = JCSMPFactory.onlyInstance().createTopic(topicName);

        BytesXMLMessage msg = JCSMPFactory.onlyInstance().createMessage(BytesXMLMessage.class);
        msg.writeBytes(request.toByteArray());

        bifrostProducer.send(msg, topic);
    }
}
