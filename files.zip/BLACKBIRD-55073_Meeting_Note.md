## Meeting note (with Arun) — BLACKBIRD-55073

**Scope (this ticket):** Sales Trading ROE only — add `TargetPositionAccount` and `TargetSubBook` for AMER ↔ EMEA horizontal comms. Optional fields, informational/pass-through (no booking impact, no validation, no POG).

**Out of scope:** Position Trading ROE — owned by the Batman team (separate work, since Batman passes the values through to Blackbird).

**Placement (Sales Trading ROE):**
- `ClientRequestedOrderGroup` (7999) — also covers OrderCancelReplace via inline group.
- `OrderNewMessageDetails` (8003) — pending confirm (order-new event leg).
- `TradeMessage` (20) and `TradeCorrectMessage` (26) — direct add.

**Dependency:** EQDS-4979 (EMEA Book & SubBook repo in AMER) needed to populate live values. Schema change can proceed independently.

**Next:** define the two fields in common-model.xml, then add the `<fieldRef>`s; raise PR for review.
