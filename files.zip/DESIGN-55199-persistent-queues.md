# optionpricer-gateway — Design Addendum (v3 draft)
## BLACKBIRD-55199: Persistent queue consumption for BiFrost inbound

**Status:** Proposed. Extends design doc v2 §"Two inbound paths".
**Motivation:** Erb Cooper (MR !20858 / follow-up story): BiFrost consumption should
use queues + guaranteed messaging rather than direct topic subscriptions, so
messages survive gateway restarts/failover instead of being dropped.

### 1. Change summary
Replace the raw JCSMP **direct** consumer (`session.getMessageConsumer` +
`session.addSubscription(Pricing/RESPONSE/>, Pricing/GREEKS/>)`) with a
**FlowReceiver bound to a durable queue** that has the same two topic
subscriptions mapped onto it broker-side. Everything downstream of `onReceive`
(copy topic+bytes, `Scheduler.scheduleOnce(...).immediately()` hop to the apex
thread, dispatch/parse/handlers) is unchanged. Outbound publish unchanged.

Pattern source: stockloan `LocateBroadcastHandlerImpl` (prod) — FlowReceiver,
`ConsumerFlowProperties.setEndpoint(queue)`, `SUPPORTED_MESSAGE_ACK_AUTO`,
`flow.close()` on shutdown. We mirror it exactly.

### 2. Delivery semantics
- Solace promotes direct-published messages to guaranteed when a matching
  durable queue subscription exists, so BiFrost does NOT need to change how it
  publishes. (Verify per-VPN that direct-to-guaranteed promotion is enabled —
  standard, but confirm with Solace team.) Note: this is broker-side
  persistence, not end-to-end guaranteed delivery — the publisher receives no
  acks. Sufficient for the ticket's goal (no message loss across gateway
  restarts/failover).
- Ack mode: AUTO (stockloan precedent). Redelivery-on-crash is therefore
  best-effort; acceptable for pricing data. A CLIENT-ack /
  ack-after-apex-processing variant is a possible later hardening step, noted
  and deliberately not done now.

### 3. Failover interaction (improvement)
Today, messages published while no primary holds the direct subscriptions are
lost. With a durable queue, messages spool during the promotion gap and the
promoted backup drains them on `setup()`. Net: failover story strictly improves.

### 4. Stale-backlog handling (the one real risk)
Persistence cuts both ways: after extended downtime the queue holds stale
prices, and the gateway chews through them before reaching live data. Mitigate
broker-side at provision time:
- Set message TTL on the queue (respectTtl + maxTtl, e.g. 30-60s — pricing
  older than that is worthless), and a bounded maxMsgSpoolUsage.
- Discard-behavior on overflow: discard oldest.
This keeps the app code free of staleness logic in v1. (Optional later:
timestamp check in dispatch.)

### 5. Configuration
Following stockloan's key pattern (default in static.conf, per-env override):

static.conf (optionPricerGateway.solace):
    bifrostInboundQueue = "SOLQ.BB.OPG.BIFROST.1"          # default
    bifrostInboundQueue = ${?optionPricerGateway.solace.bifrostInboundQueue}

environment.conf (per env, deploy repo): override with env-specific name.
Queue NAME convention to confirm with platform (SOLQ.* vs SOLQIN.* style and
instance suffix) before provisioning.

`BifrostAdapter.Solace` gains:
    BIFROST_INBOUND_QUEUE = "optionPricerGateway.solace.bifrostInboundQueue"
`BiFrostAdapterModule` binds it @Named, same as the topic subscriptions today.
The two topic-subscription @Named injections in the listener are removed (the
topics move to the queue's broker-side subscription set); the dispatch-side
RESPONSE/GREEKS prefix constants are unaffected.

### 6. Provisioning
- NPS: create durable queue + map topic subscriptions Pricing/RESPONSE/> and
  Pricing/GREEKS/> via SEMP (same Bruno workflow as SOLQIN.BB.OPG.OPT.1),
  with TTL/spool settings from §4. Client-username needs consume permission.
- Pilot/prod: via the existing config/provisioning Jira; CR lead time applies.

### 7. Test plan
- Unit: existing BifrostInboundListenerTest unchanged (dispatch untouched).
- QA functional: publish to the topics -> confirm delivery via queue.
- QA persistence: stop gateway, publish, start -> spooled messages delivered.
- QA failover: repeat kill-primary test; verify promoted backup binds the flow
  and drains any spooled messages ("Magics"-equivalent log lines below).
- Observe queue depth in SolAdmin during all of the above.

### 8. Rollback
Config + contained code change in one class; revert commit restores direct
subscriptions. Queue can stay provisioned (harmless) or be removed.
