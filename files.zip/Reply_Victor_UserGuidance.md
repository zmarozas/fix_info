# Reply to Victor — "anything the user could have done differently?"

Based on what I've been able to see so far, I don't believe the user did anything wrong. The orders were cancelled normally, and the trades on them were busted afterwards — both are valid actions in isolation.

The problem is on our side. When the bust was processed, Blackbird restored the busted quantity as open onto orders that were already cancelled, i.e. in a terminal state. That left 25,000 showing as open on an order that could not be worked, which then flagged as invalid and had to be released manually by the service desk at 11:38:46.

One possibility is that busting the trades before cancelling the orders, rather than after, would avoid the issue — but I'd want to confirm that against the message flow before we give it to users as guidance. Message search was unavailable this afternoon so I couldn't complete the investigation.

I'm raising a Jira with the findings so far and will paste the number here. I'll update it with the full timeline and a confirmed root cause once message search is back up.
