// ============================================================================
// BLACKBIRD-55358 - FINAL SCOPE (sent-only) - exact end-state of touched code
// Apply by replacing each method with the version below.
// ============================================================================

// ---------------------------------------------------------------------------
// 1. OrderQuantities.java
// ---------------------------------------------------------------------------

// (a) REVERT to original - leaves guard removed:
private boolean isLeavesQtyChangeRequired(ExecutionAction execution) {
    return !isPreviouslyBustedAmerMulticross()
        && (!isBust(execution) || isReinstatingBust(execution));
}

// (b) DELETE this method entirely (no longer referenced):
//     private boolean isBustOnCompletedAmerOrder(ExecutionAction execution) { ... }

// (c) REVERT to original - reserved guard removed:
private void adjustParentReservedQuantity(ExecutionAction execution) {
    if (order.hasParent() && !execution.isReinstate()
            && !isWaveZeroNonReinstatingBust(execution)
            && !isFillOfForceCancelledSlice(execution)) {
        propagateReservedQtyToParent(-execution.getBoundedDeltaQuantity());
    }
}

// (d) KEEP - the one change that ships:
private boolean isExecutionConsumesSentQty(ExecutionAction execution) {
    return (isExecutionOfSentDescendant(execution) || isSentSliceOrder())
        && !execution.isNonReinstatingBust()
        && !execution.isReinstate()
        && !isFillOfForceCancelledSlice(execution)
        && !isBustOnCancelledSentLeg(execution);
}

// (e) KEEP - the new predicate (sole usage: isExecutionConsumesSentQty):
private boolean isBustOnCancelledSentLeg(ExecutionAction execution) {
    DeskOrder sliceOrder = execution.getOrder();
    return isBust(execution)
        && sliceOrder != null
        && order.getRegion() == Region.AMER
        && NotFilledTerminalStatusOrderSpecification.isSatisfiedBy(sliceOrder);
}

// ---------------------------------------------------------------------------
// 2. SalesDeskTradeBustingTest.testBustedTradesOnCancelledOrders...
//    Post-bust assertion block - REPLACE the existing assertions with:
//    (LeavesQty reinstatement on cancelled orders is venue-directed
//     (reinstatedQuantity=true) and intentionally preserved; Batman's
//     terminal-order contract is SentQty=0 / OpenQty=0.)
// ---------------------------------------------------------------------------

batman.mustSee().order().parentChildType(Child).deskId(CASH)
        .state(CANCELLED).sentQty(0).openQty(0);
batman.mustSee().order().parentChildType(Wave).deskId(CASH)
        .state(CANCELLED).sentQty(0).openQty(0).leavesQty(100);   // reinstated by design
batman.mustSee().order().parentChildType(Root).deskId(CASH)
        .state(CANCELLED).sentQty(0).openQty(0).leavesQty(100);   // reinstated by design
batman.mustSee().order().parentChildType(Child).deskId(CASH_SALES)
        .state(CANCELLED).sentQty(0).openQty(0);

// Live sales side gets its quantity released:
batman.mustSee().order().parentChildType(Root).deskId(CASH_SALES)
        .sentQty(0).openQty(1500);

// ---------------------------------------------------------------------------
// 3. OctonSwapTradeBustingTest.testVenueBustOnCancelledOctonSwapOrders...
//    Post-bust assertion block - REPLACE with:
//    (run once, read actual leaves values on cancelled levels, then either
//     pin them with the "reinstated by design" comment or leave unasserted)
// ---------------------------------------------------------------------------

batman.mustSee().order().orderID(affiliateHedgeSlice.orderID)
        .state(CANCELLED).sentQty(0).openQty(0).cumQty(0);
batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Wave)
        .state(CANCELLED).sentQty(0).openQty(0);
batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Root)
        .state(CANCELLED).sentQty(0).openQty(0);
batman.mustSee().order().orderID(hedgeSlice.orderID)
        .state(CANCELLED).sentQty(0).openQty(0);

batman.mustSee().order().orderID(hedgeWave.orderID).cumQty(0);
batman.mustSee().order().orderID(hedgeRoot.orderID).cumQty(0);
batman.mustSee().order().orderID(swapAgencyRoot.orderID).cumQty(0);
batman.mustSee().order().orderID(agencySalesRoot.orderID).cumQty(0).sentQty(0);

// ---------------------------------------------------------------------------
// 4. Rename (both test classes):
//    ...ShouldNotRestoreOpenQuantity  ->  ...ShouldNotRestoreSentQuantity
// ---------------------------------------------------------------------------
