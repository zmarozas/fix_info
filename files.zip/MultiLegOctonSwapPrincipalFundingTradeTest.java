package com.barclays.eq.functional.amer.hightouch.octon.us.multilegexplosion.principal;

// keep existing imports; changes vs current file:
//  + import static ...xplatform.ExecutorQualifiedRole.Client;   (if not present)
//  + FillType.InternalTransfer / FillType.House used below
//  - InterCompany no longer needed in funding-trade systemRoles assertions

public class MultiLegOctonSwapPrincipalFundingTradeTest extends BaseMultiLegOctonTestSetup {

    @Story(spec = "https://estjira.barcapint.com/browse/BLACKBIRD-49040")
    @Test
    public void testOrderFillForInternalTransfer() {

        batman.createOrder().deskId(SWAP).handlInst(Manual)
                .positionAccount("0010012912099")
                .traderId("SWAP_DESK_TRADER").send();                       // + traderId

        batman.slice().targetDeskId("LDN-EFS-PIII")
                .suppressOrderExplosion(true)
                .traderID("SWAP_DESK_TRADER").send();                       // + traderID

        OrderReference firmSliceOrder = batman.mustSee().sliceOrder()
                .portfolioType(FirmNonArb)
                .targetDeskId("LDN-EFS-PIII")
                .positionAccount("0010012912099")
                .legalEntity(BBPLC)
                .isAffiliate(false)
                .orderQty(1000.0)
                .reference();

        emeaDownstreamBlackbird.mustSee().newOrderSingle()
                .side(BUY)
                .originatingLegalEntity(BBPLC)
                .clientSettlType(Regular)
                .executorQualifiedRole(Person)      // as in current multileg NOS block
                .handlInst(Manual)
                .isAffiliate(false)
                .legalEntity(BBPLC)
                .ordType(MARKET)
                .orderCapacity(OrderCapacity.Agency)
                .orderQty(1000.0)
                .portfolioType(FirmNonArb)
                .rootOrderCapacity(Principal)
                .settlType(Regular)
                .senderCompId("BLACKBIRD")
                .targetCompId("BLACKBIRD")
                .deskId("SWAP")
                .targetDeskId("LDN-EFS-PIII")
                .currency("USD")
                .orderOriginationSystem("BLACKBIRD")
                .positionAccount("0010012912099")
                .settlCurrency("USD");

        DownstreamBlackbirdOmsOrder emeaOrder = emeaDownstreamBlackbird.acceptOrder().send();
        emeaDownstreamBlackbird.fillOrder(emeaOrder).lastQty(1000)
                .fillType(FillType.InternalTransfer)                        // was Broker
                .lastMkt(OFF_EXCHANGE).send();

        pog2.mustSee().trade()
                .orderId(firmSliceOrder.orderID)
                .execType(TRADE)
                .lastQty(1000.0)
                .lastPx(1.0)
                .lastCapacity(P)
                .legalEntity(BBPLC)
                .orderCapacity(OrderCapacity.Principal)
                .rootOrderCapacity(Principal)
                .settlType(Regular)
                .clientSettlType(Regular)
                .handlInst(Manual)
                .isRiskless(false)
                .isManuallyTicketed(false)
                .investorQualifiedRole(InvestorQualifiedRole.Person)
                .investmentDecisionWithinFirm("SWAP_DESK_TRADER")           // + IDF
                .executorQualifiedRole(Client)
                .executionWithinFirm("NORE")
                .mIFIDTradingCapacity(MIFIDTradingCapacity.DEAL)
                .clientFlowType(Worked)
                .ordType(MARKET)
                .currency("USD")
                .systemRoles(EnumSet.of(SystemRole.TradingRole, SystemRole.InternalMarketRole)) // - InterCompany
                .executingFirm("GSD")
                .settlCurrency("USD")
                .deskId("SWAP")
                .sourceDeskId("SWAP")
                .orderOriginationSystem("BLACKBIRD")
                .deskGroup("PROGRAMS")
                .region("AMER")
                .positionAccount("0010012912099")
                .clientId(null)
                .relatedClientId(null)
                .lastMkt(OFF_EXCHANGE)
                .fillType(FillType.InternalTransfer)                        // was Broker
                .portfolioType(FirmNonArb)
                .trdType(TrdType.FundingTrade);
    }

    @Story(spec = "https://estjira.barcapint.com/browse/BLACKBIRD-49040")
    @Test
    public void testOrderFillForHouseFill() {
        // identical flow; only the fill type differs (BBPLC -> BCSL house fill)

        batman.createOrder().deskId(SWAP).handlInst(Manual)
                .positionAccount("0010012912099")
                .traderId("SWAP_DESK_TRADER").send();

        batman.slice().targetDeskId("LDN-EFS-PIII")
                .suppressOrderExplosion(true)
                .traderID("SWAP_DESK_TRADER").send();

        OrderReference firmSliceOrder = batman.mustSee().sliceOrder()
                .portfolioType(FirmNonArb)
                .targetDeskId("LDN-EFS-PIII")
                .positionAccount("0010012912099")
                .legalEntity(BBPLC)
                .isAffiliate(false)
                .orderQty(1000.0)
                .reference();

        emeaDownstreamBlackbird.mustSee().newOrderSingle()
                .side(BUY)
                .originatingLegalEntity(BBPLC)
                .clientSettlType(Regular)
                .executorQualifiedRole(Person)
                .handlInst(Manual)
                .isAffiliate(false)
                .legalEntity(BBPLC)
                .ordType(MARKET)
                .orderCapacity(OrderCapacity.Agency)
                .orderQty(1000.0)
                .portfolioType(FirmNonArb)
                .rootOrderCapacity(Principal)
                .settlType(Regular)
                .senderCompId("BLACKBIRD")
                .targetCompId("BLACKBIRD")
                .deskId("SWAP")
                .targetDeskId("LDN-EFS-PIII")
                .currency("USD")
                .orderOriginationSystem("BLACKBIRD")
                .positionAccount("0010012912099")
                .settlCurrency("USD");

        DownstreamBlackbirdOmsOrder emeaOrder = emeaDownstreamBlackbird.acceptOrder().send();
        emeaDownstreamBlackbird.fillOrder(emeaOrder).lastQty(1000)
                .fillType(FillType.House)                                   // BCSL house fill
                .lastMkt(OFF_EXCHANGE).send();

        pog2.mustSee().trade()
                .orderId(firmSliceOrder.orderID)
                .execType(TRADE)
                .lastQty(1000.0)
                .lastPx(1.0)
                .lastCapacity(P)
                .legalEntity(BBPLC)
                .orderCapacity(OrderCapacity.Principal)
                .rootOrderCapacity(Principal)
                .settlType(Regular)
                .clientSettlType(Regular)
                .handlInst(Manual)
                .isRiskless(false)
                .isManuallyTicketed(false)
                .investorQualifiedRole(InvestorQualifiedRole.Person)
                .investmentDecisionWithinFirm("SWAP_DESK_TRADER")
                .executorQualifiedRole(Client)
                .executionWithinFirm("NORE")
                .mIFIDTradingCapacity(MIFIDTradingCapacity.DEAL)
                .clientFlowType(Worked)
                .ordType(MARKET)
                .currency("USD")
                .systemRoles(EnumSet.of(SystemRole.TradingRole, SystemRole.InternalMarketRole))
                .executingFirm("GSD")
                .settlCurrency("USD")
                .deskId("SWAP")
                .sourceDeskId("SWAP")
                .orderOriginationSystem("BLACKBIRD")
                .deskGroup("PROGRAMS")
                .region("AMER")
                .positionAccount("0010012912099")
                .clientId(null)
                .relatedClientId(null)
                .lastMkt(OFF_EXCHANGE)
                .fillType(FillType.House)
                .portfolioType(FirmNonArb)
                .trdType(TrdType.FundingTrade);
    }
}
