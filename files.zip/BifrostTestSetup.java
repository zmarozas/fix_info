package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barclays.eq.roe.optionpricer.OptionPricerFactory;
import com.barcap.eq.integration.common.xplatform.ExerciseType;
import com.barcap.eq.integration.common.xplatform.PutOrCall;
import com.barcap.eq.integration.common.xplatform.SettlementCode;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResult;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.Date;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.FirstOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.SecondOrdGreeks;

import org.junit.Before;
import org.mockito.MockitoAnnotations;

/**
 * Shared test fixtures for BiFrost bridge tests.
 * JUnit 4 runs base @Before before subclass @Before, so subclass setUp can use @Mock fields.
 */
public abstract class BifrostTestSetup {

    protected static final String ENV_PREFIX = "bb_dev";
    protected static final String DEFAULT_TZ = "America/New_York";

    protected static final long SENDING_MILLIS = 1735000000000L;
    protected static final long EXPIRY_MILLIS  = 1735603200000L;

    protected static final double EPSILON = 1e-6;

    @Before
    public final void initBifrostTestMocks() {
        MockitoAnnotations.initMocks(this);
    }

    protected static Date buildDate(long timestampMillis) {
        return Date.newBuilder()
                .setTimestamp(timestampMillis)
                .setTz(DEFAULT_TZ)
                .build();
    }

    protected static IOptionPricingSubscriptionRequestMessage buildRoeRequest(String ric, String underlyingRic) {
        IOptionPricingSubscriptionRequestMessage req =
                OptionPricerFactory.createOptionPricingSubscriptionRequestMessage();
        req.setRIC(ric);
        req.setUnderlyingRIC(underlyingRic);
        req.setOptionStrikePrice(150.0);
        req.setExpireDateAsTimestamp(EXPIRY_MILLIS);
        req.setSendingTimeAsTimestamp(SENDING_MILLIS);
        req.setPutOrCall(PutOrCall.Call);
        req.setExerciseType(ExerciseType.AMERICAN);
        req.setSettlementCode(SettlementCode.PHYSICAL);
        return req;
    }

    protected static RiskProfile buildRiskProfile(double tv, double delta, double gamma) {
        return RiskProfile.newBuilder()
                .setTv(tv)
                .setFirstOrderGreeks(FirstOrdGreeks.newBuilder()
                        .setDelta(delta).build())
                .setSecondOrderGreeks(SecondOrdGreeks.newBuilder()
                        .setGamma(gamma).build())
                .setPricingDate(buildDate(SENDING_MILLIS))
                .build();
    }

    protected static PricingResult buildPricingResult(int tradeIndex,
                                                      String productId,
                                                      double tv,
                                                      double delta,
                                                      double gamma) {
        return buildPricingResult(tradeIndex, productId, tv, delta, gamma, "", "");
    }

    protected static PricingResult buildPricingResult(int tradeIndex,
                                                      String productId,
                                                      double tv,
                                                      double delta,
                                                      double gamma,
                                                      String error,
                                                      String warning) {
        PricingResult.Builder b = PricingResult.newBuilder()
                .setTradeIndex(tradeIndex)
                .setProductId(productId)
                .setRiskProfile(buildRiskProfile(tv, delta, gamma));
        if (!error.isEmpty()) {
            b.setError(error);
        }
        if (!warning.isEmpty()) {
            b.setWarning(warning);
        }
        return b.build();
    }
}
