package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barclays.eq.roe.optionpricer.OptionPricerFactory;
import com.barcap.eq.integration.common.xplatform.ExerciseType;
import com.barcap.eq.integration.common.xplatform.PutOrCall;
import com.barcap.eq.integration.common.xplatform.SettlementCode;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResult;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.Date;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.FirstOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.SecondOrdGreeks;

import org.junit.Before;
import org.mockito.MockitoAnnotations;

/**
 * Shared test fixtures for BiFrost bridge tests.
 * <p>
 * Holds constants and message-builder helpers used across translator, codec
 * and handler tests so each test class only has to declare what's unique to it.
 * <p>
 * JUnit 4 runs the base {@code @Before} (initMocks) before any subclass
 * {@code @Before}, so subclass setUp can use {@code @Mock}-annotated fields
 * directly.
 */
public abstract class BifrostTestSetup {

    // --- shared constants ---

    protected static final String ENV_PREFIX = "bb_dev";

    protected static final String DEFAULT_TZ = "America/New_York";

    protected static final long SENDING_MILLIS = 1735000000000L;
    protected static final long EXPIRY_MILLIS  = 1735603200000L; // 2024-12-31

    protected static final double EPSILON = 1e-6;

    // --- mockito init ---

    @Before
    public final void initBifrostTestMocks() {
        MockitoAnnotations.initMocks(this);
    }

    // --- shared builders ---

    /** BiFrost RiskMeta.Date with DEFAULT_TZ. */
    protected static Date buildDate(long timestampMillis) {
        return Date.newBuilder()
                .setTimestamp(timestampMillis)
                .setTz(DEFAULT_TZ)
                .build();
    }

    /**
     * Vanilla American CALL on the given RIC/underlying, strike 150,
     * EXPIRY_MILLIS expiry, SENDING_MILLIS sending time, PHYSICAL settlement.
     * Tests that need different values can modify the returned object.
     */
    protected static IOptionPricingSubscriptionRequestMessage buildRoeRequest(String ric, String underlyingRic) {
        IOptionPricingSubscriptionRequestMessage req =
                OptionPricerFactory.createOptionPricingSubscriptionRequestMessage();
        req.setRIC(ric);
        req.setUnderlyingRIC(underlyingRic);
        req.setOptionStrikePrice(150.0);
        req.setExpireDateAsTimestamp(EXPIRY_MILLIS);
        req.setSendingTimeAsTimestamp(SENDING_MILLIS);
        req.setPutOrCall(PutOrCall.Call);
        req.setExerciseType(ExerciseType.AMERICAN);
        req.setSettlementCode(SettlementCode.PHYSICAL);
        return req;
    }

    /**
     * BiFrost PricingResult with the supplied productId and a RiskProfile
     * carrying tv + delta (first-order) + gamma (second-order). tradeIndex is
     * required by the protobuf schema; handlers ignore it.
     */
    protected static PricingResult buildPricingResult(int tradeIndex,
                                                      String productId,
                                                      double tv,
                                                      double delta,
                                                      double gamma) {
        return PricingResult.newBuilder()
                .setTradeIndex(tradeIndex)
                .setProductId(productId)
                .setRiskProfile(RiskProfile.newBuilder()
                        .setTv(tv)
                        .setFirstOrderGreeks(FirstOrdGreeks.newBuilder()
                                .setDelta(delta).build())
                        .setSecondOrderGreeks(SecondOrdGreeks.newBuilder()
                                .setGamma(gamma).build())
                        .build())
                .build();
    }
}
