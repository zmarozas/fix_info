package com.barcap.eq.oms.server.bifrost;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;

public interface PricingRequestPublisher {
    void publish(PricingRequest request);
}
