package com.barcap.eq.oms.server.bifrost;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;

/**
 * Publishes a BiFrost {@link PricingRequest} to the appropriate Solace topic.
 * <p>
 * The publisher owns the wire concern (topic naming, Solace session, serialization);
 * upstream code only hands it a fully-built protobuf message.
 */
public interface PricingRequestPublisher {

    /**
     * Publish a pricing request to BiFrost. The topic is derived by the
     * implementation from the request's product data (typically the underlying name).
     */
    void publish(PricingRequest request);
}
