package com.barcap.eq.oms.server.bifrost;

import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.JCSMPSession;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;

public interface PricingRequestPublisher {
    void setup(JCSMPSession session) throws JCSMPException;
    void publish(PricingRequest request) throws JCSMPException;
}
