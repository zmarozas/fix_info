package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;
import com.barclays.eq.roe.optionpricer.OptionPricerFactory;
import com.barcap.eq.integration.common.xplatform.PutOrCall;
import com.barcap.eq.integration.common.xplatform.ExerciseType;
import com.barcap.eq.integration.common.xplatform.SettlementCode;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;
import protobuf.com.barcap.eq.risk.flow.PricingData.ProductData;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.FirstOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.SecondOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionStyle;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.SettlementType;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PricingMessageTranslatorTest {

    private static final double EPSILON = 1e-6;
    private static final long EXPIRY_MILLIS  = 1735603200000L; // 2024-12-31
    private static final long SENDING_MILLIS = 1735000000000L;

    private final PricingMessageTranslator translator = new PricingMessageTranslator();

    @Test
    public void testInboundMapsAllProductFields() {
        IOptionPricingSubscriptionRequestMessage req =
                OptionPricerFactory.createOptionPricingSubscriptionRequestMessage();
        req.setRIC("AAPL.O");
        req.setUnderlyingRIC("AAPL.O");
        req.setOptionStrikePrice(150.0);
        req.setExpireDateAsTimestamp(EXPIRY_MILLIS);
        req.setSendingTimeAsTimestamp(SENDING_MILLIS);
        req.setPutOrCall(PutOrCall.CALL);
        req.setExerciseType(ExerciseType.AMERICAN);
        req.setSettlementCode(SettlementCode.PHYSICAL);

        // ProductId is the environment-prefixed RIC produced by ProductIdCodec ({prefix}_{ric}).
        // Translator is opaque to the encoding; it just passes the string through.
        PricingRequest out = translator.toBifrostRequest(req, "corr-123", "bb_dev_AAPL.O", "AAPL");

        // Request-level fields
        assertEquals("corr-123", out.getCorrelationId());
        assertEquals(SENDING_MILLIS, out.getSendingTime().getTimestamp());
        assertEquals("America/New_York", out.getSendingTime().getTz());
        assertEquals(1, out.getProductsCount());

        // Product-level fields (single product in the batch).
        ProductData p = out.getProducts(0);
        assertEquals("bb_dev_AAPL.O", p.getProductId());
        assertEquals("AAPL", p.getUnderlyingName());
        assertEquals("AAPL.O", p.getUnderlyingRic());
        assertEquals(150.0, p.getStrike(), EPSILON);
        assertEquals(EXPIRY_MILLIS, p.getExpiry().getTimestamp());
        assertEquals("America/New_York", p.getExpiry().getTz());
        assertEquals(OptionType.CALL, p.getOptionType());
        assertEquals(OptionStyle.AMERICAN, p.getOptionStyle());
        assertEquals(SettlementType.PHYSICAL, p.getSettlementType());
    }

    @Test
    public void testOutboundMapsTheoAndAllGreeks() {
        RiskProfile rp = RiskProfile.newBuilder()
                .setTv(7.50)
                .setFirstOrderGreeks(FirstOrdGreeks.newBuilder()
                        .setDelta(0.55).setVega(0.12).setTheta(-0.04)
                        .setCashRho(0.01).setBorrowRho(-0.001).setDivRho(0.002).build())
                .setSecondOrderGreeks(SecondOrdGreeks.newBuilder()
                        .setGamma(0.03).build())
                .build();

        IOptionPricingSnapshotMessage snap = translator.toRoeSnapshot("AAPL.O", rp, SENDING_MILLIS);

        assertEquals("AAPL.O", snap.getRIC());
        assertEquals(SENDING_MILLIS, snap.getSendingTimeAsTimestamp());
        assertEquals(7.50,   snap.getTheoValue(), EPSILON);
        assertEquals(0.55,   snap.getDelta(),     EPSILON);
        assertEquals(0.03,   snap.getGamma(),     EPSILON);
        assertEquals(0.12,   snap.getVega(),      EPSILON);
        assertEquals(-0.04,  snap.getTheta(),     EPSILON);
        assertEquals(0.01,   snap.getCashRho(),   EPSILON);
        assertEquals(-0.001, snap.getBorrowRho(), EPSILON);
        assertEquals(0.002,  snap.getDivRho(),    EPSILON);
    }
}
