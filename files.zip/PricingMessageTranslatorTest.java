package com.barcap.eq.oms.optionpricergateway.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;
import com.barclays.eq.roe.optionpricer.OptionPricerFactory;
import com.barcap.eq.integration.common.xplatform.PutOrCall;
import com.barcap.eq.integration.common.xplatform.ExerciseType;
import com.barcap.eq.integration.common.xplatform.SettlementCode;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;
import protobuf.com.barcap.eq.risk.flow.PricingData.ProductData;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.FirstOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.SecondOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionStyle;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.SettlementType;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class PricingMessageTranslatorTest {

    private final PricingMessageTranslator translator = new PricingMessageTranslator();
    private static final long EXPIRY_MILLIS  = 1735603200000L; // 2024-12-31
    private static final long SENDING_MILLIS = 1735000000000L;

    @Test
    void inbound_mapsAllProductFields() {
        IOptionPricingSubscriptionRequestMessage req =
                OptionPricerFactory.createOptionPricingSubscriptionRequestMessage();
        req.setRIC("AAPL.O");
        req.setUnderlyingRIC("AAPL.O");
        req.setOptionStrikePrice(150.0);
        req.setExpireDateAsTimestamp(EXPIRY_MILLIS);
        req.setSendingTimeAsTimestamp(SENDING_MILLIS);
        req.setPutOrCall(PutOrCall.CALL);
        req.setExerciseType(ExerciseType.AMERICAN);
        req.setSettlementCode(SettlementCode.PHYSICAL);

        PricingRequest out = translator.toBifrostRequest(req, "corr-123", "AAPL.O@150C@241231", "AAPL");

        // Request-level fields
        assertThat(out.getCorrelationId()).isEqualTo("corr-123");
        assertThat(out.getSendingTime().getTimestamp()).isEqualTo(SENDING_MILLIS);
        assertThat(out.getSendingTime().getTz()).isEqualTo("America/New_York");
        assertThat(out.getProductsCount()).isEqualTo(1);

        // Product-level fields (single product in the batch).
        ProductData p = out.getProducts(0);
        assertThat(p.getProductId()).isEqualTo("AAPL.O@150C@241231");
        assertThat(p.getUnderlyingName()).isEqualTo("AAPL");
        assertThat(p.getUnderlyingRic()).isEqualTo("AAPL.O");
        assertThat(p.getStrike()).isEqualTo(150.0);
        assertThat(p.getExpiry().getTimestamp()).isEqualTo(EXPIRY_MILLIS);
        assertThat(p.getExpiry().getTz()).isEqualTo("America/New_York");
        assertThat(p.getOptionType()).isEqualTo(OptionType.CALL);
        assertThat(p.getOptionStyle()).isEqualTo(OptionStyle.AMERICAN);
        assertThat(p.getSettlementType()).isEqualTo(SettlementType.PHYSICAL);
    }

    @Test
    void outbound_mapsTheoAndAllGreeks() {
        RiskProfile rp = RiskProfile.newBuilder()
                .setTv(7.50)
                .setFirstOrderGreeks(FirstOrdGreeks.newBuilder()
                        .setDelta(0.55).setVega(0.12).setTheta(-0.04)
                        .setCashRho(0.01).setBorrowRho(-0.001).setDivRho(0.002).build())
                .setSecondOrderGreeks(SecondOrdGreeks.newBuilder()
                        .setGamma(0.03).build())
                .build();

        IOptionPricingSnapshotMessage snap = translator.toRoeSnapshot("AAPL.O", rp, SENDING_MILLIS);

        assertThat(snap.getRIC()).isEqualTo("AAPL.O");
        assertThat(snap.getSendingTimeAsTimestamp()).isEqualTo(SENDING_MILLIS);
        assertThat(snap.getTheoValue()).isEqualTo(7.50);
        assertThat(snap.getDelta()).isEqualTo(0.55);
        assertThat(snap.getGamma()).isEqualTo(0.03);
        assertThat(snap.getVega()).isEqualTo(0.12);
        assertThat(snap.getTheta()).isEqualTo(-0.04);
        assertThat(snap.getCashRho()).isEqualTo(0.01);
        assertThat(snap.getBorrowRho()).isEqualTo(-0.001);
        assertThat(snap.getDivRho()).isEqualTo(0.002);
    }
}
