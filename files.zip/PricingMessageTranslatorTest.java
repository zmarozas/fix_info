package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;
import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;
import protobuf.com.barcap.eq.risk.flow.PricingData.ProductData;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionStyle;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.SecurityType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.SettlementType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.StrikeType;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.FirstOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.SecondOrdGreeks;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PricingMessageTranslatorTest extends BifrostTestSetup {

    private final PricingMessageTranslator translator = new PricingMessageTranslator();

    @Test
    public void testInboundMapsAllProductFields() {
        IOptionPricingSubscriptionRequestMessage req = buildRoeRequest("AAPL.O", "AAPL.O");

        // ProductId is the environment-prefixed RIC produced by ProductIdCodec ({prefix}_{ric}).
        // Translator is opaque to the encoding; it just passes the string through.
        PricingRequest out = translator.toBifrostRequest(req, "corr-123", "bb_dev_AAPL.O", "AAPL");

        // Request-level fields
        assertEquals("corr-123", out.getCorrelationId());
        assertEquals(SENDING_MILLIS, out.getSendingTime().getTimestamp());
        assertEquals(DEFAULT_TZ, out.getSendingTime().getTz());
        assertEquals(1, out.getProductsCount());

        // Product-level fields (single product in the batch).
        ProductData p = out.getProducts(0);
        assertEquals("bb_dev_AAPL.O", p.getProductId());
        assertEquals(SecurityType.LISTED_OPTION, p.getSecurityType());
        assertEquals("AAPL", p.getUnderlyingName());
        assertEquals("AAPL.O", p.getUnderlyingRic());
        assertEquals(150.0, p.getStrike(), EPSILON);
        assertEquals(StrikeType.STRIKE_ABSOLUTE, p.getStrikeType());
        assertEquals(EXPIRY_MILLIS, p.getExpiry().getTimestamp());
        assertEquals(DEFAULT_TZ, p.getExpiry().getTz());
        assertEquals(OptionType.CALL, p.getOptionType());
        assertEquals(OptionStyle.AMERICAN, p.getOptionStyle());
        assertEquals(SettlementType.PHYSICAL, p.getSettlementType());
    }

    @Test
    public void testOutboundMapsTheoAndAllGreeks() {
        RiskProfile rp = RiskProfile.newBuilder()
                .setTv(7.50)
                .setFirstOrderGreeks(FirstOrdGreeks.newBuilder()
                        .setDelta(0.55).setVega(0.12).setTheta(-0.04)
                        .setCashRho(0.01).setBorrowRho(-0.001).setDivRho(0.002).build())
                .setSecondOrderGreeks(SecondOrdGreeks.newBuilder()
                        .setGamma(0.03).build())
                .build();

        IOptionPricingSnapshotMessage snap = translator.toRoeSnapshot("AAPL.O", rp, SENDING_MILLIS);

        assertEquals("AAPL.O", snap.getRIC());
        assertEquals(SENDING_MILLIS, snap.getSendingTimeAsTimestamp());
        assertEquals(7.50,   snap.getTheoValue(), EPSILON);
        assertEquals(0.55,   snap.getDelta(),     EPSILON);
        assertEquals(0.03,   snap.getGamma(),     EPSILON);
        assertEquals(0.12,   snap.getVega(),      EPSILON);
        assertEquals(-0.04,  snap.getTheta(),     EPSILON);
        assertEquals(0.01,   snap.getCashRho(),   EPSILON);
        assertEquals(-0.001, snap.getBorrowRho(), EPSILON);
        assertEquals(0.002,  snap.getDivRho(),    EPSILON);
    }
}
