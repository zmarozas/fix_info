// =====================================================================
// BifrostInboundListenerTest — ADDITIONS for BLACKBIRD-55199
// All existing dispatch/translator tests stay EXACTLY as they are
// (dispatch is unchanged). Add the below.
// =====================================================================

// --- imports to add ---
import com.solacesystems.jcsmp.ConsumerFlowProperties;
import com.solacesystems.jcsmp.FlowReceiver;
import com.solacesystems.jcsmp.JCSMPProperties;
import com.solacesystems.jcsmp.JCSMPSession;
import com.solacesystems.jcsmp.XMLMessageListener;
import org.mockito.ArgumentCaptor;
// (Mockito statics: mock/when/verify/never/any — match your existing style)

// --- fields to add next to the existing @Mock fields ---
@Mock private JCSMPSession session;
@Mock private FlowReceiver flowReceiver;

private static final String QUEUE_NAME = "SOLQ.BB.OPG.BIFROST.TEST";

// --- in setUp(), after constructing the listener, add: ---
//     listener.bifrostInboundQueueName = QUEUE_NAME;
// (field is package-private for exactly this)

@Test
public void testSetupBindsFlowToConfiguredQueueWithAutoAck() throws Exception {
    when(session.createFlow(any(XMLMessageListener.class), any(ConsumerFlowProperties.class)))
            .thenReturn(flowReceiver);

    listener.setup(session);

    ArgumentCaptor<ConsumerFlowProperties> flowPropsCaptor =
            ArgumentCaptor.forClass(ConsumerFlowProperties.class);
    verify(session).createFlow(any(XMLMessageListener.class), flowPropsCaptor.capture());

    ConsumerFlowProperties props = flowPropsCaptor.getValue();
    assertEquals(QUEUE_NAME, props.getEndpoint().getName());
    assertEquals(JCSMPProperties.SUPPORTED_MESSAGE_ACK_AUTO, props.getAckMode());
    verify(flowReceiver).start();
}

@Test
public void testOnReceiveSchedulesDispatchOnApexThread() throws Exception {
    when(session.createFlow(any(XMLMessageListener.class), any(ConsumerFlowProperties.class)))
            .thenReturn(flowReceiver);
    listener.setup(session);

    ArgumentCaptor<XMLMessageListener> messageListenerCaptor =
            ArgumentCaptor.forClass(XMLMessageListener.class);
    verify(session).createFlow(messageListenerCaptor.capture(),
            any(ConsumerFlowProperties.class));

    BytesXMLMessage msg = mock(BytesXMLMessage.class);
    Destination destination = mock(Destination.class);
    when(msg.getDestination()).thenReturn(destination);
    when(destination.getName()).thenReturn("Pricing/RESPONSE/AAPL/corr-1");
    when(msg.getBytes()).thenReturn(new byte[]{1, 2, 3});

    messageListenerCaptor.getValue().onReceive(msg);

    // scheduler is the existing mock; matches the existing scheduleOnce stubbing style
    verify(scheduler).scheduleOnce(any(Runnable.class));
}

@Test
public void testShutdownClosesFlow() throws Exception {
    when(session.createFlow(any(XMLMessageListener.class), any(ConsumerFlowProperties.class)))
            .thenReturn(flowReceiver);
    listener.setup(session);

    listener.shutdown();

    verify(flowReceiver).close();
}

@Test
public void testShutdownWithoutSetupIsNoOp() {
    listener.shutdown(); // must not throw
}

// =====================================================================
// Notes:
// 1. scheduleOnce verification: your existing tests mock Scheduler and its
//    fluent .immediately() — reuse the same stubbing (e.g. a ScheduledTask
//    mock returned from scheduleOnce). Match whatever BifrostTestSetup does
//    today; the verify line may need that stub to avoid an NPE on
//    .immediately().
// 2. props.getAckMode()/getEndpoint() getters — verify names via
//    autocomplete on ConsumerFlowProperties; if getEndpoint() returns
//    Endpoint, getName() is on it.
// 3. If the team objects to the package-private field, alternative is a
//    constructor parameter for the queue name — bigger diff, same effect.
// =====================================================================
