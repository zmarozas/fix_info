/*
 * BLACKBIRD-55073 — refactor of the target book / sub-book block in
 * CreateSliceOrderAndRouteParamsToSliceOrderTranslator.translate()
 *
 * Resolution precedence (both fields):
 *   1. TradingConfig override value      (when ENABLE_AMER_TO_EMEA_TARGET_ACCOUNT_OVERRIDE)
 *   2. Slice params value                (createSliceOrderAndRouteParams)
 *   3. Parent order value                (fallback when slice doesn't carry it)
 *
 * NOTE on types: assumes parent.getTargetPositionAccount() returns Book
 * (already mapped) while params/config carry String -> mapped via bookMapper.
 * If parent stores a String instead, collapse resolveTargetBook to the
 * string chain + single map call (variant at bottom).
 */

// ---- in translate(), the whole block becomes one line: ----

        applyAmerToEmeaTargetBookAndSubBook(
                parent, createSliceOrderAndRouteParams, uninitializedDeskOrder, violations);

// ---- extracted methods ----

    private void applyAmerToEmeaTargetBookAndSubBook(DeskOrder parent,
                                                     CreateSliceOrderAndRouteParams params,
                                                     UninitializedDeskOrder uninitializedDeskOrder,
                                                     Violations violations) {
        if (!amerToEmeaFundingTradeOrderSpecification
                .isSatisfiedBySourceOMS(parent.getRootOrder(), params.getTargetDeskID())) {
            return;
        }
        Book targetBook = resolveTargetBook(parent, params, violations);
        if (targetBook != null) {
            uninitializedDeskOrder.targetPositionAccount(targetBook);
        }
        uninitializedDeskOrder.targetSubBook(resolveTargetSubBook(parent, params));
    }

    @Nullable
    private Book resolveTargetBook(DeskOrder parent,
                                   CreateSliceOrderAndRouteParams params,
                                   Violations violations) {
        if (isOverrideEnabled()) {
            return mapBook(tradingConfigurationProvider.getAmerToEmeaTargetPositionAccount(), violations);
        }
        Book fromParams = mapBook(params.getTargetPositionAccount(), violations);
        return fromParams != null ? fromParams : parent.getTargetPositionAccount(); // slice -> parent fallback
    }

    @Nullable
    private String resolveTargetSubBook(DeskOrder parent, CreateSliceOrderAndRouteParams params) {
        if (isOverrideEnabled()) {
            return tradingConfigurationProvider.getAmerToEmeaTargetSubBook();
        }
        String fromParams = params.getTargetSubBook();
        return fromParams != null ? fromParams : parent.getTargetSubBook();          // slice -> parent fallback
    }

    private boolean isOverrideEnabled() {
        // TEMPORARY (BLACKBIRD-55073): remove with the override configs once BM sends real values.
        return tradingConfigurationProvider.isAmerToEmeaTargetAccountOverrideEnabled();
    }

    @Nullable
    private Book mapBook(@Nullable String positionAccount, Violations violations) {
        return positionAccount != null ? bookMapper.map(positionAccount, violations) : null;
    }

/*
 * ---- Variant if parent.getTargetPositionAccount() returns String ----
 *
 *   @Nullable
 *   private Book resolveTargetBook(DeskOrder parent, CreateSliceOrderAndRouteParams params, Violations violations) {
 *       String account = isOverrideEnabled()
 *               ? tradingConfigurationProvider.getAmerToEmeaTargetPositionAccount()
 *               : firstNonNull(params.getTargetPositionAccount(), parent.getTargetPositionAccount());
 *       return mapBook(account, violations);
 *   }
 */
