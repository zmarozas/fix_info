// ============================================================
// ADDITIONS to existing OptionComplianceAdminMBean
// (com.barcap.eq.oms.acl.jmx.OptionComplianceAdminMBean)
// Delete OptionDomainAdminMBean.java and revert the
// OptionEmsApp.startBeans() line — it already starts
// OptionComplianceAdminMBean, so no launcher change needed.
// ============================================================

// --- imports to add ---
import com.barcap.eq.oms.domain.marketdata.OptionPricingDataSubscriptionService;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanParameterInfo;
import java.util.Arrays;

// --- field to add (next to the existing @Inject fields) ---
@Inject
private OptionPricingDataSubscriptionService optionPricingDataSubscriptionService;

// --- constants ---
private static final String CLEAR_OPTION_PRICING_SUBSCRIPTIONS_METHOD =
        "clearOptionPricingDataSubscriptions";
private static final String RESUBSCRIBE_ALL_OPTION_PRICING_METHOD =
        "resubscribeAllOptionPricingData";
private static final String SUBSCRIBE_OPTION_PRICING_FOR_ESMP_METHOD =
        "subscribeOptionPricingDataForEsmp";

private static final String CLEAR_OPTION_PRICING_SUBSCRIPTIONS_INFO =
        "Clears all cached option pricing data subscriptions.";
private static final String RESUBSCRIBE_ALL_OPTION_PRICING_INFO =
        "Re-sends option pricing data subscription requests for all cached ESMPs.";
private static final String SUBSCRIBE_OPTION_PRICING_FOR_ESMP_INFO =
        "Sends an option pricing data subscription request for the given ESMP.";

private static final String INITIATED_CLEAR_OPTION_PRICING_SUBSCRIPTIONS =
        "Initiated clear of all cached option pricing data subscriptions";
private static final String INITIATED_RESUBSCRIBE_ALL_OPTION_PRICING =
        "Initiated resubscribe of option pricing data for all cached ESMPs";
private static final String INITIATED_SUBSCRIBE_OPTION_PRICING_FOR_ESMP =
        "Initiated option pricing data subscription for ESMP: ";

// --- operations ---
public String clearOptionPricingDataSubscriptions() {
    log.info("Mbean -executing clearOptionPricingDataSubscriptions");
    runOnMainThreadService.waitForCompletion(() ->
            optionPricingDataSubscriptionService.clearCachedSubscriptions());
    return INITIATED_CLEAR_OPTION_PRICING_SUBSCRIPTIONS;
}

public String resubscribeAllOptionPricingData() {
    log.info("Mbean -executing resubscribeAllOptionPricingData");
    runOnMainThreadService.waitForCompletion(() ->
            optionPricingDataSubscriptionService.resubscribe());
    return INITIATED_RESUBSCRIBE_ALL_OPTION_PRICING;
}

public String subscribeOptionPricingDataForEsmp(String esmp) {
    if (esmp == null || esmp.trim().isEmpty()) {
        return "Error: ESMP parameter is required and cannot be empty";
    }
    log.info("Mbean -executing subscribeOptionPricingDataForEsmp: esmp {}", esmp);
    runOnMainThreadService.waitForCompletion(() ->
            optionPricingDataSubscriptionService.resubscribe(esmp));
    return INITIATED_SUBSCRIBE_OPTION_PRICING_FOR_ESMP.concat(esmp);
}

// --- UI: keep ALL parent compliance ops, append the three new ones ---
@Override
protected MBeanOperationInfo[] createMBeanOperationInfo() {
    MBeanOperationInfo[] base = super.createMBeanOperationInfo();
    MBeanOperationInfo[] all = Arrays.copyOf(base, base.length + 3);
    all[base.length] = new MBeanOperationInfo(
            CLEAR_OPTION_PRICING_SUBSCRIPTIONS_METHOD,
            CLEAR_OPTION_PRICING_SUBSCRIPTIONS_INFO,
            new MBeanParameterInfo[]{},
            String.class.getName(), MBeanOperationInfo.ACTION);
    all[base.length + 1] = new MBeanOperationInfo(
            RESUBSCRIBE_ALL_OPTION_PRICING_METHOD,
            RESUBSCRIBE_ALL_OPTION_PRICING_INFO,
            new MBeanParameterInfo[]{},
            String.class.getName(), MBeanOperationInfo.ACTION);
    all[base.length + 2] = new MBeanOperationInfo(
            SUBSCRIBE_OPTION_PRICING_FOR_ESMP_METHOD,
            SUBSCRIBE_OPTION_PRICING_FOR_ESMP_INFO,
            new MBeanParameterInfo[]{
                    new MBeanParameterInfo("esmp", String.class.getName(),
                            "This is a required field - the ESMP of the product to subscribe option pricing data for.")
            },
            String.class.getName(), MBeanOperationInfo.ACTION);
    return all;
}
