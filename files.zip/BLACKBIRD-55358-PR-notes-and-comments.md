# MR NOTE + LINE COMMENTS — BLACKBIRD-55358 (sent-only scope, CancelledBy discriminator)

---------------------------------------------------------------------------
## 1. Note for the MR description (paste as a section, e.g. "Scope & design notes")
---------------------------------------------------------------------------

**Why this fix is conditional on WHO cancelled the order**

There are existing flows and regression tests that REQUIRE SentQty > 0 on a
CANCELLED order, so an unconditional "sent must be 0 on terminal orders" rule
is wrong:

- BLACKBIRD-3024 (`ReinstatingBustOnDownstreamSliceWithMultipleWavesAcceptanceTest`):
  when the VENUE cancels a slice and later sends a reinstating bust
  (`reinstatedQuantity=true`), the cancelled slice is deliberately re-opened —
  the tests assert `state(CANCELLED).sentQty(40)` etc. Per Chris Dodenhoff:
  the market side directs this re-opening.
- BLACKBIRD-12975 / AUT_104 (execution moves): busted quantity must return to
  the cancelled slice so the sales trader can re-slice.

The incident (INC1040558889) is the OTHER case: the FIRM cancelled the
hierarchy, and a later venue bust restored SentQty against the dead leg,
breaching Batman's terminal-order contract (OpenQty=0 / SentQty=0 on
Cancelled — per Vaibhav Nakhawa, support chat 7/30) and leaving the order
flagged Invalid until a manual Service Desk ReleaseQuantity.

The rule implemented here therefore keys on cancel provenance:

    The venue may re-open what the venue cancelled.
    Orders cancelled by the firm stay closed: busts still unwind CumQty,
    but SentQty is not restored.

This satisfies BLACKBIRD-3024, BLACKBIRD-12975 and the incident flow
simultaneously. LeavesQty reinstatement on cancelled orders is venue-directed
by design (BLACKBIRD-43896 et al.) and intentionally left untouched by this MR.

**Ask for reviewers:** please confirm the provenance rule matches product
intent — it is inferred from the existing specs above, not from a written
requirement.

---------------------------------------------------------------------------
## 2. Line-anchored PR comments (add via "Add comment" on the diff line)
---------------------------------------------------------------------------

### OrderQuantities.java — on the line `&& !isBustOnCancelledSentLeg(execution);`
(inside `isExecutionConsumesSentQty`)

> This is the only behavioural change in the MR. It stops SentQty being
> restored when a bust arrives for an execution whose slice was cancelled BY
> THE FIRM. Venue-cancelled slices are excluded on purpose — BLACKBIRD-3024
> requires the venue to be able to re-open its own cancels (sentQty > 0 on
> CANCELLED is asserted there). Mirrors the neighbouring
> `isFillOfForceCancelledSlice` pattern.

### OrderQuantities.java — on the line `&& isCancelledByFirm(sliceOrder);`
(inside `isBustOnCancelledSentLeg`)

> Cancel provenance is the discriminator, not `reinstatedQuantity` — that flag
> is true in BOTH the legitimate re-open flow (3024) and the incident flow, so
> it cannot distinguish them. FirmCancel = desk-initiated cancel; the busted
> quantity has nowhere to go and must not sit as "at risk downstream" on a
> dead leg. Null / other values fall through to today's behaviour (restore),
> which is the safe default for unknown provenance.

### OrderQuantities.java — on the line `&& order.getRegion() == Region.AMER`

> Scoped to AMER to mirror the existing `isPreviouslyBustedAmerMulticross`
> guard and match the incident. Whether this should be global is a product
> question (venue bust semantics differ by region — see 2022 Busts Quantity
> Model page); happy to widen on BA confirmation.

### QuantitySanityChecker.java — on the changed line in `calcSentQuantity`

> The checker previously derived expected sent from the child's leaves, which
> made it agree with the broken pre-fix state (leaves 100 + sent 100) and stay
> silent through the prod incident. It now encodes the actual contract: sent=0
> on FIRM-cancelled orders. Venue-cancelled orders are excluded so the
> BLACKBIRD-3024 re-open flow (legitimate sent > 0 on CANCELLED) does not
> trip it. With this rule the checker WOULD have caught INC1040558889.

### SalesDeskTradeBustingTest.java — on the renamed test method line

> Renamed ...OpenQuantity -> ...SentQuantity: the defect and the fix are about
> SentQty (Batman contract: OpenQty/SentQty = 0 on Cancelled). LeavesQty
> reinstatement on the cancelled CASH levels is venue-directed and asserted at
> its reinstated value on purpose — it is NOT part of the defect.

### SalesDeskTradeBustingTest.java — on the sales-root assertion line
(`.sentQty(0).openQty(1500)`)

> The client-facing outcome: with sent released on the firm-cancelled leg, the
> live sales Root recovers its full workable size. This is the state the
> Service Desk produced manually via ReleaseQuantity on 30 Jul.

### OctonSwapTradeBustingTest.java — on the cancelled-level assertion block

> Cancelled swap-side levels assert sentQty(0)/openQty(0) (firm-cancelled leg);
> leaves values on cancelled levels are venue-directed reinstatement and are
> left unpinned deliberately.

---------------------------------------------------------------------------
## 3. Optional one-liner for the CC12 / RTB thread
---------------------------------------------------------------------------

Re-raised the 55358 MR with a narrower rule: busts no longer restore SentQty
onto FIRM-cancelled orders (Batman contract), while venue-cancelled slices
keep the existing re-open behaviour required by BLACKBIRD-3024/12975. All
previously failing regression suites green. One confirmation needed from
BA/Erb: that cancel provenance is the intended product rule.
