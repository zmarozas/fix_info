package com.barcap.eq.oms.server.bifrost;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

/**
 * Encodes a RIC into a BiFrost ProductId with the bridge's environment prefix
 * (format: {environmentPrefix}_{ric}, e.g. "bb_dev_AAPL.O"), and decodes it back.
 * The prefix lets the Solace bridge layer route BiFrost updates to the correct
 * Blackbird VPN, preventing cross-environment leakage.
 */
@Singleton
public final class ProductIdCodec {

    private static final String DELIMITER = "_";

    private final String prefixWithDelimiter;

    @Inject
    public ProductIdCodec(@Named("bifrost.environmentPrefix") String environmentPrefix) {
        if (environmentPrefix == null || environmentPrefix.isEmpty()) {
            throw new IllegalArgumentException("environmentPrefix must not be null or empty");
        }
        this.prefixWithDelimiter = environmentPrefix + DELIMITER;
    }

    public String encode(String ric) {
        if (ric == null || ric.isEmpty()) {
            throw new IllegalArgumentException("ric must not be null or empty");
        }
        return prefixWithDelimiter + ric;
    }

    public String decode(String productId) {
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("productId must not be null or empty");
        }
        if (!productId.startsWith(prefixWithDelimiter)) {
            throw new IllegalArgumentException(
                    "productId does not start with expected prefix '" + prefixWithDelimiter + "': " + productId);
        }
        return productId.substring(prefixWithDelimiter.length());
    }
}
