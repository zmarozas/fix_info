package com.barcap.eq.oms.server.bifrost;

import javax.inject.Singleton;

/**
 * Encodes a RIC and a unique suffix into a BiFrost ProductId, and decodes
 * the ProductId back into its RIC component.
 * <p>
 * The bridge is stateless: BiFrost echoes the ProductId on every update, and
 * the bridge uses the encoded RIC to route the update to the correct Blackbird
 * snapshot topic without needing a correlation registry.
 * <p>
 * Format: {ric}|{uniqueSuffix}
 */
@Singleton
public final class ProductIdCodec {

    private static final String DELIMITER = "|";
    private static final String SPLIT_PATTERN = "\\|";
    private static final String TEMPLATE = "%s|%s";
    private static final int NUM_PARTS = 2;
    private static final int RIC_IDX = 0;

    /**
     * Encode a RIC and a unique suffix into a ProductId.
     * The suffix only needs to disambiguate concurrent subscriptions to the
     * same RIC; the codec does not interpret it.
     */
    public String encode(String ric, String uniqueSuffix) {
        if (ric == null || ric.isEmpty()) {
            throw new IllegalArgumentException("ric must not be null or empty");
        }
        if (uniqueSuffix == null || uniqueSuffix.isEmpty()) {
            throw new IllegalArgumentException("uniqueSuffix must not be null or empty");
        }
        if (ric.contains(DELIMITER) || uniqueSuffix.contains(DELIMITER)) {
            throw new IllegalArgumentException(
                    "ric and uniqueSuffix must not contain delimiter '" + DELIMITER + "'");
        }
        return String.format(TEMPLATE, ric, uniqueSuffix);
    }

    /**
     * Decode a ProductId back into its RIC component.
     *
     * @throws IllegalArgumentException if the ProductId is null, empty, or malformed
     */
    public String decode(String productId) {
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("productId must not be null or empty");
        }
        String[] parts = productId.split(SPLIT_PATTERN);
        if (parts.length != NUM_PARTS) {
            throw new IllegalArgumentException("malformed productId: " + productId);
        }
        return parts[RIC_IDX];
    }
}
