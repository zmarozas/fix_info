package com.barcap.eq.oms.server.bifrost;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

/**
 * Encodes a RIC into a BiFrost ProductId, prefixed with the bridge app's
 * environment identifier; and decodes a ProductId back into its RIC.
 * <p>
 * Format: {environmentPrefix}_{ric}  (e.g. "bb_dev_AAPL.O")
 * <p>
 * Purpose: a single BiFrost environment can serve multiple Blackbird bridge
 * deployments (dev, qa, uat, prod). By prefixing ProductIds with the bridge's
 * environment, the Solace bridge layer can route updates back to the correct
 * Blackbird VPN, preventing cross-environment leakage.
 * <p>
 * Each bridge app instance has exactly one configured prefix and ignores
 * ProductIds carrying any other prefix.
 */
@Singleton
public final class ProductIdCodec {

    private static final String DELIMITER = "_";

    private final String prefixWithDelimiter;

    @Inject
    public ProductIdCodec(@Named("bifrost.environmentPrefix") String environmentPrefix) {
        if (environmentPrefix == null || environmentPrefix.isEmpty()) {
            throw new IllegalArgumentException("environmentPrefix must not be null or empty");
        }
        this.prefixWithDelimiter = environmentPrefix + DELIMITER;
    }

    /**
     * Encode a RIC into a ProductId by prepending the configured environment prefix.
     */
    public String encode(String ric) {
        if (ric == null || ric.isEmpty()) {
            throw new IllegalArgumentException("ric must not be null or empty");
        }
        return prefixWithDelimiter + ric;
    }

    /**
     * Decode a ProductId by stripping the configured environment prefix.
     *
     * @throws IllegalArgumentException if the ProductId is null, empty, or does
     *         not start with the configured prefix (e.g. belongs to another environment)
     */
    public String decode(String productId) {
        if (productId == null || productId.isEmpty()) {
            throw new IllegalArgumentException("productId must not be null or empty");
        }
        if (!productId.startsWith(prefixWithDelimiter)) {
            throw new IllegalArgumentException(
                    "productId does not start with expected prefix '" + prefixWithDelimiter + "': " + productId);
        }
        return productId.substring(prefixWithDelimiter.length());
    }
}
