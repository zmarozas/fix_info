/*
 * BLACKBIRD-55073 — parent-only overloads for AmerToEmeaTargetBookCalculator.
 * Root mapper does NOT apply the logic (legal entity not yet calculated -> spec
 * can't run there). Values inherit root -> wave -> slice; the calculator is applied
 * at wave/slice translators where the root order exists and the spec is evaluable.
 */

// ============================================================
// 1) Add to AmerToEmeaTargetBookCalculator — overloads that
//    delegate to the existing 3-arg/2-arg methods with params = null
// ============================================================

    /** Parent-only: keep inherited book unless the override is enabled. */
    @Nullable
    public Book calculateTargetBook(@Nullable Book parentBook, Violations violations) {
        return calculateTargetBook(/* paramsPositionAccount */ null, parentBook, violations);
    }

    /** Parent-only: keep inherited sub-book unless the override is enabled. */
    @Nullable
    public String calculateTargetSubBook(@Nullable String parentSubBook) {
        return calculateTargetSubBook(/* paramsSubBook */ null, parentSubBook);
    }

// ============================================================
// 2) Wave / slice translators — spec is evaluable here (root exists).
//    Values already inherited from parent; calculator only decides
//    "keep inherited vs config override".
// ============================================================

    protected void applyAmerToEmeaTargetBookAndSubBook(UninitializedDeskOrder target,
                                                       DeskOrder rootOrder,
                                                       Violations violations) {
        if (rootOrder.getTargetDesk() == null
                || !amerToEmeaFundingTradeOrderSpecification
                        .isSatisfiedBySourceOMS(rootOrder, rootOrder.getTargetDesk().getDeskId())) {
            return;
        }
        Book targetBook = amerToEmeaTargetBookCalculator
                .calculateTargetBook(rootOrder.getTargetPositionAccount(), violations);
        if (targetBook != null) {
            target.targetPositionAccount(targetBook);
        }
        target.targetSubBook(amerToEmeaTargetBookCalculator
                .calculateTargetSubBook(rootOrder.getTargetSubBook()));
    }

// ============================================================
// 3) MINIMAL variant — if plain mapping already copies the fields
//    parent -> child, the stub's only job is the override. Guard once
//    and touch nothing when disabled (also answers the "double set"
//    concern: disabled => untouched, enabled => single deliberate set).
// ============================================================

    protected void applyAmerToEmeaTargetBookOverride(UninitializedDeskOrder target,
                                                     DeskOrder rootOrder,
                                                     Violations violations) {
        if (!amerToEmeaTargetBookCalculator.isOverrideEnabled()) {
            return; // inherited values flow root -> wave -> slice untouched
        }
        if (rootOrder.getTargetDesk() == null
                || !amerToEmeaFundingTradeOrderSpecification
                        .isSatisfiedBySourceOMS(rootOrder, rootOrder.getTargetDesk().getDeskId())) {
            return;
        }
        Book targetBook = amerToEmeaTargetBookCalculator.calculateTargetBook(null, violations);
        if (targetBook != null) {
            target.targetPositionAccount(targetBook);
        }
        target.targetSubBook(amerToEmeaTargetBookCalculator.calculateTargetSubBook(null));
    }
