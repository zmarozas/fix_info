# Options Order Trace & Support Visibility — Executive Summary

**Status:** Draft for discussion · July 2026
**Full design:** see *Options Order Trace and Journal Analytics — Design* (linked page)

---

## In one line

Make the order-lifecycle data we **already retain** searchable with SQL — daily Parquet files plus a zero-server query engine — before SpiderRock volumes make today's manual investigation workflow untenable.

## Problem

- Options volumes are set to rise sharply: planned SpiderRock expansion targets **~5,000 orders every 30 seconds** — tens of millions of order events per trading day.
- **Elasticsearch cannot carry this.** It is already heavily loaded at current volumes, retains only ~7 days, and options transaction messages are not consistently indexed there in the first place.
- The authoritative data exists — in **Neeve RDAT files** and **Bedrock journals**, already aggregated daily onto the Golden Host — but reconstructing one order across them today means manual extraction and vendor point-lookup tools with no joins and no flexible queries. Investigations are slow, and ad-hoc file copying is itself a governance concern.

## What this is NOT

- Not a new database platform, not a second Elasticsearch, not a UI project.
- Not a change to any production path — Neeve, Bedrock, Solace, and books-and-records are untouched.
- Not real-time; primarily end-of-day derived data. (A lightweight **same-day path** exists for live incidents: extract today's rolled journals to JSON and query them directly with the same tool — design §12.)
- Not a replacement for ES where ES works (equities stays as-is).

## Proposal

Convert the aggregated journals into daily, partitioned **Parquet** files on the Golden Host and query them read-only with **DuckDB** (single binary, no server, no license cost). Data stays where it already lives; we add a readable, auditable copy.

**To be precise about what we are adopting:** the commitment is to **Apache Parquet** — the open, columnar, industry-standard file format — not to any particular tool. Partitioned Parquet directories are readable by the whole modern data ecosystem (Python, Spark, Java, cloud services); DuckDB is simply today's best lightweight engine for running standard SQL directly over those files. The engine is swappable at any time; the durable asset is the open-format data.

The same tool covers both investigation modes:

- **Historical (primary):** end-of-day Parquet, partitioned by source and business date — fast SQL over any retained day or range; this is where the saved lifecycle queries run.
- **Same-day (incident):** extract today's rolled journals to JSON in a controlled scratch folder and query them directly — no waiting for the end-of-day cycle. Fresh as of the last journal roll; slower than Parquet but sufficient for a one-day, one-incident scope. (Design §12.)

Investigations start the way they do today — from the **compliance ID** of the client-facing order (as supplied by upstream systems). Single-leg orders (the majority) resolve with one indexed lookup. For multi-leg / multi-entity orders the link IDs are **discovered from the data**, then used to pull every sibling leg — a three-step funnel on exact identifiers, no fuzzy correlation at any step (design §7).

The conversion layer **reuses proven tooling**: the RDAT→JSON extractor built for the Apex 2→3 migration validation (exercised there on whole days of traffic) and the existing fastpath journal→JSON extraction — we are assembling, not inventing (design §3).

**What using it looks like** — the complete lifecycle of one order, across both data sources, with the business fields support reads (returns in seconds):

```sql
SELECT event_time, source, message_type,
       attributes['OrdStatus']  AS ord_status,
       attributes['OrderQty']   AS order_qty,
       attributes['LeavesQty']  AS leaves_qty,
       attributes['TraderID']   AS trader_id
FROM events
WHERE compliance_id = 'CMP123456'
  AND business_date = DATE '2026-07-17'
ORDER BY event_time;
```

The fixed columns (`event_time`, `compliance_id`, …) are the search keys; `attributes` carries every other message field — including ones added in future releases, automatically. For standard cases support doesn't write SQL at all: `find-order 2026-07-17 CMP123456` produces the same output from a wrapper script.

## What is Apache Parquet?

The foundation of this design is the **data format**, not any tool. Apache Parquet is the industry-standard open file format for analytical data — an Apache Software Foundation project, used everywhere from Python and Spark to every major cloud data service:

- **Columnar:** data is stored by column, not by row, so a query reads only the columns it needs — one reason lookups over gigabytes finish in seconds.
- **Compressed and self-describing:** the schema travels inside the file; repetitive trading fields compress ~10–20× versus JSON; built-in statistics let engines skip whole blocks that can't match a query.
- **Universal:** a Parquet directory is readable today by Python (pyarrow/pandas), Spark, Java, DuckDB, and cloud query services — and will remain readable for decades. **The durable asset this project creates is these files**; every tool around them is swappable.
- **Already used inside Barclays:** other teams have adopted Parquet as a data format (e.g. the COO Data Reporting QE group's pyarrow-based tooling), so this is a new application of an already-accepted format — not a new technology for the firm to approve from scratch.

## What is DuckDB?

The lightweight engine we would use to query those files: an open-source, MIT-licensed SQL engine — "SQLite for analytics" — that runs standard SQL directly against Parquet on the file system. A single binary in the user's session: no server, no ports, nothing to patch on a schedule. It is mature and mainstream (v1.0 in 2024; a 1.4 LTS release with AES-256 encryption in 2025; #4 database in the Stack Overflow survey; shipped inside Microsoft Fabric; production use at companies including Okta; covered by Manning's *DuckDB in Action*). In this design it is **read-only and replaceable** — if it were ever disallowed, the same files are queryable from approved Python with no rework. Details and links in the design, §5.1.

## Phase 1 — proof of concept (~3–5 engineer-days, normal hours, existing hardware)

**The entire POC runs in non-production.** The pipeline is first proven end-to-end on QA/SIT/UAT journals (identical archive and file formats, smaller volumes); the production-scale benchmark then uses **one representative high-volume production day copied into the same environment** via the standard data-handling process. The Golden Host enters only at the later controlled-operations phase. Demonstrated:

| Success criterion | Target |
|---|---|
| Record counts reconcile to source; all expected shards present (validated against a shard map) | 100%, with manifest |
| Exact order lookup (compliance ID + date) | seconds, not minutes |
| Full lifecycle — incl. one multi-leg order reconstructed from its primary compliance ID alone (link IDs discovered from the data) — in a single SQL query | compliance-ID and link-ID coverage validated in both sources |
| Storage vs. extracted JSON | ~10–20× smaller (zstd Parquet); est. single-digit GB/day |
| Compliance path for a controlled pilot | agreed with reviewers |

## Cost

Zero license cost (Apache/MIT tooling). No new servers. No new headcount — Phase 1 fits inside normal support capacity; if priorities don't allow it, the design simply waits.

The **no-server architecture is itself the cost story.** Scaling Elasticsearch means buying what is currently the most expensive hardware on the market: an always-on hot cluster of multiple dedicated nodes consumes RAM and compute around the clock, and both have seen sharp price inflation from AI-datacenter demand. This design consumes only **disk** — the cheap resource — on infrastructure we already run. The entire query engine runs comfortably in **4–8 cores and 8–16 GB of RAM on the existing Golden Host, only while a query executes** (design §13.1) — versus a permanent multi-node ES cluster; the incremental need is storage measured in single-digit GB per day (~1 TB/year at full retention). Typical investigation queries return in seconds (§13.1).

## Beyond single incidents: what accumulated history unlocks

Once daily files accumulate, the same directory of Parquet quietly becomes an analytical asset that Elasticsearch's ~7-day window can never be:

- **A year of order history, queryable in seconds** — incident patterns ("has this reject happened before?"), client-behavior questions, and month-over-month comparisons stop requiring warehouse requests and data-team round-trips; support answers them directly.
- **One-command investigations for RTB/support:** predefined wrapper scripts take a compliance ID and business date and emit the complete lifecycle ready for analysis — no SQL knowledge required for the standard cases. The whole toolkit is one portable executable plus scripts; nothing to install beyond copying it.
- **Data-driven platform operations:** accumulated per-shard, per-symbol, per-underlying volume statistics turn questions like re-sharding and capacity planning ahead of SpiderRock growth from guesswork into a query — using data we generated ourselves.
- **Storage is the cheapest resource in computing:** a full year of this data is roughly a terabyte — a quantity consumer cloud services sell for about ten dollars a month. Holding one terabyte on existing infrastructure is a trivial ask for the productivity it buys; the constraint has never been storage, only that the data was locked in unqueryable formats.

## Asks

1. **15 minutes** to review the design.
2. **No approvals needed to start:** the entire POC — including the production-scale benchmark on a copied day — runs in non-production. Golden Host installation and a disk quota (~1 TB/year at full retention) become asks only if the POC succeeds and Phase 3 is pursued.
3. **Confirmation DuckDB can be installed there** — fallback exists (Parquet is readable from approved Python/pyarrow), so the design does not live or die on one tool approval.
4. **A named sponsor** for the Phase 1 → Phase 2 decision once POC numbers are in.

## Why now

When SpiderRock volumes arrive, "search the messages" stops working as a support strategy. This closes that gap **before** it becomes an incident-review finding — using data we already store and tools that cost nothing.
