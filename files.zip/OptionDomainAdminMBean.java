package com.barcap.eq.oms.acl.jmx;

import com.barcap.eq.oms.domain.marketdata.OptionPricingDataSubscriptionService;

import javax.inject.Inject;
import javax.inject.Singleton;

/** Options-specific JMX admin operations (option pricing data subscriptions). */
@Singleton
public class OptionDomainAdminMBean extends DomainAdminMBean {

    private static final String INITIATED_CLEAR_OPTION_PRICING_SUBSCRIPTIONS =
            "Initiated clear of all cached option pricing data subscriptions";
    private static final String INITIATED_RESUBSCRIBE_ALL_OPTION_PRICING =
            "Initiated resubscribe of option pricing data for all cached ESMPs";
    private static final String INITIATED_SUBSCRIBE_OPTION_PRICING_FOR_ESMP =
            "Initiated option pricing data subscription for ESMP: ";

    @Inject
    private OptionPricingDataSubscriptionService optionPricingDataSubscriptionService;

    public String clearOptionPricingDataSubscriptions() {
        log.info("Mbean -executing clearOptionPricingDataSubscriptions");
        runOnMainThreadService.waitForCompletion(() ->
                optionPricingDataSubscriptionService.clearCachedSubscriptions());
        return INITIATED_CLEAR_OPTION_PRICING_SUBSCRIPTIONS;
    }

    public String resubscribeAllOptionPricingData() {
        log.info("Mbean -executing resubscribeAllOptionPricingData");
        runOnMainThreadService.waitForCompletion(() ->
                optionPricingDataSubscriptionService.resubscribe());
        return INITIATED_RESUBSCRIBE_ALL_OPTION_PRICING;
    }

    public String subscribeOptionPricingDataForEsmp(String esmp) {
        log.info("Mbean -executing subscribeOptionPricingDataForEsmp: esmp {}", esmp);
        runOnMainThreadService.waitForCompletion(() ->
                optionPricingDataSubscriptionService.resubscribe(esmp));
        return INITIATED_SUBSCRIBE_OPTION_PRICING_FOR_ESMP.concat(esmp);
    }
}
