package com.barcap.eq.oms.acl.jmx;

import com.barcap.eq.oms.domain.marketdata.OptionPricingDataSubscriptionService;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanParameterInfo;
import java.util.Arrays;

/** Options-specific JMX admin operations (option pricing data subscriptions). */
@Singleton
public class OptionDomainAdminMBean extends DomainAdminMBean {

    // Method names (must match the public method names below exactly)
    protected static final String CLEAR_OPTION_PRICING_SUBSCRIPTIONS_METHOD =
            "clearOptionPricingDataSubscriptions";
    protected static final String RESUBSCRIBE_ALL_OPTION_PRICING_METHOD =
            "resubscribeAllOptionPricingData";
    protected static final String SUBSCRIBE_OPTION_PRICING_FOR_ESMP_METHOD =
            "subscribeOptionPricingDataForEsmp";

    // Descriptions shown on the JMX page
    protected static final String CLEAR_OPTION_PRICING_SUBSCRIPTIONS_INFO =
            "Clears all cached option pricing data subscriptions.";
    protected static final String RESUBSCRIBE_ALL_OPTION_PRICING_INFO =
            "Re-sends option pricing data subscription requests for all cached ESMPs.";
    protected static final String SUBSCRIBE_OPTION_PRICING_FOR_ESMP_INFO =
            "Sends an option pricing data subscription request for the given ESMP.";

    // Return messages
    private static final String INITIATED_CLEAR_OPTION_PRICING_SUBSCRIPTIONS =
            "Initiated clear of all cached option pricing data subscriptions";
    private static final String INITIATED_RESUBSCRIBE_ALL_OPTION_PRICING =
            "Initiated resubscribe of option pricing data for all cached ESMPs";
    private static final String INITIATED_SUBSCRIBE_OPTION_PRICING_FOR_ESMP =
            "Initiated option pricing data subscription for ESMP: ";

    @Inject
    private OptionPricingDataSubscriptionService optionPricingDataSubscriptionService;

    public String clearOptionPricingDataSubscriptions() {
        log.info("Mbean -executing clearOptionPricingDataSubscriptions");
        runOnMainThreadService.waitForCompletion(() ->
                optionPricingDataSubscriptionService.clearCachedSubscriptions());
        return INITIATED_CLEAR_OPTION_PRICING_SUBSCRIPTIONS;
    }

    public String resubscribeAllOptionPricingData() {
        log.info("Mbean -executing resubscribeAllOptionPricingData");
        runOnMainThreadService.waitForCompletion(() ->
                optionPricingDataSubscriptionService.resubscribe());
        return INITIATED_RESUBSCRIBE_ALL_OPTION_PRICING;
    }

    public String subscribeOptionPricingDataForEsmp(String esmp) {
        log.info("Mbean -executing subscribeOptionPricingDataForEsmp: esmp {}", esmp);
        runOnMainThreadService.waitForCompletion(() ->
                optionPricingDataSubscriptionService.resubscribe(esmp));
        return INITIATED_SUBSCRIBE_OPTION_PRICING_FOR_ESMP.concat(esmp);
    }

    @Override
    protected MBeanOperationInfo[] createMBeanOperationInfo() {
        MBeanOperationInfo[] base = super.createMBeanOperationInfo();
        MBeanOperationInfo[] all = Arrays.copyOf(base, base.length + 3);
        all[base.length] = new MBeanOperationInfo(
                CLEAR_OPTION_PRICING_SUBSCRIPTIONS_METHOD,
                CLEAR_OPTION_PRICING_SUBSCRIPTIONS_INFO,
                new MBeanParameterInfo[]{},
                String.class.getName(), MBeanOperationInfo.ACTION);
        all[base.length + 1] = new MBeanOperationInfo(
                RESUBSCRIBE_ALL_OPTION_PRICING_METHOD,
                RESUBSCRIBE_ALL_OPTION_PRICING_INFO,
                new MBeanParameterInfo[]{},
                String.class.getName(), MBeanOperationInfo.ACTION);
        all[base.length + 2] = new MBeanOperationInfo(
                SUBSCRIBE_OPTION_PRICING_FOR_ESMP_METHOD,
                SUBSCRIBE_OPTION_PRICING_FOR_ESMP_INFO,
                new MBeanParameterInfo[]{
                        new MBeanParameterInfo("esmp", String.class.getName(),
                                "This is a required field - the ESMP of the product to subscribe option pricing data for.")
                },
                String.class.getName(), MBeanOperationInfo.ACTION);
        return all;
    }
}
