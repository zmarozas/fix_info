package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class PricingResponseHandlerTest extends BifrostTestSetup {

    @Mock private OptionPricingSnapshotPublisher publisher;

    private PricingResponseHandler handler;

    @Before
    public void setUp() {
        handler = new PricingResponseHandler(
                new ProductIdCodec(ENV_PREFIX),
                new PricingMessageTranslator(),
                publisher);
    }

    @Test
    public void testHandlePublishesOneSnapshotPerPricingResult() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O",  7.50, 0.55, 0.03))
                .addPricingResult(buildPricingResult(1, "bb_dev_MSFT.OQ", 12.30, 0.60, 0.04))
                .build();

        handler.handle(response);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher, times(2)).publish(captor.capture());

        List<IOptionPricingSnapshotMessage> snapshots = captor.getAllValues();

        IOptionPricingSnapshotMessage first = snapshots.get(0);
        assertEquals("AAPL.O", first.getRIC());
        assertEquals(SENDING_MILLIS, first.getSendingTimeAsTimestamp());
        assertEquals(7.50, first.getTheoValue(), EPSILON);
        assertEquals(0.55, first.getDelta(), EPSILON);
        assertEquals(0.03, first.getGamma(), EPSILON);

        IOptionPricingSnapshotMessage second = snapshots.get(1);
        assertEquals("MSFT.OQ", second.getRIC());
        assertEquals(SENDING_MILLIS, second.getSendingTimeAsTimestamp());
        assertEquals(12.30, second.getTheoValue(), EPSILON);
        assertEquals(0.60, second.getDelta(), EPSILON);
        assertEquals(0.04, second.getGamma(), EPSILON);
    }

    @Test
    public void testHandleDecodesProductIdToRecoverRic() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O", 7.50, 0.55, 0.03))
                .build();

        handler.handle(response);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher).publish(captor.capture());

        assertEquals("AAPL.O", captor.getValue().getRIC());
    }

    @Test
    public void testHandleSkipsPublishWhenTopLevelErrorPresent() {
        PricingResponse response = PricingResponse.newBuilder()
                .setError("BiFrost: invalid request")
                .setSendingTime(buildDate(SENDING_MILLIS))
                .build();

        handler.handle(response);

        verify(publisher, never()).publish(any());
    }

    @Test
    public void testHandleSkipsPublishWhenResultListEmpty() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .build();

        handler.handle(response);

        verify(publisher, never()).publish(any());
    }

    @Test
    public void testHandleSkipsResultWithPerResultError() {
        // First result has an error, second is fine - only second should publish.
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O",  7.50, 0.55, 0.03, "pricing failed", ""))
                .addPricingResult(buildPricingResult(1, "bb_dev_MSFT.OQ", 12.30, 0.60, 0.04))
                .build();

        handler.handle(response);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher, times(1)).publish(captor.capture());

        assertEquals("MSFT.OQ", captor.getValue().getRIC());
    }

    @Test
    public void testHandlePublishesResultWithWarningButNoError() {
        // Warning is non-fatal - we still publish.
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O", 7.50, 0.55, 0.03, "", "stale market data"))
                .build();

        handler.handle(response);

        verify(publisher, times(1)).publish(any());
    }
}
