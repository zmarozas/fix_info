package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;
import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResult;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.FirstOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.SecondOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Sociable test: mocks the boundary (Publisher to capture output) and uses
 * real ProductIdCodec and PricingMessageTranslator since both are pure logic
 * with their own dedicated tests.
 */
public class PricingResponseHandlerTest {

    private static final String ENV_PREFIX = "bb_dev";
    private static final long SENDING_MILLIS = 1735000000000L;
    private static final double EPSILON = 1e-6;

    @Mock private OptionPricingSnapshotPublisher publisher;

    private PricingResponseHandler handler;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        handler = new PricingResponseHandler(
                new ProductIdCodec(ENV_PREFIX),
                new PricingMessageTranslator(),
                publisher);
    }

    @Test
    public void testHandlePublishesOneSnapshotPerPricingResult() {
        PricingResponse response = PricingResponse.newBuilder()
                .setCorrelationId("corr-001")
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult("bb_dev_AAPL.O",  7.50, 0.55, 0.03))
                .addPricingResult(buildPricingResult("bb_dev_MSFT.OQ", 12.30, 0.60, 0.04))
                .build();

        handler.handle(response);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher, times(2)).publish(captor.capture());

        List<IOptionPricingSnapshotMessage> snapshots = captor.getAllValues();

        IOptionPricingSnapshotMessage first = snapshots.get(0);
        assertEquals("AAPL.O", first.getRIC());
        assertEquals(SENDING_MILLIS, first.getSendingTimeAsTimestamp());
        assertEquals(7.50, first.getTheoValue(), EPSILON);
        assertEquals(0.55, first.getDelta(), EPSILON);
        assertEquals(0.03, first.getGamma(), EPSILON);

        IOptionPricingSnapshotMessage second = snapshots.get(1);
        assertEquals("MSFT.OQ", second.getRIC());
        assertEquals(SENDING_MILLIS, second.getSendingTimeAsTimestamp());
        assertEquals(12.30, second.getTheoValue(), EPSILON);
        assertEquals(0.60, second.getDelta(), EPSILON);
        assertEquals(0.04, second.getGamma(), EPSILON);
    }

    @Test
    public void testHandleDecodesProductIdToRecoverRic() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult("bb_dev_AAPL.O", 7.50, 0.55, 0.03))
                .build();

        handler.handle(response);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher).publish(captor.capture());

        assertEquals("AAPL.O", captor.getValue().getRIC());
    }

    @Test
    public void testHandleSkipsPublishWhenTopLevelErrorPresent() {
        PricingResponse response = PricingResponse.newBuilder()
                .setError("BiFrost: invalid request")
                .setSendingTime(buildDate(SENDING_MILLIS))
                .build();

        handler.handle(response);

        verify(publisher, never()).publish(any());
    }

    @Test
    public void testHandleSkipsPublishWhenResultListEmpty() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .build();

        handler.handle(response);

        verify(publisher, never()).publish(any());
    }

    // --- helpers ---

    private static Date buildDate(long timestampMillis) {
        return Date.newBuilder()
                .setTimestamp(timestampMillis)
                .setTz("America/New_York")
                .build();
    }

    // ASSUMED PricingResult builder shape - if setProductId / setRiskProfile
    // method names differ, this test (and the handler) won't compile, which
    // is the fast feedback we want.
    private static PricingResult buildPricingResult(String productId,
                                                    double tv,
                                                    double delta,
                                                    double gamma) {
        return PricingResult.newBuilder()
                .setProductId(productId)
                .setRiskProfile(RiskProfile.newBuilder()
                        .setTv(tv)
                        .setFirstOrderGreeks(FirstOrdGreeks.newBuilder()
                                .setDelta(delta).build())
                        .setSecondOrderGreeks(SecondOrdGreeks.newBuilder()
                                .setGamma(gamma).build())
                        .build())
                .build();
    }
}
