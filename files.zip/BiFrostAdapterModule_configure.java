// BiFrostAdapterModule.configure() — full binding set with the missing IdGenerator added.
// The only change vs your current code is the IdGenerator binding (marked below).
// Guidance comments are for you — strip them before committing.

@Override
protected void configure() {
    Config config = appConfig.getConfig();

    for (Map.Entry<String, String> entry : ConfigurationConstants.loadProperties(config).entrySet()) {
        bind(entry.getValue()).named(entry.getKey()).to(String.class);
    }
    bind(config.getString(BifrostAdapter.Solace.REQUEST_TOPIC_PATTERN))
            .named(BifrostAdapter.Solace.REQUEST_TOPIC_PATTERN).to(String.class);
    bind(config.getString(BifrostAdapter.Solace.RESPONSE_SUBSCRIPTION))
            .named(BifrostAdapter.Solace.RESPONSE_SUBSCRIPTION).to(String.class);
    bind(config.getString(BifrostAdapter.Solace.GREEKS_SUBSCRIPTION))
            .named(BifrostAdapter.Solace.GREEKS_SUBSCRIPTION).to(String.class);

    bind(config.getString(BifrostAdapter.ENVIRONMENT_PREFIX))
            .named(BifrostAdapter.ENVIRONMENT_PREFIX_KEY).to(String.class);

    bind(OptionPricingSnapshotPublisherImpl.class).to(OptionPricingSnapshotPublisher.class).in(Singleton.class);
    bind(PricingRequestPublisherImpl.class).to(PricingRequestPublisher.class).in(Singleton.class);

    // ---- ADD: IdGenerator binding (the missing one) ----
    // Pick ONE form, based on what IdGenerator is (ctrl-click it to check):
    //
    // (A) interface + app impl  -> most likely; impl probably in your service package:
    bind(IdGeneratorImpl.class).to(IdGenerator.class).in(Singleton.class);
    //
    // (B) concrete class (no interface):
    // addActiveDescriptor(IdGenerator.class);
    //
    // (C) platform-provided instance:
    // bind(new <PlatformImpl>()).to(IdGenerator.class);
    // ----------------------------------------------------

    addActiveDescriptor(BifrostAdapter.class);
    addActiveDescriptor(BifrostInboundListener.class);
    addActiveDescriptor(EnvironmentPrefixTranslator.class);
    addActiveDescriptor(PricingMessageTranslator.class);
    addActiveDescriptor(PricingRequestHandler.class);
    addActiveDescriptor(PricingResponseHandler.class);
    addActiveDescriptor(RiskProfileUpdateHandler.class);
    addActiveDescriptor(SubscriptionRequestHandler.class);
    addActiveDescriptor(ShutdownMessageHandler.class);

    addActiveDescriptor(TimeServiceImpl.class);
    addActiveDescriptor(SystemStartTimeService.class);
    addActiveDescriptor(StartupEventHandler.class);
}
