/*
 * BLACKBIRD-55073 / meeting 7-23: TEMPORARY stub to unblock BB from BM.
 * Injects configured TargetPositionAccount / TargetSubBook as if BM had sent them
 * (position trading ROE not yet updated by Batman team).
 * When BM work is done: set ENABLE flag false, then DELETE all three configs + this code.
 *
 * ============================================================
 * 1) TradingConfigurationParameter enum — add three entries
 *    (names follow AMER_TO_EMEA_* / ENABLE_* conventions)
 * ============================================================
 */
//  ENABLE_AMER_TO_EMEA_TARGET_ACCOUNT_OVERRIDE,   // Boolean — master on/off
//  AMER_TO_EMEA_TARGET_POSITION_ACCOUNT,          // String  — sample target account
//  AMER_TO_EMEA_TARGET_SUB_BOOK,                  // String  — sample target sub book

/*
 * ============================================================
 * 2) TradingConfigurationProvider — add next to
 *    getAmerToEmeaTargetFundingDesks() (~line 614)
 * ============================================================
 */
public class TradingConfigurationProviderAdditions {

    // TEMPORARY (BLACKBIRD-55073): remove when BM sends real target values.
    public boolean isAmerToEmeaTargetAccountOverrideEnabled() {
        return getParameterValue(
                TradingConfigurationParameter.ENABLE_AMER_TO_EMEA_TARGET_ACCOUNT_OVERRIDE,
                /* defaultValue */ false);
    }

    // Sample target account for UAT/QA (pending real values from EMEA — Arun's ask).
    @Nullable
    public String getAmerToEmeaTargetPositionAccount() {
        return getParameterValue(
                TradingConfigurationParameter.AMER_TO_EMEA_TARGET_POSITION_ACCOUNT,
                (String) null);
    }

    @Nullable
    public String getAmerToEmeaTargetSubBook() {
        return getParameterValue(
                TradingConfigurationParameter.AMER_TO_EMEA_TARGET_SUB_BOOK,
                (String) null);
    }
}

/*
 * ============================================================
 * 3) Injection point — in the outgoing NOS (AMER -> EMEA) mapper,
 *    gated by the funding-trade spec so it can't leak elsewhere.
 *    Flag off => fields untouched (flow BM value or null).
 * ============================================================
 */
class TargetAccountOverrideSketch {
    void applyOverride(DeskOrder order, NewOrderSingleBuilder message) {
        // TEMPORARY (BLACKBIRD-55073)
        if (tradingConfigurationProvider.isAmerToEmeaTargetAccountOverrideEnabled()
                && amerToEmeaFundingTradeOrderSpecification.isSatisfiedBySourceOMS(order)) {
            message.targetPositionAccount(
                    tradingConfigurationProvider.getAmerToEmeaTargetPositionAccount());
            message.targetSubBook(
                    tradingConfigurationProvider.getAmerToEmeaTargetSubBook());
        }
    }
}

/*
 * ============================================================
 * 4) Test usage — set configs in test setup, assert on NOS + trade:
 *
 *    tradingConfig.set(ENABLE_AMER_TO_EMEA_TARGET_ACCOUNT_OVERRIDE, true);
 *    tradingConfig.set(AMER_TO_EMEA_TARGET_POSITION_ACCOUNT, "0010004513099"); // sample
 *    tradingConfig.set(AMER_TO_EMEA_TARGET_SUB_BOOK, "LDN-EFS-SUB1");          // sample
 *
 *    emeaDownstreamBlackbird.mustSee().newOrderSingle()
 *            .targetPositionAccount("0010004513099")
 *            .targetSubBook("LDN-EFS-SUB1")
 *            ...
 * ============================================================
 */
