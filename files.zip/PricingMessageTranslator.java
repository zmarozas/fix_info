package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;
import com.barclays.eq.roe.optionpricer.OptionPricerFactory;
// ROE enums live in xplatform - referenced by common-roe
import com.barcap.eq.integration.common.xplatform.PutOrCall;
import com.barcap.eq.integration.common.xplatform.ExerciseType;
import com.barcap.eq.integration.common.xplatform.SettlementCode;

// BiFrost protobuf - confirmed via IDE:
//   PricingRequest, ProductData -> PricingData
//   RiskProfile, FirstOrdGreeks, SecondOrdGreeks -> RiskpnlData
//   OptionType, OptionStyle, SettlementType, StrikeType, SecurityType, Date -> RiskMeta
import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;
import protobuf.com.barcap.eq.risk.flow.PricingData.ProductData;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.FirstOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.SecondOrdGreeks;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.OptionStyle;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.SettlementType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.StrikeType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.SecurityType;
import protobuf.com.barcap.eq.risk.flow.RiskMeta.Date;

import javax.inject.Singleton;

/**
 * Pure translator between Blackbird Trading ROE messages and BiFrost protobuf messages.
 * No I/O, no state, no clock - all side effects and non-determinism are the caller's job.
 * Fully unit-testable in isolation.
 */
@Singleton
public final class PricingMessageTranslator {

    private static final String DEFAULT_TIMEZONE = "America/New_York";

    /**
     * ROE subscription request -> BiFrost PricingRequest.
     * <p>
     * Caller supplies correlationId, productId (environment-prefixed RIC, see ProductIdCodec),
     * and underlyingName. SendingTime is read from the inbound ROE request.
     * <p>
     * SecurityType is hardcoded to LISTED_OPTION (this bridge only serves listed equity options).
     * StrikeType is hardcoded to STRIKE_ABSOLUTE per BiFrost docs example for vanilla options.
     * <p>
     * Note: BiFrost's PricingRequest accepts a batch (Products is a repeated field); we send one.
     */
    public PricingRequest toBifrostRequest(IOptionPricingSubscriptionRequestMessage req,
                                           String correlationId,
                                           String productId,
                                           String underlyingName) {
        ProductData product = ProductData.newBuilder()
                .setProductId(productId)
                .setSecurityType(SecurityType.LISTED_OPTION)
                .setUnderlyingName(underlyingName)
                .setUnderlyingRic(req.getUnderlyingRIC())
                .setStrike(req.getOptionStrikePrice())
                .setStrikeType(StrikeType.STRIKE_ABSOLUTE)
                .setExpiry(toBifrostDate(req.getExpireDateAsTimestamp()))
                .setOptionType(toBifrostOptionType(req.getPutOrCall()))
                .setOptionStyle(toBifrostOptionStyle(req.getExerciseType()))
                .setSettlementType(toBifrostSettlementType(req.getSettlementCode()))
                .build();

        return PricingRequest.newBuilder()
                .setCorrelationId(correlationId)
                .setSendingTime(toBifrostDate(req.getSendingTimeAsTimestamp()))
                .addProducts(product)
                .build();
    }

    /**
     * BiFrost RiskProfile -> ROE snapshot. Used for both the initial PricingResponse
     * (where caller passes response.getSendingTime()) and ongoing GREEKS updates
     * (where caller passes riskProfile.getPricingDate()).
     */
    public IOptionPricingSnapshotMessage toRoeSnapshot(String ric, RiskProfile rp, long sendingTimeMillis) {
        IOptionPricingSnapshotMessage snap = OptionPricerFactory.createOptionPricingSnapshotMessage();
        snap.setRIC(ric);
        snap.setSendingTimeAsTimestamp(sendingTimeMillis);
        snap.setTheoValue(rp.getTv());

        FirstOrdGreeks g1 = rp.getFirstOrderGreeks();
        snap.setDelta(g1.getDelta());
        snap.setVega(g1.getVega());
        snap.setTheta(g1.getTheta());
        snap.setCashRho(g1.getCashRho());
        snap.setBorrowRho(g1.getBorrowRho());
        snap.setDivRho(g1.getDivRho());

        SecondOrdGreeks g2 = rp.getSecondOrderGreeks();
        snap.setGamma(g2.getGamma());

        return snap;
    }

    // --- enum translation ---

    private static OptionType toBifrostOptionType(PutOrCall src) {
        // Note: PutOrCall enum constants are Pascal case (Put/Call), unlike the
        // other ROE enums (ExerciseType, SettlementCode) which are UPPER_CASE.
        switch (src) {
            case Put:  return OptionType.PUT;
            case Call: return OptionType.CALL;
            default:   throw new IllegalArgumentException("Unsupported PutOrCall: " + src);
        }
    }

    private static OptionStyle toBifrostOptionStyle(ExerciseType src) {
        switch (src) {
            case AMERICAN: return OptionStyle.AMERICAN;
            case EUROPEAN: return OptionStyle.EUROPEAN;
            default:       throw new IllegalArgumentException("Unsupported ExerciseType: " + src);
        }
    }

    private static SettlementType toBifrostSettlementType(SettlementCode src) {
        switch (src) {
            case PHYSICAL: return SettlementType.PHYSICAL;
            case CASH:     return SettlementType.CASH;
            default:       throw new IllegalArgumentException("Unsupported SettlementCode: " + src);
        }
    }

    private static Date toBifrostDate(long timestampMillis) {
        return Date.newBuilder()
                .setTimestamp(timestampMillis)
                .setTz(DEFAULT_TIMEZONE)
                .build();
    }
}
