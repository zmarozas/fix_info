package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barclays.eq.roe.optionpricer.OptionPricerFactory;
import com.barcap.eq.integration.common.xplatform.PutOrCall;
import com.barcap.eq.integration.common.xplatform.ExerciseType;
import com.barcap.eq.integration.common.xplatform.SettlementCode;
import com.barcap.eq.oms.util.idgenerator.IdGenerator;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;
import protobuf.com.barcap.eq.risk.flow.PricingData.ProductData;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class PricingRequestHandlerTest {

    private static final String FAKE_CORRELATION_ID = "corr-001";
    private static final long EXPIRY_MILLIS = 1735603200000L;
    private static final long SENDING_MILLIS = 1735000000000L;

    private CapturingPublisher publisher;
    private PricingRequestHandler handler;

    @Before
    public void setUp() {
        IdGenerator deterministicIdGenerator = new IdGenerator() {
            @Override
            public String createUniqueId() {
                return FAKE_CORRELATION_ID;
            }
        };
        publisher = new CapturingPublisher();
        handler = new PricingRequestHandler(
                deterministicIdGenerator,
                new ProductIdCodec(),
                new PricingMessageTranslator(),
                publisher);
    }

    @Test
    public void testHandlePublishesBifrostRequestWithEncodedProductId() {
        IOptionPricingSubscriptionRequestMessage req = buildRequest("AAPL.O", "AAPL.O");

        handler.handle(req);

        assertEquals(1, publisher.published.size());
        PricingRequest out = publisher.published.get(0);

        assertEquals(FAKE_CORRELATION_ID, out.getCorrelationId());
        assertEquals(1, out.getProductsCount());

        ProductData p = out.getProducts(0);
        assertEquals("AAPL.O|" + FAKE_CORRELATION_ID, p.getProductId());
        assertEquals("AAPL", p.getUnderlyingName());
        assertEquals("AAPL.O", p.getUnderlyingRic());
    }

    @Test
    public void testHandleEncodesRicIntoProductIdForStatelessRouting() {
        IOptionPricingSubscriptionRequestMessage req = buildRequest("MSFT.OQ", "MSFT.OQ");

        handler.handle(req);

        ProductData p = publisher.published.get(0).getProducts(0);
        assertEquals("MSFT.OQ|" + FAKE_CORRELATION_ID, p.getProductId());
        // round-trip via codec to confirm RIC is recoverable from ProductId
        assertEquals("MSFT.OQ", new ProductIdCodec().decode(p.getProductId()));
    }

    private static IOptionPricingSubscriptionRequestMessage buildRequest(String ric, String underlyingRic) {
        IOptionPricingSubscriptionRequestMessage req =
                OptionPricerFactory.createOptionPricingSubscriptionRequestMessage();
        req.setRIC(ric);
        req.setUnderlyingRIC(underlyingRic);
        req.setOptionStrikePrice(150.0);
        req.setExpireDateAsTimestamp(EXPIRY_MILLIS);
        req.setSendingTimeAsTimestamp(SENDING_MILLIS);
        req.setPutOrCall(PutOrCall.CALL);
        req.setExerciseType(ExerciseType.AMERICAN);
        req.setSettlementCode(SettlementCode.PHYSICAL);
        return req;
    }

    /** Capturing fake - no mocking framework needed. */
    private static final class CapturingPublisher implements PricingRequestPublisher {
        final List<PricingRequest> published = new ArrayList<>();

        @Override
        public void publish(PricingRequest request) {
            published.add(request);
        }
    }
}
