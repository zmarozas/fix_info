package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barclays.eq.roe.optionpricer.OptionPricerFactory;
import com.barcap.eq.integration.common.xplatform.PutOrCall;
import com.barcap.eq.integration.common.xplatform.ExerciseType;
import com.barcap.eq.integration.common.xplatform.SettlementCode;
import com.barcap.eq.oms.util.idgenerator.IdGenerator;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;
import protobuf.com.barcap.eq.risk.flow.PricingData.ProductData;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Sociable test: mocks the boundaries (IdGenerator for determinism, Publisher to capture output)
 * and uses real PricingMessageTranslator and ProductIdCodec since both are pure logic with
 * their own dedicated tests.
 */
public class PricingRequestHandlerTest {

    private static final String ENV_PREFIX = "bb_dev";
    private static final String FAKE_CORRELATION_ID = "corr-001";
    private static final long EXPIRY_MILLIS = 1735603200000L;
    private static final long SENDING_MILLIS = 1735000000000L;

    @Mock private IdGenerator idGenerator;
    @Mock private PricingRequestPublisher publisher;

    private PricingRequestHandler handler;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(idGenerator.createUniqueId()).thenReturn(FAKE_CORRELATION_ID);
        handler = new PricingRequestHandler(
                idGenerator,
                new ProductIdCodec(ENV_PREFIX),
                new PricingMessageTranslator(),
                publisher);
    }

    @Test
    public void testHandlePublishesBifrostRequestWithEncodedProductId() {
        IOptionPricingSubscriptionRequestMessage req = buildRequest("AAPL.O", "AAPL.O");

        handler.handle(req);

        ArgumentCaptor<PricingRequest> captor = ArgumentCaptor.forClass(PricingRequest.class);
        verify(publisher).publish(captor.capture());
        PricingRequest out = captor.getValue();

        assertEquals(FAKE_CORRELATION_ID, out.getCorrelationId());
        assertEquals(1, out.getProductsCount());

        ProductData p = out.getProducts(0);
        assertEquals("bb_dev_AAPL.O", p.getProductId());
        assertEquals("AAPL", p.getUnderlyingName());
        assertEquals("AAPL.O", p.getUnderlyingRic());
    }

    @Test
    public void testHandleEncodesRicIntoProductIdForStatelessRouting() {
        IOptionPricingSubscriptionRequestMessage req = buildRequest("MSFT.OQ", "MSFT.OQ");

        handler.handle(req);

        ArgumentCaptor<PricingRequest> captor = ArgumentCaptor.forClass(PricingRequest.class);
        verify(publisher).publish(captor.capture());
        ProductData p = captor.getValue().getProducts(0);

        assertEquals("bb_dev_MSFT.OQ", p.getProductId());
        // round-trip via codec to confirm RIC is recoverable from ProductId
        assertEquals("MSFT.OQ", new ProductIdCodec(ENV_PREFIX).decode(p.getProductId()));
    }

    private static IOptionPricingSubscriptionRequestMessage buildRequest(String ric, String underlyingRic) {
        IOptionPricingSubscriptionRequestMessage req =
                OptionPricerFactory.createOptionPricingSubscriptionRequestMessage();
        req.setRIC(ric);
        req.setUnderlyingRIC(underlyingRic);
        req.setOptionStrikePrice(150.0);
        req.setExpireDateAsTimestamp(EXPIRY_MILLIS);
        req.setSendingTimeAsTimestamp(SENDING_MILLIS);
        req.setPutOrCall(PutOrCall.CALL);
        req.setExerciseType(ExerciseType.AMERICAN);
        req.setSettlementCode(SettlementCode.PHYSICAL);
        return req;
    }
}
