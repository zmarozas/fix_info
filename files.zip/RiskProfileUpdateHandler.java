package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Handles per-cycle Greeks updates from BiFrost on Solace topic Pricing/GREEKS/...
 * Payload is a standalone RiskProfile; the ProductId is in the topic path
 * (Pricing/GREEKS/{UnderlyingName}/{ProductId}) and parsed by the listener.
 */
@Singleton
public final class RiskProfileUpdateHandler {

    private final ProductIdCodec productIdCodec;
    private final PricingMessageTranslator translator;
    private final OptionPricingSnapshotPublisher publisher;

    @Inject
    public RiskProfileUpdateHandler(ProductIdCodec productIdCodec,
                                    PricingMessageTranslator translator,
                                    OptionPricingSnapshotPublisher publisher) {
        this.productIdCodec = productIdCodec;
        this.translator = translator;
        this.publisher = publisher;
    }

    public void handle(String productId, RiskProfile riskProfile) {
        String ric;
        try {
            ric = productIdCodec.decode(productId);
        } catch (IllegalArgumentException e) {
            // TODO log foreign-env productId
            return;
        }

        long sendingTimeMillis = riskProfile.getPricingDate().getTimestamp();
        IOptionPricingSnapshotMessage snapshot =
                translator.toRoeSnapshot(ric, riskProfile, sendingTimeMillis);
        publisher.publish(snapshot);
    }
}
