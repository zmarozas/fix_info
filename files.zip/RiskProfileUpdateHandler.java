package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Handles per-cycle Greeks updates from BiFrost (Solace topic Pricing/GREEKS/...).
 * <p>
 * On this topic the payload is a raw {@code RiskpnlData.RiskProfile} - NOT wrapped
 * in a PricingResponse. The ProductId is carried in the topic path
 * ({@code Pricing/GREEKS/{UnderlyingName}/{ProductId}}), so the Solace listener
 * parses the topic and hands productId + RiskProfile to this handler.
 * <p>
 * Flow: validate prefix via codec -> RIC, take timestamp from
 * {@code RiskProfile.pricingDate}, translate, publish.
 */
@Singleton
public final class RiskProfileUpdateHandler {

    private final ProductIdCodec productIdCodec;
    private final PricingMessageTranslator translator;
    private final OptionPricingSnapshotPublisher publisher;

    @Inject
    public RiskProfileUpdateHandler(ProductIdCodec productIdCodec,
                                    PricingMessageTranslator translator,
                                    OptionPricingSnapshotPublisher publisher) {
        this.productIdCodec = productIdCodec;
        this.translator = translator;
        this.publisher = publisher;
    }

    /**
     * @param productId ProductId extracted from the Solace topic path
     * @param riskProfile The full RiskProfile payload from the message body
     */
    public void handle(String productId, RiskProfile riskProfile) {
        String ric;
        try {
            ric = productIdCodec.decode(productId);
        } catch (IllegalArgumentException e) {
            // ProductId doesn't match our env prefix - shouldn't normally happen
            // since the Solace bridge layer filters by prefix, but defend anyway.
            // TODO log
            return;
        }

        // RiskProfile carries its own pricingDate; use it as the snapshot timestamp.
        long sendingTimeMillis = riskProfile.getPricingDate().getTimestamp();

        IOptionPricingSnapshotMessage snapshot =
                translator.toRoeSnapshot(ric, riskProfile, sendingTimeMillis);

        publisher.publish(snapshot);
    }
}
