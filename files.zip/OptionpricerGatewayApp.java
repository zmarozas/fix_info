package com.barcap.eq.oms.optionpricergateway.launcher;

// Auto-import (Alt+Enter) the platform types, same ones your current launcher + stockloan's
// StockloanGatewayMain use: AppHAPolicy, AepEngine, ApexServerApplication, FirstTransactionTask,
// ApexConfiguration, SystemStartTimeService, StartupEventHandler, EngineProvider,
// AepEngineActiveEvent, JmxLoader, Binder, the @EventHandler annotation, and the shared
// ConfigurationComponentModule.

import com.barcap.eq.oms.optionpricergateway.module.BiFrostAdapterModule;
import com.barcap.eq.oms.server.bifrost.BifrostAdapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

import java.util.List;

@AppHAPolicy(AepEngine.HAPolicy.EventSourcing)
public class OptionpricerGatewayApp extends ApexServerApplication implements FirstTransactionTask {

    private static final Logger LOGGER = LoggerFactory.getLogger(OptionpricerGatewayApp.class);

    @Inject
    private SystemStartTimeService systemStartTimeService;

    @Inject
    private StartupEventHandler startupEventHandler;

    @Inject
    private EngineProvider engineProvider;

    @Inject
    private BifrostAdapter bifrostAdapter;

    // for IDE only
    public static void main(String[] args) {
        boolean isWin = System.getProperty("os.name").toLowerCase().startsWith("win");
        if (isWin) {
            System.setProperty("shard", "1");
            System.setProperty("appName", "optionpricer-gateway");
        }
        LOGGER.info("Starting optionpricer-gateway.");
        com.neeve.server.Main.main(args);
    }

    @Override
    protected void addApplicationModules(List<Binder> modules) {
        ApexConfiguration apexConfiguration = getApexConfiguration();
        modules.add(new BiFrostAdapterModule(apexConfiguration));
        // Shared platform module, mirrored from stockloan's launcher. Confirm it is needed
        // (e.g. it provides the injected ApexConfiguration); drop the line if optionpricer doesn't use it.
        modules.add(new ConfigurationComponentModule(apexConfiguration.getConfig()));
    }

    @Override
    public String getDescription() {
        return "OptionpricerGatewayApp";
    }

    @Override
    public void onFirstTransaction() throws Exception {
        systemStartTimeService.recordSystemStartTime();
        JmxLoader.startJmx(getApexConfiguration(), "optionpricerGateway");
        startupEventHandler.primaryOrBackupStartedSuccessfully();
    }

    // Stockloan starts its adapter from handle(StaticDataLoadedMessage) after async data load and
    // re-starts here on failover. This bridge has no static data, so the adapter is started when the
    // engine becomes active.
    // TODO confirm AepEngineActiveEvent fires on INITIAL primary startup, not only on failover.
    //      If it does not fire on initial startup, call startBifrostAdapter() from onFirstTransaction
    //      instead (it is already isPrimary-guarded).
    @EventHandler
    public void handle(AepEngineActiveEvent event) {
        startBifrostAdapter();
    }

    private void startBifrostAdapter() {
        if (!getEngine().isPrimary()) {
            LOGGER.info("Not starting BiFrost Adapter on backup/DR.");
            return;
        }
        LOGGER.info("Starting BiFrost Adapter.");
        try {
            bifrostAdapter.setup();
        } catch (Exception ex) {
            LOGGER.error("Failed to start BiFrost Adapter, exiting app", ex);
            engineProvider.getEngine().setAsLastTransaction(ex, true);
        }
    }
}
