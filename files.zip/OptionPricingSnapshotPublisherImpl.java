package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Outbound publisher back to Blackbird Trading via the Neeve apex bus.
 * TODO confirm ServiceFacade.process signature with Erb - stockloan uses
 *      service.process(msg, dynamicProperties) when routing to EMS via Solace,
 *      but our snapshots flow back to Blackbird on the apex bus and may not need
 *      dynamic properties.
 */
@Singleton
public class OptionPricingSnapshotPublisherImpl implements OptionPricingSnapshotPublisher {

    private final ServiceFacade service;

    @Inject
    public OptionPricingSnapshotPublisherImpl(ServiceFacade service) {
        this.service = service;
    }

    @Override
    public void publish(IOptionPricingSnapshotMessage snapshot) {
        service.process(snapshot);
    }
}
