package com.barcap.eq.oms.optionpricergateway.service;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import javax.inject.Inject;
import javax.inject.Singleton;
// MessageSender: com.neeve.toa.MessageSender

/**
 * Publishes OptionPricingSnapshot ROE back to Blackbird via the apex MessageSender.
 * The Snapshots channel (OPTION_PRICING/SNAPSHOT/${RIC}) templates its topic from the
 * message's RIC field, so no topic Properties are required.
 */
@Singleton
public class OptionPricingSnapshotPublisherImpl implements OptionPricingSnapshotPublisher {

    private final MessageSender messageSender;

    @Inject
    public OptionPricingSnapshotPublisherImpl(MessageSender messageSender) {
        this.messageSender = messageSender;
    }

    @Override
    public void publish(IOptionPricingSnapshotMessage snapshot) {
        messageSender.sendMessage(snapshot);
    }
}
