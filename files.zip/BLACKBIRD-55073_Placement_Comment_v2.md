## BLACKBIRD-55073 — Sales Trading ROE: final field placement

### Fields (per Arun)
- `TargetPositionAccount`
- `TargetSubBook`

Namespace `com.barclays.eq.roe.common.*`, added as **optional** `<fieldRef>`. Informational / pass-through (no booking impact, no validation). No POG.

### Placement — derived from where `PositionAccount` already lives (5 occurrences)
Existing pattern: `PositionAccount` rides on both order-side entities and trade-side messages; `SubBook` currently exists only in `ClientRequestedOrderGroup`. To satisfy "Orders **and** Fills / persisted across the full lifecycle", mirror `PositionAccount`:

| # | Location | Type | Add |
|---|----------|------|-----|
| 1 | `ClientRequestedOrderGroup` (entity 7999) | embedded | both |
| 2 | `OrderNewMessageDetails` (entity 8003) | embedded | both — **CONFIRM scope (order-new event leg)** |
| 3 | `TradeMessage` (id 20) | message, direct | both |
| 4 | `TradeCorrectMessage` (id 26) | message, direct | both |

**Automatic via the group (no separate edit):** `OrderCancelReplaceRequestMessage` (id 60) inlines `ClientRequestedOrderGroup` (line 297), so editing #1 covers it — plus NewOrderSingle, Cross, Multileg.

### Deliberately excluded
- `QuoteValidationRequestMessage` (id 32) — has `PositionAccount` but it's the Apollo/IRESS RSP RFQ flow, unrelated to funding swap orders/fills.
- Messages with no `PositionAccount` today (skipped to stay consistent): `OrderDoneMessageDetails` (8002), `OrderRestatedMessage` (12), `OrderRejectedMessage` (11), `OrderCanceledMessage` (15), `OrderCancelRejectMessage` (28).

### To confirm before merge
1. **`OrderNewMessageDetails` (8003)** — is the order-new event leg in scope? Adding it to truly mirror `PositionAccount`.
2. **`TradeCancelMessage` / Bust (id 27)** — has no `PositionAccount` today; should a busted trade still carry the target book/sub-book?
3. **common-model.xml** — `TargetPositionAccount` / `TargetSubBook` field **definitions** must be created (unique `id`, `type` matching existing `PositionAccount` / `SubBook`). This is the prerequisite for the `<fieldRef>` adds.

### Dependency
Schema change is independent and reviewable now. Populating **live** values depends on EQDS-4979 (EMEA Book & SubBook repo enabled in AMER). "Field support merged" ≠ "live values flowing".
