# Bruno env values — create `SOLQIN.BB.OPG.OPT.1` on `om_nyk_dev18`

Goal: create your app's durable input queue and add its two subscriptions, so the
gateway's flow bind stops failing with `UNKNOWN_QUEUE_NAME`.

You only touch **6 variables**. The other 10 are for bridge/cache/client requests
you are not running — leave them as-is.

## Variables to set

| Variable | Set to | Notes |
|---|---|---|
| **vpn** | `om_nyk_dev18` | Your DEV broker VPN. ✅ confirmed |
| **queue** | `SOLQIN.BB.OPG.OPT.1` | Your app's input queue. `OPT` because optionpricer's trading function is OPT (not HT). ✅ confirmed |
| **template** | ⚠️ **confirm** | Sets durable / exclusive / permissions. Sample shows `EQNPS`; the other runbook page showed `EQNFS` — they differ. Use whatever template the **EQ OMS input queues** use on `om_nyk_dev18`. Source it from the runbook, an existing input queue, or Mark. This is the one value that can give you the right name but still a queue your app can't bind. |
| **topic** | `Pricing/RESPONSE/>` then `Pricing/GREEKS/>` | One at a time. Used only by **Add Subscription**. Set it, Send, change it, Send again. |
| **user** | `om_nyk_dev18` (likely) | In DEV the username is normally the VPN name. The bus session you saw used `SESSION_USERNAME=om_nyk_dev18`. |
| **password** | blank, else `om_nyk_dev18` | The runbook shows a Kerberos ticket, so auth is probably Kerberos and password is unused — try blank first. If you get a 401, it's basic auth: use `om_nyk_dev18`. |

## Variables to ignore (leave the sample values)

These feed bridge / cache / client requests you are not running:

| Variable | Belongs to |
|---|---|
| discacheName, clusterName, instanceName | cache requests |
| bridgeQueue, bridgeTopic, bridgeName, destinationVpn, remoteSubscriptionTopic | bridge requests |
| msgId | delete-message requests |
| clientName | disconnect-client request |

## How to run

1. Set the 6 variables above → **Save**.
2. Open **POST Create Queue** → **Send**.
   - Success → queue created.
   - **403 / forbidden** → your user can't create queues on `om_nyk_dev18`. Stop here and hand it to Mark (the runbook's "check your access" link confirms). That's the infra ask, not a you-problem.
3. Open **POST Add Subscription** → set `topic = Pricing/RESPONSE/>` → **Send**. Then set `topic = Pricing/GREEKS/>` → **Send** again. (You were right: one topic per call.)
4. Verify in SolView: `om_nyk_dev18` → **Queues** → `SOLQIN.BB.OPG.OPT.1` should now exist, durable, with **2 subscriptions**.

## Then

Once **both** are true — `function = OPT` rebuilt/deployed, and `SOLQIN.BB.OPG.OPT.1`
exists with those two subscriptions — restart the app. The flow bind should finally
succeed, and the gateway stays up.

## The only two things that can still trip you

- **template** — wrong template = right queue name but wrong durability/permissions → app still won't bind.
- **auth** — if Create Queue returns 401/403, it's a credentials/access issue (Kerberos ticket, or no create rights), which flips this to Mark provisioning the queue instead.
