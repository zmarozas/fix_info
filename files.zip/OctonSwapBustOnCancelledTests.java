@Story(spec = "https://estjira.barcapint.com/browse/BLACKBIRD-55358")
@Test
public void testVenueBustOnCancelledOctonSwapOrdersDoesNotRestoreOpenQuantity() {

    puma.requestNewOrder().handlInst(Manual).send();
    OrderReference agencySalesRoot = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Root).reference();

    batman.takeOwnership(agencySalesRoot).send();
    batman.acceptRootOrder(agencySalesRoot).deskId(DRV_SALES).send();
    OrderReference agencySalesWave = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Wave).reference();

    batman.slice(agencySalesWave).deskId(null).targetDeskId(SWAP).send();
    OrderReference agencySalesSlice = batman.mustSee().order()
            .portfolioType(Agency).deskId(DRV_SALES).parentChildType(Child).reference();

    OrderReference swapAgencyRoot = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Root).deskId(SWAP)
            .state(PENDING_NEW).reference();

    OrderReference hedgeRoot = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Root).deskId(SWAP).reference();
    batman.acceptRootOrder(hedgeRoot).deskId(SWAP).send();
    OrderReference hedgeWave = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Wave).deskId(SWAP).reference();

    batman.slice(hedgeWave).targetCompID(zeroTouchSourceLocation).send();
    OrderReference venueSlice = batman.mustSee().order()
            .portfolioType(AffiliateHedge).parentChildType(Child).reference();

    zeroTouch.mustSee().newOrderSingle();
    ZeroTouchOrder ztOrder = zeroTouch.acceptOrder().send();
    zeroTouch.fillOrder(ztOrder).lastQty(100)
            .execID("123").origExecId("123")
            .tradeCaptureSystem("BBEMSZTNYK").tradeExecutionSystem("BBEMSZTNYK").send();

    batman.mustSee().order().orderID(venueSlice.orderID).cumQty(100).state(PARTIALLY_FILLED);

    batman.requestCancel(agencySalesSlice).send();
    batman.requestCancel(venueSlice).send();
    zeroTouch.acceptCancel(ztOrder).send();
    batman.acceptCancel(swapAgencyRoot).send();

    zeroTouch.bustExecution().execRefID("123").origExecRefId("123").send();

    batman.mustSee().order().orderID(venueSlice.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(hedgeWave.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(hedgeRoot.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().portfolioType(Agency).parentChildType(Child).deskId(SWAP)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().portfolioType(Agency).parentChildType(Wave).deskId(SWAP)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(swapAgencyRoot.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(agencySalesSlice.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);

    batman.mustSee().order().orderID(agencySalesRoot.orderID)
            .sentQty(0).openQty(1000);
}

@Story(spec = "https://estjira.barcapint.com/browse/BLACKBIRD-55358")
@Test
public void testBatmanBustOnCancelledOctonSwapOrdersDoesNotRestoreOpenQuantity() {

    puma.requestNewOrder().handlInst(Manual).send();
    OrderReference agencySalesRoot = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Root).reference();

    batman.takeOwnership(agencySalesRoot).send();
    batman.acceptRootOrder(agencySalesRoot).deskId(DRV_SALES).send();
    OrderReference agencySalesWave = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Wave).reference();

    batman.slice(agencySalesWave).deskId(null).targetDeskId(SWAP).send();
    OrderReference agencySalesSlice = batman.mustSee().order()
            .portfolioType(Agency).deskId(DRV_SALES).parentChildType(Child).reference();

    OrderReference swapAgencyRoot = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Root).deskId(SWAP)
            .state(PENDING_NEW).reference();

    OrderReference hedgeRoot = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Root).deskId(SWAP).reference();
    batman.acceptRootOrder(hedgeRoot).deskId(SWAP).send();
    OrderReference hedgeWave = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Wave).deskId(SWAP).reference();

    batman.slice(hedgeWave).targetCompID(zeroTouchSourceLocation).send();
    OrderReference venueSlice = batman.mustSee().order()
            .portfolioType(AffiliateHedge).parentChildType(Child).reference();

    zeroTouch.mustSee().newOrderSingle();
    ZeroTouchOrder ztOrder = zeroTouch.acceptOrder().send();
    zeroTouch.fillOrder(ztOrder).lastQty(100)
            .execID("123").origExecId("123")
            .tradeCaptureSystem("BBEMSZTNYK").tradeExecutionSystem("BBEMSZTNYK").send();

    batman.mustSee().order().orderID(venueSlice.orderID).cumQty(100).state(PARTIALLY_FILLED);

    batman.requestCancel(agencySalesSlice).send();
    batman.requestCancel(venueSlice).send();
    zeroTouch.acceptCancel(ztOrder).send();
    batman.acceptCancel(swapAgencyRoot).send();

    batman.bustExecution().orderID(hedgeRoot.orderID).origExecID("123").send();

    batman.mustSee().order().orderID(venueSlice.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(hedgeWave.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(hedgeRoot.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().portfolioType(Agency).parentChildType(Child).deskId(SWAP)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().portfolioType(Agency).parentChildType(Wave).deskId(SWAP)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(swapAgencyRoot.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(agencySalesSlice.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);

    batman.mustSee().order().orderID(agencySalesRoot.orderID)
            .sentQty(0).openQty(1000);
}
