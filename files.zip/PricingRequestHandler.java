package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barcap.eq.oms.util.idgenerator.IdGenerator;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Inbound handler for Blackbird Trading option pricing subscription requests.
 * <p>
 * For each incoming ROE request, generates a correlation id and a product id
 * (which encodes the RIC for stateless routing of updates back to Blackbird),
 * translates the message to BiFrost protobuf, and publishes it.
 * <p>
 * The handler holds no per-subscription state - all routing information is
 * encoded into the ProductId, which BiFrost echoes back on every update.
 */
@Singleton
public final class PricingRequestHandler {

    private final IdGenerator idGenerator;
    private final ProductIdCodec productIdCodec;
    private final PricingMessageTranslator translator;
    private final PricingRequestPublisher publisher;

    @Inject
    public PricingRequestHandler(IdGenerator idGenerator,
                                 ProductIdCodec productIdCodec,
                                 PricingMessageTranslator translator,
                                 PricingRequestPublisher publisher) {
        this.idGenerator = idGenerator;
        this.productIdCodec = productIdCodec;
        this.translator = translator;
        this.publisher = publisher;
    }

    /**
     * Handle an inbound subscription request from Blackbird Trading.
     * Wires to the Neeve ROE pipeline via the inbound channel binding.
     */
    public void handle(IOptionPricingSubscriptionRequestMessage request) {
        String correlationId = idGenerator.createUniqueId();
        String ric = request.getRIC();
        String productId = productIdCodec.encode(ric, correlationId);
        String underlyingName = deriveUnderlyingName(request.getUnderlyingRIC());

        PricingRequest bifrostRequest =
                translator.toBifrostRequest(request, correlationId, productId, underlyingName);

        publisher.publish(bifrostRequest);
    }

    /**
     * Derive the BiFrost underlying name from a RIC.
     * <p>
     * TODO confirm with Bapu - this is a placeholder. The ROE only carries
     * UnderlyingRIC (e.g. "AAPL.O"), while BiFrost expects an underlying name.
     * Naive impl strips the venue suffix; real impl may need a lookup.
     */
    private static String deriveUnderlyingName(String underlyingRic) {
        if (underlyingRic == null) {
            return null;
        }
        int dotIdx = underlyingRic.indexOf('.');
        return dotIdx > 0 ? underlyingRic.substring(0, dotIdx) : underlyingRic;
    }
}
