package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSubscriptionRequestMessage;
import com.barcap.eq.oms.util.idgenerator.IdGenerator;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingRequest;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Inbound handler: Blackbird ROE subscription request -> BiFrost PricingRequest.
 * Stateless - RIC is encoded into the ProductId via the codec; BiFrost echoes it back.
 */
@Singleton
public final class PricingRequestHandler {

    private final IdGenerator idGenerator;
    private final ProductIdCodec productIdCodec;
    private final PricingMessageTranslator translator;
    private final PricingRequestPublisher publisher;

    @Inject
    public PricingRequestHandler(IdGenerator idGenerator,
                                 ProductIdCodec productIdCodec,
                                 PricingMessageTranslator translator,
                                 PricingRequestPublisher publisher) {
        this.idGenerator = idGenerator;
        this.productIdCodec = productIdCodec;
        this.translator = translator;
        this.publisher = publisher;
    }

    public void handle(IOptionPricingSubscriptionRequestMessage request) {
        String correlationId = idGenerator.createUniqueId();
        String ric = request.getRIC();
        String productId = productIdCodec.encode(ric);
        String underlyingName = deriveUnderlyingName(request.getUnderlyingRIC());

        PricingRequest bifrostRequest =
                translator.toBifrostRequest(request, correlationId, productId, underlyingName);

        publisher.publish(bifrostRequest);
    }

    // TODO confirm with Bapu - naive strip-suffix vs static-data lookup.
    private static String deriveUnderlyingName(String underlyingRic) {
        if (underlyingRic == null) {
            return null;
        }
        int dotIdx = underlyingRic.indexOf('.');
        return dotIdx > 0 ? underlyingRic.substring(0, dotIdx) : underlyingRic;
    }
}
