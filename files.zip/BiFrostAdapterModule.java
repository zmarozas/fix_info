package com.barcap.eq.oms.module;

import com.barclays.eq.apex.config.ApexConfiguration;

import com.typesafe.config.Config;

import com.barcap.eq.oms.server.bifrost.BifrostAdapter;
import com.barcap.eq.oms.server.bifrost.BifrostInboundListener;
import com.barcap.eq.oms.server.bifrost.OptionPricingSnapshotPublisher;
import com.barcap.eq.oms.server.bifrost.PricingMessageTranslator;
import com.barcap.eq.oms.server.bifrost.PricingRequestHandler;
import com.barcap.eq.oms.server.bifrost.PricingRequestPublisher;
import com.barcap.eq.oms.server.bifrost.PricingRequestPublisherImpl;
import com.barcap.eq.oms.server.bifrost.PricingResponseHandler;
import com.barcap.eq.oms.server.bifrost.ProductIdCodec;
import com.barcap.eq.oms.server.bifrost.RiskProfileUpdateHandler;
import com.barcap.eq.oms.server.bifrost.SubscriptionRequestHandler;
import com.barcap.eq.oms.service.OptionPricingSnapshotPublisherImpl;

import org.glassfish.hk2.utilities.binding.AbstractBinder;

import javax.inject.Singleton;

/**
 * Bindings for the optionpricer-gateway. Mirrors stockloan's MagicsAdapterModule: @Named Solace
 * config strings, publisher interface-to-impl, and the @Managed beans. No StaticDataBinder -
 * this bridge is stateless.
 */
public class BiFrostAdapterModule extends AbstractBinder {

    private final ApexConfiguration appConfig;

    public BiFrostAdapterModule(ApexConfiguration config) {
        this.appConfig = config;
    }

    @Override
    protected void configure() {
        Config config = appConfig.getConfig();

        // The BifrostAdapter.Solace.* constant is both the config path and the @Named qualifier
        // (see PricingRequestPublisherImpl and BifrostInboundListener).
        bind(config.getString(BifrostAdapter.Solace.REQUEST_TOPIC_PATTERN))
                .named(BifrostAdapter.Solace.REQUEST_TOPIC_PATTERN).to(String.class);
        bind(config.getString(BifrostAdapter.Solace.RESPONSE_SUBSCRIPTION))
                .named(BifrostAdapter.Solace.RESPONSE_SUBSCRIPTION).to(String.class);
        bind(config.getString(BifrostAdapter.Solace.GREEKS_SUBSCRIPTION))
                .named(BifrostAdapter.Solace.GREEKS_SUBSCRIPTION).to(String.class);

        bind(OptionPricingSnapshotPublisherImpl.class).to(OptionPricingSnapshotPublisher.class).in(Singleton.class);
        bind(PricingRequestPublisherImpl.class).to(PricingRequestPublisher.class).in(Singleton.class);

        addActiveDescriptor(BifrostAdapter.class);
        addActiveDescriptor(BifrostInboundListener.class);
        addActiveDescriptor(ProductIdCodec.class);
        addActiveDescriptor(PricingMessageTranslator.class);
        addActiveDescriptor(PricingRequestHandler.class);
        addActiveDescriptor(PricingResponseHandler.class);
        addActiveDescriptor(RiskProfileUpdateHandler.class);
        addActiveDescriptor(SubscriptionRequestHandler.class);

        // TODO not yet bound: @Named("bifrost.timezone") for PricingMessageTranslator. Add either
        //   bind(config.getString("environment.timeZone")).named("bifrost.timezone").to(String.class);
        //   (match PROD key casing) OR switch the translator to inject TimeZoneService.
        // TODO add if DI cannot resolve the launcher-injected services:
        //   addActiveDescriptor(TimeServiceImpl.class);
        //   addActiveDescriptor(SystemStartTimeService.class);
        //   addActiveDescriptor(StartupEventHandler.class);
    }
}
