package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.apex.EngineProvider;
import com.barclays.eq.roe.optionpricer.OptionPricingSubscriptionRequestMessage;

import com.neeve.aep.annotations.EventHandler;
import com.neeve.managed.annotations.Managed;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Inbound Blackbird ROE subscription request handler. Mirrors stockloan's
 * EBorrowRequestMessageHandler: only the primary engine acts, then delegates to PricingRequestHandler.
 */
@Managed
@Singleton
public class SubscriptionRequestHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(SubscriptionRequestHandler.class);

    private final PricingRequestHandler pricingRequestHandler;
    private final EngineProvider aepEngine;

    @Inject
    public SubscriptionRequestHandler(PricingRequestHandler pricingRequestHandler,
                                      EngineProvider aepEngine) {
        this.pricingRequestHandler = pricingRequestHandler;
        this.aepEngine = aepEngine;
    }

    @EventHandler
    public void handle(OptionPricingSubscriptionRequestMessage message) {
        if (!aepEngine.getEngine().isPrimary()) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Ignoring subscription request, engine is not primary: {}", message);
            }
            return;
        }
        pricingRequestHandler.handle(message);
    }
}
