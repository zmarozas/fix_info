package com.barcap.eq.oms.server.bifrost;

import com.google.protobuf.InvalidProtocolBufferException;

import com.solacesystems.jcsmp.BytesXMLMessage;
import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.JCSMPFactory;
import com.solacesystems.jcsmp.JCSMPSession;
import com.solacesystems.jcsmp.Topic;
import com.solacesystems.jcsmp.XMLMessageConsumer;
import com.solacesystems.jcsmp.XMLMessageListener;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

/**
 * Subscribes to BiFrost Solace topics and routes inbound messages to the business handlers.
 * - Pricing/RESPONSE/> -> PricingResponse protobuf -> PricingResponseHandler
 * - Pricing/GREEKS/{UnderlyingName}/{ProductId} -> standalone RiskProfile protobuf -> RiskProfileUpdateHandler
 */
@Singleton
public class BifrostInboundListener {

    private static final String RESPONSE_TOPIC_PREFIX = "Pricing/RESPONSE/";
    private static final String GREEKS_TOPIC_PREFIX   = "Pricing/GREEKS/";

    private final Logger logger = LoggerFactory.getLogger(BifrostInboundListener.class);

    private final PricingResponseHandler pricingResponseHandler;
    private final RiskProfileUpdateHandler riskProfileUpdateHandler;

    @Inject @Named(BifrostAdapter.Solace.RESPONSE_SUBSCRIPTION)
    private String responseSubscription;

    @Inject @Named(BifrostAdapter.Solace.GREEKS_SUBSCRIPTION)
    private String greeksSubscription;

    private XMLMessageConsumer consumer;

    @Inject
    public BifrostInboundListener(PricingResponseHandler pricingResponseHandler,
                                  RiskProfileUpdateHandler riskProfileUpdateHandler) {
        this.pricingResponseHandler = pricingResponseHandler;
        this.riskProfileUpdateHandler = riskProfileUpdateHandler;
    }

    public void setup(JCSMPSession session) throws JCSMPException {
        consumer = session.getMessageConsumer(new XMLMessageListener() {
            @Override
            public void onReceive(BytesXMLMessage msg) {
                dispatch(msg);
            }
            @Override
            public void onException(JCSMPException ex) {
                logger.error("BiFrost solace consumer error", ex);
            }
        });

        session.addSubscription(JCSMPFactory.onlyInstance().createTopic(responseSubscription));
        session.addSubscription(JCSMPFactory.onlyInstance().createTopic(greeksSubscription));

        consumer.start();
        logger.info("BiFrost solace inbound listener started, subscriptions: [{}, {}]",
                responseSubscription, greeksSubscription);
    }

    public void shutdown() {
        if (consumer != null) {
            consumer.close();
        }
    }

    // TODO confirm with Erb: thread-bridging from Solace I/O thread to apex thread.
    // Stockloan uses ADM-generated Schedule* messages via service.enqueueMessage(),
    // then a @Managed @Singleton with @EventHandler picks them up on apex thread.
    // We don't have Schedule* defined yet for pricing. If Erb confirms we need them,
    // this method becomes: build SchedulePricingResponseMessage / ScheduleRiskProfileUpdateMessage,
    // call service.enqueueMessage(...), and move the parseFrom + handler.handle() into
    // new SchedulePricingResponseMessageHandler / ScheduleRiskProfileUpdateMessageHandler.
    private void dispatch(BytesXMLMessage msg) {
        String topicName = msg.getDestination().getName();
        byte[] payload = msg.getBytes();

        try {
            if (topicName.startsWith(RESPONSE_TOPIC_PREFIX)) {
                PricingResponse response = PricingResponse.parseFrom(payload);
                pricingResponseHandler.handle(response);
            } else if (topicName.startsWith(GREEKS_TOPIC_PREFIX)) {
                String productId = extractProductIdFromGreeksTopic(topicName);
                RiskProfile riskProfile = RiskProfile.parseFrom(payload);
                riskProfileUpdateHandler.handle(productId, riskProfile);
            } else {
                logger.warn("Received message on unexpected topic: {}", topicName);
            }
        } catch (InvalidProtocolBufferException e) {
            logger.error("Failed to parse protobuf payload, topic: {}", topicName, e);
        } catch (RuntimeException e) {
            logger.error("Error dispatching inbound BiFrost message, topic: {}", topicName, e);
        }
    }

    private static String extractProductIdFromGreeksTopic(String topicName) {
        String afterPrefix = topicName.substring(GREEKS_TOPIC_PREFIX.length());
        int slashIdx = afterPrefix.indexOf('/');
        if (slashIdx < 0 || slashIdx == afterPrefix.length() - 1) {
            throw new IllegalArgumentException("Invalid GREEKS topic format: " + topicName);
        }
        return afterPrefix.substring(slashIdx + 1);
    }
}
