package com.barcap.eq.oms.optionpricergateway.service;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.verify;
// MessageSender: com.neeve.toa.MessageSender

public class OptionPricingSnapshotPublisherImplTest {

    @Mock private MessageSender messageSender;
    @Mock private IOptionPricingSnapshotMessage snapshot;

    private OptionPricingSnapshotPublisherImpl publisher;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        publisher = new OptionPricingSnapshotPublisherImpl(messageSender);
    }

    @Test
    public void testPublishSendsSnapshotToMessageSender() {
        publisher.publish(snapshot);
        verify(messageSender).sendMessage(snapshot);
    }
}
