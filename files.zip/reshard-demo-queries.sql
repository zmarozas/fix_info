-- Resharding demo queries — run in DuckDB CLI against the BBEMSOPTNYK dump
-- Adjust the path to wherever the xlsx sits.

-- Q1: current shard balance (BBEMSOPTNYK vs BBEMSOPTNYK-1)
SELECT pusblishingsystem,
       SUM("count(1)") AS orders,
       ROUND(100.0 * SUM("count(1)") / SUM(SUM("count(1)")) OVER (), 1) AS pct
FROM "C:\work\data_dump\BBEMSOPTNYK.xlsx"
GROUP BY 1
ORDER BY 2 DESC;

-- Q2: proposed rebalance by underlying (round-robin over descending volume)
-- Change % 2 to % 3 to model adding a shard.
WITH per_und AS (
  SELECT regexp_extract(symbol, '^[A-Za-z]+') AS underlying,
         SUM("count(1)") AS orders
  FROM "C:\work\data_dump\BBEMSOPTNYK.xlsx"
  GROUP BY 1
),
ranked AS (
  SELECT *, row_number() OVER (ORDER BY orders DESC) AS rn
  FROM per_und
)
SELECT ((rn - 1) % 2) + 1 AS proposed_shard,
       COUNT(*)   AS underlyings,
       SUM(orders) AS shard_load
FROM ranked
GROUP BY 1
ORDER BY 1;

-- Q2b: actual symbol -> shard assignment list (what Shubham was asked to produce)
WITH per_und AS (
  SELECT regexp_extract(symbol, '^[A-Za-z]+') AS underlying,
         SUM("count(1)") AS orders
  FROM "C:\work\data_dump\BBEMSOPTNYK.xlsx"
  GROUP BY 1
),
ranked AS (
  SELECT *, row_number() OVER (ORDER BY orders DESC) AS rn
  FROM per_und
)
SELECT underlying,
       orders,
       ((rn - 1) % 2) + 1 AS proposed_shard
FROM ranked
ORDER BY orders DESC;

-- Caveats to state in the demo:
-- 1) "underlying" here = leading letters of the option symbol — verify this matches
--    the real sharding key.
-- 2) Round-robin by rank is an approximation, not optimal bin-packing — fine for
--    a distribution proposal.
