package com.barcap.eq.oms.server.bifrost;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ProductIdCodecTest {

    private final ProductIdCodec codec = new ProductIdCodec();

    @Test
    public void testEncodeJoinsRicAndSuffix() {
        assertEquals("AAPL.O|corr-123", codec.encode("AAPL.O", "corr-123"));
    }

    @Test
    public void testDecodeReturnsRicPortion() {
        assertEquals("AAPL.O", codec.decode("AAPL.O|corr-123"));
    }

    @Test
    public void testRoundTripPreservesRic() {
        String ric = "MSFT.OQ";
        assertEquals(ric, codec.decode(codec.encode(ric, "abc-456")));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEncodeRejectsNullRic() {
        codec.encode(null, "suffix");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEncodeRejectsEmptyRic() {
        codec.encode("", "suffix");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEncodeRejectsNullSuffix() {
        codec.encode("AAPL.O", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEncodeRejectsEmptySuffix() {
        codec.encode("AAPL.O", "");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEncodeRejectsRicWithDelimiter() {
        codec.encode("BAD|RIC", "suffix");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEncodeRejectsSuffixWithDelimiter() {
        codec.encode("AAPL.O", "bad|suffix");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDecodeRejectsNull() {
        codec.decode(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDecodeRejectsEmpty() {
        codec.decode("");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDecodeRejectsMalformedProductId() {
        codec.decode("no-delimiter-here");
    }
}
