package com.barcap.eq.oms.server.bifrost;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ProductIdCodecTest extends BifrostTestSetup {

    private final ProductIdCodec codec = new ProductIdCodec(ENV_PREFIX);

    @Test
    public void testEncodePrependsPrefixAndDelimiter() {
        assertEquals("bb_dev_AAPL.O", codec.encode("AAPL.O"));
    }

    @Test
    public void testDecodeStripsPrefix() {
        assertEquals("AAPL.O", codec.decode("bb_dev_AAPL.O"));
    }

    @Test
    public void testRoundTripPreservesRic() {
        assertEquals("MSFT.OQ", codec.decode(codec.encode("MSFT.OQ")));
    }

    @Test
    public void testRicWithMultipleDotsIsPreserved() {
        assertEquals("BRK.B.N", codec.decode(codec.encode("BRK.B.N")));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsNullPrefix() {
        new ProductIdCodec(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsEmptyPrefix() {
        new ProductIdCodec("");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEncodeRejectsNullRic() {
        codec.encode(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEncodeRejectsEmptyRic() {
        codec.encode("");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDecodeRejectsNull() {
        codec.decode(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDecodeRejectsEmpty() {
        codec.decode("");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDecodeRejectsProductIdWithWrongPrefix() {
        // bb_qa_ doesn't match the bb_dev_ prefix configured by the base
        codec.decode("bb_qa_AAPL.O");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDecodeRejectsProductIdWithoutPrefix() {
        codec.decode("AAPL.O");
    }
}
