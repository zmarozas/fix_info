package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

/**
 * Publishes an {@link IOptionPricingSnapshotMessage} back to Blackbird Trading
 * via the ROE pipeline.
 * <p>
 * The publisher owns the wire concern (channel selection, serialization); upstream
 * code only hands it a fully-built ROE message. The snapshot's RIC determines the
 * outbound topic per the ROE service definition.
 */
public interface OptionPricingSnapshotPublisher {

    /**
     * Publish a pricing snapshot to Blackbird Trading.
     */
    void publish(IOptionPricingSnapshotMessage snapshot);
}
