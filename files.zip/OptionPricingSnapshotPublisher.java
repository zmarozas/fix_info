package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

public interface OptionPricingSnapshotPublisher {
    void publish(IOptionPricingSnapshotMessage snapshot);
}
