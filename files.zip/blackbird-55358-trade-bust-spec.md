# Trade Bust Quantity Handling — Current Behaviour and Proposed Fix

**Jira:** BLACKBIRD-55358 · **Incident:** INC1040558889 (30 Jul 2026) · **Status:** Proposal — implementation in progress, one design question deferred (see §6)

---

## 1. Context

On 30 Jul 2026 a venue trade bust (ExecType=TRADE_CANCEL) arrived on a child order whose desk hierarchy had already been cancelled. Blackbird reversed the executions correctly, but the reversal pushed the busted quantity back into `LeavesQty` on the **cancelled** Wave and Root. The result: cancelled orders showing 25,000 shares working, flagged Invalid downstream (Batman expects `OpenQty = SentQty = 0` on Cancelled), phantom quantity propagating to the parent blotter, and ~84 minutes in a bad state until the service desk manually released the quantity.

Both scenarios below are reproduced in automated tests (`SalesDeskTradeBustingTest`, branch `bugfix/BLACKBIRD-55358`). Test quantities are used throughout; the production analog was a 25,000 street leg under a 52,577 inter-desk order.

## 2. Shared scenario

```
Puma order 1500
  -> CASH-SALES desk: Root / Wave
     -> sales Child slices 1500 to CASH desk
        -> CASH desk: Root / Wave
           -> cash Child slices 1000 to street (CMA, XNYS floor brokers)
              -> street fills 100
              -> venue busts the 100 (ExecType=TRADE_CANCEL)
```

## 3. Scenario A — bust on a LIVE (partially filled) order

Test: `testBustedTradesOnPartiallyFilledOrders` — **passing**. This is current behaviour and it is correct; it is the regression guard for any fix.

| Level | After fill of 100 | After bust (current = correct) |
|---|---|---|
| Street child (1000) | cum 100, leaves 900 | **NEW, cum 0, leaves 900** |
| CASH Wave / Root (1500) | cum 100, leaves 1400 | NEW, cum 0, leaves 1500 |
| CASH-SALES child (1500) | cum 100, leaves 1400 | NEW, cum 0, leaves 1500 |
| CASH-SALES Root (1500) | sent 1500, open 0 | sent 1500, open 0 |

Semantics: the bust reverses `CumQty` at every level and states revert to NEW (`ReinstatedQuantity=true` on the TradeCancel event). The busted quantity is returned to the **desk chain** — parents re-open to full size. It is **not** re-opened on the street-facing child (leaves stays 900): the shares are no longer live at the venue, and the trader re-slices if wanted.

## 4. Scenario B — bust on a CANCELLED leg (the defect)

Test: `testBustedTradesOnCancelledOrdersShouldNotRestoreOpenQuantity` — **failing by design**; its assertions encode the expected behaviour.

Sequence: after the fill of 100, the sales slice, the street slice and the CASH hierarchy are cancelled (cancel correctly zeroes leaves everywhere), then the bust arrives.

| Level | After cancel (correct) | After bust — CURRENT (defective) | After bust — EXPECTED |
|---|---|---|---|
| Street child | CANCELLED, leaves 0 | CANCELLED, cum 0, leaves 0 ✓ | CANCELLED, leaves 0 |
| CASH Wave | CANCELLED, leaves 0 | **CANCELLED, cum 0, leaves 100 ✗** | CANCELLED, leaves 0 |
| CASH Root | CANCELLED, leaves 0 | **CANCELLED, leaves 100 ✗** | CANCELLED, leaves 0 |
| CASH-SALES child | CANCELLED, leaves 0 | **CANCELLED, leaves 100 ✗** | CANCELLED, leaves 0 |
| CASH-SALES Root (live) | sent 100, open 1400 | sent 100, open 1400 — busted 100 stranded | unchanged for now (see §6) |

Test failure evidence (LocatorException at the Wave assertion):

```
WaveOrder CANCELLED  OrderQty=1500.0  LeavesQty=100.0  CumQty=0.0  SentQty=0.0  OpenQty=0.0
Expected: leavesQty 0.0
```

Production consequences of the current behaviour: FIX terminal-state invariant violated; downstream (Batman) validation breached, order flagged Invalid; phantom working quantity visible on the parent blotter; manual service-desk `ReleaseQuantity` required to clear it.

## 5. Root cause

The bust reversal arithmetic itself is correct (`CumQty + LeavesQty` conserved at every step). The defect is in the **parent roll-up**: when a child bust rolls up, Wave/Root add the busted quantity back into their own `LeavesQty` without checking their **own** `OrdStatus`. The street-facing child behaves correctly in both scenarios; only the aggregation path is cancel-state-blind.

## 6. Proposed fix

**Rule: reinstatement is state-aware.** When the order receiving a bust roll-up is in a terminal state, hold `LeavesQty` at 0 — do not reinstate quantity onto dead orders.

- Terminal states in scope: CANCELLED, EXPIRED, REJECTED, DONE_FOR_DAY.
- Explicitly **out of scope**: FILLED (a bust on a filled order should revive it — live-order semantics) and PENDING_CANCEL (in-flight, treated as live). Edge cases to confirm in code review.
- Change is confined to the roll-up / reinstatement path; the live-order path (Scenario A) is untouched.
- Acceptance criterion: the dead-level assertions of `testBustedTradesOnCancelledOrdersShouldNotRestoreOpenQuantity` go green; `testBustedTradesOnPartiallyFilledOrders` stays green.

**Deferred design question** (needs product / framework-owner sign-off): should the busted quantity additionally be returned to the lowest still-live ancestor — here the sales Root (sent 0 / open 1500) — or auto-released? All candidate behaviours agree the dead levels must read 0, so this fix is the intersection of every option and is safe to ship independently. Today the quantity is not returned to the desk either, so deferring changes nothing for users. The deferred expectation is encoded in a separate `@Disabled` test referencing this page.

## 7. Supporting evidence

1. **FIX specification** — `LeavesQty` is defined as 0 for orders in terminal status (Canceled, Expired, Rejected, DoneForDay); `OrderQty − CumQty` applies to open orders only. Nothing in FIX re-opens quantity on a cancelled order after ExecType=TRADE_CANCEL.
2. **Downstream contract** — Batman validation requires `OpenQty = SentQty = 0` on Cancelled; the invariant already exists in our stack.
3. **Operational precedent** — the 30 Jul manual remediation was `ReleaseQuantity` to 0 on the dead leg: operations' own answer to what the correct state is.

## 8. References

- Jira: BLACKBIRD-55358
- Incident: INC1040558889
- Tests: `SalesDeskTradeBustingTest.testBustedTradesOnPartiallyFilledOrders` (green), `.testBustedTradesOnCancelledOrdersShouldNotRestoreOpenQuantity` (red until fix)
- Prod trace: bust burst 10:14:28 (~772 reversal events), manual release 11:38:46, ~84 min Invalid
