package com.barclays.eq.functional.amer.hightouch.octon.us.singlelegexplosion.principal;

// imports as per existing tests in this package

/**
 * BLACKBIRD-55073 — TargetPositionAccount / TargetSubBook propagation on the
 * Sales Trading ROE (AMER Blackbird -> EMEA Blackbird), funding trade flow.
 *
 * Verifies the two new pass-through fields survive the full lifecycle:
 *   create -> slice -> route to EMEA (NewOrderSingle) -> fill -> trade back to AMER.
 *
 * ASSUMPTIONS (verify before running):
 *  1. Generated builder/assert methods are .targetPositionAccount(..) / .targetSubBook(..)
 *     (from common-model ids 22232/22233 after ROE regen).
 *  2. batman.createOrder() can set the fields. If the Batman-side (position trading ROE)
 *     change hasn't landed yet, inject them at the Blackbird boundary instead —
 *     the scope of THIS test is only the salestrading leg (AMER BB <-> EMEA BB).
 *  3. Target values are synthetic test data. Live values depend on EQDS-4979
 *     (EMEA Book/SubBook reference data in AMER) — not required for schema pass-through.
 */
public class SingleLegOctonSwapPrincipalFundingTradeTargetFieldsTest
        extends BaseSingleLegPrincipaOctonTestSetup {

    // AMER's own book (same as existing test)
    private static final String POSITION_ACCOUNT = "0010012912099";
    // TODO: replace with agreed EMEA test reference data
    private static final String TARGET_POSITION_ACCOUNT = "0010004513099"; // EMEA target book
    private static final String TARGET_SUB_BOOK = "LDN-EFS-SUB1";          // EMEA target subfolder

    /**
     * Flow 1: BBPLC (AMER) -> BBPLC (EMEA). Broker fill, target fields pass through
     * unchanged on NewOrderSingle out and Trade back.
     */
    @Test
    public void testOrderFill_targetFieldsPropagate_BBPLCtoBBPLC() {

        batman.createOrder().deskId(SWAP).handlInst(Manual)
                .positionAccount(POSITION_ACCOUNT)
                .targetPositionAccount(TARGET_POSITION_ACCOUNT)   // NEW
                .targetSubBook(TARGET_SUB_BOOK)                   // NEW
                .send();

        batman.slice().targetDeskId("LDN-EFS-PIII").suppressOrderExplosion(true).send();

        OrderReference firmSliceOrder = batman.mustSee().sliceOrder()
                .portfolioType(FirmNonArb)
                .targetDeskId("LDN-EFS-PIII")
                .positionAccount(POSITION_ACCOUNT)
                .targetPositionAccount(TARGET_POSITION_ACCOUNT)   // NEW: survives slicing
                .targetSubBook(TARGET_SUB_BOOK)                   // NEW
                .legalEntity(BBPLC)
                .isAffiliate(false)
                .orderQty(1000.0)
                .reference();

        // AMER -> EMEA: NewOrderSingle must carry the target fields (ClientRequestedOrderGroup)
        emeaDownstreamBlackbird.mustSee().newOrderSingle()
                .side(BUY)
                .originatingLegalEntity(BBPLC)
                .legalEntity(BBPLC)
                .deskId("SWAP")
                .targetDeskId("LDN-EFS-PIII")
                .positionAccount(POSITION_ACCOUNT)
                .targetPositionAccount(TARGET_POSITION_ACCOUNT)   // NEW: key assertion
                .targetSubBook(TARGET_SUB_BOOK)                   // NEW: key assertion
                .currency("USD")
                .settlCurrency("USD");
                // (retain remaining assertions from the existing test as needed)

        DownstreamBlackbirdOmsOrder emeaOrder = emeaDownstreamBlackbird.acceptOrder().send();
        emeaDownstreamBlackbird.fillOrder(emeaOrder)
                .lastQty(1000).fillType(FillType.Broker).lastMkt(OFF_EXCHANGE).send();

        // EMEA -> AMER: Trade must still carry the target fields (TradeMessage, direct fieldRefs)
        pog2.mustSee().trade()
                .orderId(firmSliceOrder.orderID)
                .execType(TRADE)
                .lastQty(1000.0)
                .legalEntity(BBPLC)
                .region("AMER")
                .positionAccount(POSITION_ACCOUNT)
                .targetPositionAccount(TARGET_POSITION_ACCOUNT)   // NEW: round-trip intact
                .targetSubBook(TARGET_SUB_BOOK)                   // NEW
                .fillType(FillType.Broker)
                .lastMkt(OFF_EXCHANGE)
                .trdType(TrdType.FundingTrade);
    }

    /**
     * Flow 2: BBPLC (AMER) -> BCSL (EMEA). Per funding-trade requirements the fill
     * comes back FillType=House (BCSL house fill); target fields identical pass-through.
     * TODO: confirm exact legalEntity/fill assertions for the BCSL leg with Arun.
     */
    @Test
    public void testOrderFill_targetFieldsPropagate_BBPLCtoBCSL() {

        batman.createOrder().deskId(SWAP).handlInst(Manual)
                .positionAccount(POSITION_ACCOUNT)
                .targetPositionAccount(TARGET_POSITION_ACCOUNT)
                .targetSubBook(TARGET_SUB_BOOK)
                .send();

        batman.slice().targetDeskId("LDN-EFS-PIII").suppressOrderExplosion(true).send();

        OrderReference firmSliceOrder = batman.mustSee().sliceOrder()
                .targetPositionAccount(TARGET_POSITION_ACCOUNT)
                .targetSubBook(TARGET_SUB_BOOK)
                .reference();

        emeaDownstreamBlackbird.mustSee().newOrderSingle()
                .originatingLegalEntity(BBPLC)
                .targetPositionAccount(TARGET_POSITION_ACCOUNT)
                .targetSubBook(TARGET_SUB_BOOK);

        DownstreamBlackbirdOmsOrder emeaOrder = emeaDownstreamBlackbird.acceptOrder().send();
        emeaDownstreamBlackbird.fillOrder(emeaOrder)
                .lastQty(1000).fillType(FillType.House).lastMkt(OFF_EXCHANGE).send(); // TODO confirm House

        pog2.mustSee().trade()
                .orderId(firmSliceOrder.orderID)
                .targetPositionAccount(TARGET_POSITION_ACCOUNT)
                .targetSubBook(TARGET_SUB_BOOK)
                .fillType(FillType.House)                          // TODO confirm
                .trdType(TrdType.FundingTrade);
    }

    /**
     * Optional: cancel-replace persistence — fields ride OrderCancelReplaceRequest
     * automatically via ClientRequestedOrderGroup. Amend qty, assert EMEA sees the
     * cancelReplace with both target fields unchanged, then fill and assert the trade.
     * Sketch only — wire up per the harness's amend DSL:
     *
     *   batman.amendOrder(firmSliceOrder).orderQty(2000.0).send();
     *   emeaDownstreamBlackbird.mustSee().orderCancelReplace()
     *           .targetPositionAccount(TARGET_POSITION_ACCOUNT)
     *           .targetSubBook(TARGET_SUB_BOOK);
     */
}
