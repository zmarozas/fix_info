package com.barcap.eq.oms.module;

import com.typesafe.config.Config;

import java.util.HashMap;
import java.util.Map;

/**
 * Generic environment config bound by name. Mirrors stockloan's ConfigurationConstants:
 * the constant is the @Named qualifier, shared with the injection point so the compiler
 * enforces agreement. BiFrost/Solace-specific config stays local to the bifrost module,
 * as in stockloan's MagicsEBorrowModule.
 */
public final class ConfigurationConstants {

    public static final String ENVIRONMENT_TIMEZONE = "environment.timeZone";

    private ConfigurationConstants() {
    }

    public static Map<String, String> loadProperties(Config config) {
        final HashMap<String, String> properties = new HashMap<>();
        properties.put(ENVIRONMENT_TIMEZONE, config.getString("environment.timeZone"));
        return properties;
    }
}

public static final String ENVIRONMENT_PREFIX_KEY = "bifrost.environmentPrefix";                     // @Named qualifier
public static final String ENVIRONMENT_PREFIX     = "optionPricerGateway.bifrost.environmentPrefix"; // config path

bind(config.getString(BifrostAdapter.ENVIRONMENT_PREFIX)).named(BifrostAdapter.ENVIRONMENT_PREFIX_KEY).to(String.class);
ProductIdCodec: @Named(BifrostAdapter.ENVIRONMENT_PREFIX_KEY).