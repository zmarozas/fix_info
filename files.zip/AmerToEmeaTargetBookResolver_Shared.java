/*
 * BLACKBIRD-55073 — shared resolution for TargetPositionAccount / TargetSubBook.
 * Used by BOTH creation paths:
 *   - two-step: CreateSliceOrderAndRouteParamsToSliceOrderTranslator (root exists -> parent fallback)
 *   - one-step: CreateRootOrderSliceOrderAndRouteParamsToOrderMapper (no parent -> fallback = null)
 *
 * Precedence per field: config override (when enabled) -> params -> parent (if any).
 */

// ============================================================
// 1) NEW shared utility
// ============================================================
package com.barcap.eq.oms.domain.trading.configuration; // or ...domain.service — match your conventions

@Singleton
public class AmerToEmeaTargetBookResolver {

    @Inject private TradingConfigurationProvider tradingConfigurationProvider;
    @Inject private BookMapper bookMapper;

    @Nullable
    public Book resolveTargetBook(@Nullable String paramsPositionAccount,
                                  @Nullable Book parentBook,          // null on one-step
                                  Violations violations) {
        if (isOverrideEnabled()) {
            return mapBook(tradingConfigurationProvider.getAmerToEmeaTargetPositionAccount(), violations);
        }
        Book fromParams = mapBook(paramsPositionAccount, violations);
        return fromParams != null ? fromParams : parentBook;
    }

    @Nullable
    public String resolveTargetSubBook(@Nullable String paramsSubBook,
                                       @Nullable String parentSubBook) { // null on one-step
        if (isOverrideEnabled()) {
            return tradingConfigurationProvider.getAmerToEmeaTargetSubBook();
        }
        return paramsSubBook != null ? paramsSubBook : parentSubBook;
    }

    // TEMPORARY (BLACKBIRD-55073): override configs removed once BM sends real values.
    public boolean isOverrideEnabled() {
        return tradingConfigurationProvider.isAmerToEmeaTargetAccountOverrideEnabled();
    }

    @Nullable
    private Book mapBook(@Nullable String positionAccount, Violations violations) {
        return positionAccount != null ? bookMapper.map(positionAccount, violations) : null;
    }
}

// ============================================================
// 2) Two-step path — translator now delegates
//    (CreateSliceOrderAndRouteParamsToSliceOrderTranslator)
// ============================================================
    @Inject private AmerToEmeaTargetBookResolver amerToEmeaTargetBookResolver;

    private void applyAmerToEmeaTargetBookAndSubBook(DeskOrder root,
                                                     CreateSliceOrderAndRouteParams params,
                                                     UninitializedDeskOrder uninitializedDeskOrder,
                                                     Violations violations) {
        if (!amerToEmeaFundingTradeOrderSpecification
                .isSatisfiedBySourceOMS(root, params.getTargetDeskID())) {
            return;
        }
        Book targetBook = amerToEmeaTargetBookResolver.resolveTargetBook(
                params.getTargetPositionAccount(), root.getTargetPositionAccount(), violations);
        if (targetBook != null) {
            uninitializedDeskOrder.targetPositionAccount(targetBook);
        }
        uninitializedDeskOrder.targetSubBook(amerToEmeaTargetBookResolver.resolveTargetSubBook(
                params.getTargetSubBook(), root.getTargetSubBook()));
    }

// ============================================================
// 3) One-step path — CreateRootOrderSliceOrderAndRouteParamsToOrderMapper
//    Keep the existing @Mapping(ignore = true) for both fields;
//    populate in the existing @AfterMapping after(...) method.
// ============================================================
    @Inject protected AmerToEmeaTargetBookResolver amerToEmeaTargetBookResolver;
    @Inject protected AmerToEmeaFundingTradeOrderSpecification amerToEmeaFundingTradeOrderSpecification;

    // add at the end of after(@MappingTarget UninitializedDeskOrder target,
    //                         CreateRootOrderSliceOrderAndRouteParams params, Violations violations):

        applyAmerToEmeaTargetBookAndSubBook(target, params, violations);

    // new method on the mapper:
    protected void applyAmerToEmeaTargetBookAndSubBook(UninitializedDeskOrder target,
                                                       CreateRootOrderSliceOrderAndRouteParams params,
                                                       Violations violations) {
        // TODO: confirm the right spec overload for root creation (no DeskOrder yet) —
        // e.g. isSatisfiedBySourceDMS(sourceDeskId, targetDeskId, product, legalEntity)
        // sourced from params/params.getRootOrderFields().
        if (!amerToEmeaFundingTradeOrderSpecification.isSatisfiedBySourceDMS(
                params.getDeskId(),
                params.getTargetDeskID(),
                /* product */ null,          // TODO wire from params/product lookup
                /* legalEntity */ null)) {   // TODO wire from params.getRootOrderFields()
            return;
        }
        // one-step: no parent -> parent fallbacks are null
        Book targetBook = amerToEmeaTargetBookResolver.resolveTargetBook(
                params.getTargetPositionAccount(), /* parentBook */ null, violations);
        if (targetBook != null) {
            target.targetPositionAccount(targetBook);
        }
        target.targetSubBook(amerToEmeaTargetBookResolver.resolveTargetSubBook(
                params.getTargetSubBook(), /* parentSubBook */ null));
    }
