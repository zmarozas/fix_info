package com.barcap.eq.oms.server.bifrost;

import com.barcap.eq.apex.ApexConfiguration;

import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.JCSMPFactory;
import com.solacesystems.jcsmp.JCSMPProperties;
import com.solacesystems.jcsmp.JCSMPSession;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

/**
 * Manages the Solace JCSMP session lifecycle for the BiFrost bridge.
 * Mirrors stockloan's MagicsAdapter: auth-type dispatcher, connect at setup,
 * delegate setup(session)/shutdown() to the inbound listener and outbound publisher.
 */
@Singleton
public class BifrostAdapter {

    public static class Solace {
        public static final String AUTHENTICATION_TYPE          = "optionpricerGateway.bifrost.solace.authType";
        public static final String HOST                         = "optionpricerGateway.bifrost.solace.host";
        public static final String VPN                          = "optionpricerGateway.bifrost.solace.vpn";
        public static final String SSL_KEY_STORE                = "optionpricerGateway.bifrost.solace.auth.ssl.keyStore";
        public static final String SSL_KEY_STORE_PASSWORD_FILE  = "optionpricerGateway.bifrost.solace.auth.ssl.keyStorePasswordFile";
        public static final String REQUEST_TOPIC_PATTERN        = "optionpricerGateway.bifrost.solace.topics.requestPattern";
        public static final String RESPONSE_SUBSCRIPTION        = "optionpricerGateway.bifrost.solace.topics.responseSubscription";
        public static final String GREEKS_SUBSCRIPTION          = "optionpricerGateway.bifrost.solace.topics.greeksSubscription";
    }

    private static final String KERBEROS = "kerberos";
    private static final String SSL = "ssl";
    private static final String CLIENT_NAME_PREFIX = "BB.TA";
    private static final String CLIENT_NAME_SUFFIX = "-bifrostadapter";
    private static final String EMPTY_STRING = "";

    private final Logger logger = LoggerFactory.getLogger(BifrostAdapter.class);

    private final PricingRequestPublisher pricingRequestPublisher;
    private final BifrostInboundListener bifrostInboundListener;
    private final Config applicationConfig;
    private JCSMPSession session;

    @Inject
    public BifrostAdapter(PricingRequestPublisher pricingRequestPublisher,
                          BifrostInboundListener bifrostInboundListener,
                          ApexConfiguration applicationConfig) {
        this.pricingRequestPublisher = pricingRequestPublisher;
        this.bifrostInboundListener = bifrostInboundListener;
        this.applicationConfig = applicationConfig.getConfig();

        try {
            createSolaceConnectionProperties();
        } catch (ConfigException e) {
            logger.error("Unable to create Solace properties for BifrostAdapter", e);
            throw e;
        }
    }

    public void setup() throws JCSMPException {
        session = JCSMPFactory.onlyInstance().createSession(createSolaceConnectionProperties());

        logger.info("Connecting to BiFrost solace ...");
        // TODO wire team's RetryPolicy.builder().build().tryCall(...) once import is confirmed
        session.connect();
        logger.info("BiFrost solace session established.");

        pricingRequestPublisher.setup(session);
        bifrostInboundListener.setup(session);
    }

    public void shutdown() {
        if (bifrostInboundListener != null) {
            bifrostInboundListener.shutdown();
        }
        if (session != null) {
            session.closeSession();
        }
    }

    private JCSMPProperties createSSLProperties() {
        logger.debug("Creating Solace properties for Client certificate authentication");

        JCSMPProperties properties = new JCSMPProperties();
        properties.setProperty(JCSMPProperties.HOST, applicationConfig.getString(Solace.HOST));
        properties.setProperty(JCSMPProperties.VPN_NAME, applicationConfig.getString(Solace.VPN));
        properties.setProperty(JCSMPProperties.AUTHENTICATION_SCHEME, JCSMPProperties.AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE);
        properties.setProperty(JCSMPProperties.SSL_KEY_STORE, applicationConfig.getString(Solace.SSL_KEY_STORE));
        properties.setProperty(JCSMPProperties.SSL_KEY_STORE_PASSWORD, readPassword(applicationConfig.getString(Solace.SSL_KEY_STORE_PASSWORD_FILE)));
        properties.setProperty(JCSMPProperties.SSL_KEY_STORE_FORMAT, "JKS");
        properties.setProperty(JCSMPProperties.SSL_CONNECTION_DOWNGRADE_TO, JCSMPProperties.TRANSPORT_PROTOCOL_PLAIN_TEXT);
        properties.setProperty(JCSMPProperties.SSL_VALIDATE_CERTIFICATE, false);
        properties.setProperty(JCSMPProperties.CLIENT_NAME, getClientName());
        return properties;
    }

    private JCSMPProperties createKerberosProperties() {
        logger.debug("Creating Solace properties for Kerberos authentication");

        JCSMPProperties properties = new JCSMPProperties();
        properties.setProperty(JCSMPProperties.HOST, applicationConfig.getString(Solace.HOST));
        properties.setProperty(JCSMPProperties.VPN_NAME, applicationConfig.getString(Solace.VPN));
        properties.setProperty(JCSMPProperties.AUTHENTICATION_SCHEME, JCSMPProperties.AUTHENTICATION_SCHEME_GSS_KRB);
        properties.setProperty(JCSMPProperties.KRB_SERVICE_NAME, JCSMPProperties.HOST);
        properties.setProperty(JCSMPProperties.CLIENT_NAME, getClientName());
        return properties;
    }

    private JCSMPProperties createBasicProperties() {
        logger.debug("Creating Solace properties for Basic authentication");

        JCSMPProperties properties = new JCSMPProperties();
        properties.setProperty(JCSMPProperties.HOST, applicationConfig.getString(Solace.HOST));
        properties.setProperty(JCSMPProperties.VPN_NAME, applicationConfig.getString(Solace.VPN));
        properties.setProperty(JCSMPProperties.AUTHENTICATION_SCHEME, JCSMPProperties.AUTHENTICATION_SCHEME_BASIC);
        properties.setProperty(JCSMPProperties.USERNAME, applicationConfig.getString(Solace.VPN));
        properties.setProperty(JCSMPProperties.PASSWORD, "");
        properties.setProperty(JCSMPProperties.CLIENT_NAME, getClientName());
        return properties;
    }

    private JCSMPProperties createSolaceConnectionProperties() {
        String authenticationType = applicationConfig.getString(Solace.AUTHENTICATION_TYPE);
        if (KERBEROS.equalsIgnoreCase(authenticationType)) {
            return createKerberosProperties();
        }
        if (SSL.equalsIgnoreCase(authenticationType)) {
            return createSSLProperties();
        }
        return createBasicProperties();
    }

    private String getClientName() {
        return String.join(".", CLIENT_NAME_PREFIX,
                applicationConfig.getString("environment.location"),
                applicationConfig.getString("environment.name"))
                + getHostname()
                + CLIENT_NAME_SUFFIX;
    }

    private String getHostname() {
        try {
            return "@" + InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            logger.warn("Cannot parse hostname - {}", e.getMessage());
        }
        return EMPTY_STRING;
    }

    private String readPassword(String filePath) {
        try (Stream<String> stream = Files.lines(Paths.get(filePath))) {
            return stream.findFirst().orElseThrow(() -> new IOException("File " + filePath + " is empty"));
        } catch (IOException e) {
            logger.error("Cannot read passphrase from {}", filePath);
        }
        return null;
    }
}
