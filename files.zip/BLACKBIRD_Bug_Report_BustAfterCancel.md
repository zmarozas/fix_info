# Jira Bug — Busted trades reopen quantity on cancelled orders

## Summary
Busting trades on cancelled orders restores open quantity to a terminal order, leaving unworkable open qty requiring manual service desk release

---

## Details

| Field | Value |
|---|---|
| Type | Bug |
| Environment | PROD |
| Impacted Systems | BLACKBIRD |
| Region | AMER |
| Status of investigation | **Partial** — see Investigation Limitations |

---

## Description

### Summary of the incident
An order originating from **Puma** was routed to the **cash sales desk** and sliced down to the **cash desk**. The resulting orders were **cancelled**. Shortly afterwards, the **trades on those orders were busted**.

When the bust was processed, Blackbird restored the busted quantity as **open** on orders that were already in a **cancelled (terminal) state**. This left **25,000** showing as open on an order that could no longer be worked, which the system then flagged as **invalid**. The position remained in this state until the **service desk manually released it at 11:38:46**.

### Sequence of events
1. Order received from Puma into the cash sales desk.
2. Order sliced down to the cash desk.
3. Sliced orders **cancelled**.
4. Trades on those cancelled orders **busted**.
5. Bust handling returns the busted quantity to open on the cancelled orders.
6. 25,000 left open on terminal orders — cannot be worked.
7. Order flagged **invalid**.
8. State persists until manual service desk release at **11:38:46**.

### Analysis
The bust handling appears to restore open quantity without accounting for the current state of the order it is being applied to. Where the order has already reached a terminal (cancelled) state, restoring open quantity produces an inconsistent order: quantity is shown as open, but there is no valid path to work or fill it, and no automatic route to close it out. The resulting state requires manual intervention to clear.

### Expected behaviour
Busting a trade against an already-cancelled order should not restore open quantity to that order. The order is terminal; any quantity returned by the bust should either not be reopened, or be handled in a way that does not leave unworkable open quantity or an invalid order state.

### Actual behaviour
Quantity is restored as open on cancelled orders. 25,000 was left open and unworkable, the order was flagged invalid, and manual service desk intervention was required to release it.

---

## Steps to reproduce (to be confirmed)
1. Route an order from Puma to the cash sales desk.
2. Slice the order down to the cash desk.
3. Cancel the sliced orders.
4. Bust the trades associated with those cancelled orders.
5. Observe that the busted quantity is restored as open on the cancelled orders, and the order is flagged invalid.

---

## Impact
- Open, unworkable quantity left on terminal orders (25,000 in this instance).
- Order flagged as invalid.
- Manual service desk intervention required to clear the state.
- Risk of user confusion: quantity appears open and available but cannot be actioned.

---

## Investigation limitations
The message search tooling (Kibana) was returning **503 Service Unavailable** during the investigation, so the full message chain could not be reviewed. The findings above are based on the information available at the time and are **not a confirmed root cause**.

Outstanding items:
- Retrieve and attach the order / execution IDs and full message timeline once message search is restored.
- Confirm the exact code path in bust handling that restores open quantity, and whether order state is evaluated before the restore.
- Confirm whether ordering matters (i.e. bust before cancel vs cancel before bust) and whether the alternative sequence behaves correctly.

---

## Next steps
- Complete investigation once message search is available; update this ticket with IDs and timeline.
- Add functional test coverage for **cancel-then-bust** on sliced cash desk orders.
- Determine correct handling for busted quantity against terminal orders and implement the fix.
