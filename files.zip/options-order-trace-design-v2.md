# Options Order Trace and Journal Analytics — Design

**Status:** Draft design for discussion · July 2026
**Companion page:** *Options Order Trace — Executive Summary*

---

## 1. Background and forcing event

The options platform is expected to absorb a step-change in volume: the business is planning to expand SpiderRock flow toward **~5,000 orders every 30 seconds**, i.e. tens of millions of order events per trading day.

Operational visibility has not kept pace. Unlike equities, options transaction messages are **not consistently available in Elasticsearch**; the ES cluster is already heavily loaded at today's volumes, is slow for interactive investigation, and retains only ~7 days. The complete record exists only in **Neeve Research RDAT files** and **Barclays Bedrock journal files** — two proprietary formats with no common query capability.

This design proposes the smallest useful step: convert already-retained journal data into an open columnar format (Parquet) and query it read-only with an embedded SQL engine (DuckDB). No new production paths, no new server platforms.

## 2. Problem statement

- Support engineers must reconstruct complete order lifecycles (client → internal → street) across two proprietary stores with different formats and tools.
- The vendor transaction-lookup tool handles single-record retrieval but not joins, time-range scans, or cross-source correlation.
- Manual extraction and copying of journal files to development machines is slow and creates governance exposure.
- Elasticsearch cannot be the answer: wrong economics (always-on hot cluster) for cold historical data, already saturated, short retention, incomplete options coverage.
- At projected SpiderRock volumes, every one of these problems compounds.

## 3. Current state

**Neeve path.** Neeve technology consumes from Solace and persists messages into proprietary RDAT files with reliable processing and failover. **RDAT→JSON extraction tooling already exists and is battle-tested:** it was built for the Apex 2 → Apex 3 platform-version migration, where whole days of production traffic were converted to JSON on both platform versions and diffed to validate the migration. This is precisely the decode-at-scale workflow this design requires — the conversion layer reuses it rather than building decoding from scratch. The bundled vendor lookup tool remains adequate for point queries only.

**Bedrock path.** Bedrock components write transaction/message journals into the daily archive's `fastpath/` folder. Journal→JSON extraction likewise already exists; raw JSON files are simply inconvenient for ad-hoc querying, which is the gap this design closes.

**Golden Host.** Already receives the daily journal archives **aggregated across all application shards** into a common folder structure — the natural home for the eventual operational workflow (Phase 3), subject to installation and entitlement approvals then. The POC itself (Phases 1a/1b) runs entirely in non-production. No new collection mechanism is required.

## 4. Goals and non-goals

| Goals (v1) | Non-goals (v1) |
|---|---|
| Convert RDAT- and journal-derived records to daily Parquet | Replace Neeve, Bedrock, Solace, or any authoritative path |
| Common searchable identifiers + timestamps across sources | A new enterprise transaction database |
| Direct SQL over one or many days of files | Real-time surveillance, reconciliation, or regulatory reporting |
| Cross-platform order-lifecycle reconstruction | Official books-and-records status for the derived data |
| Cut investigation time and infrastructure cost | Any UI before the CLI value is proven |

## 5. Alternatives considered

| Option | Assessment |
|---|---|
| **Scale up Elasticsearch** | Wrong tool economics: always-on cluster for mostly-cold data; already saturated; retention would stay expensive; options coverage gap remains. Expansion also buys the priciest hardware on today's market — RAM and compute, both inflated by AI-datacenter demand — where this design consumes only disk on existing infrastructure. |
| **New OLAP server (ClickHouse etc.)** | Strong engine, but introduces a new 24×7 platform to install, patch, entitle, and support — heavyweight for a support-diagnostics need. |
| **kdb+/q** | Excellent for tick analytics; licence cost and niche skill set are disproportionate to this use case. |
| **Parquet + DuckDB (chosen)** | Zero-server: data sits in files, engine is a single binary. Open formats, no licence cost, columnar performance, trivially removable if it doesn't earn its keep. |

The chosen option is also the **least committal** — if the POC fails, we delete a directory.

### 5.1 Maturity and adoption of the chosen tooling

DuckDB is not a hobbyist tool; it is an established open-source analytical engine with an academic pedigree and broad industry adoption:

- **Origin and governance:** created at CWI (the Dutch national research institute for mathematics and computer science — the same lab behind MonetDB and foundational columnar-database research); MIT-licensed; stewarded by the non-profit DuckDB Foundation.
- **Maturity:** version 1.0 released June 2024; **1.4 LTS** (October 2025) added AES-256 database encryption and a long-term-support designation aimed explicitly at enterprise adoption. ([duckdb.org](https://duckdb.org))
- **Adoption:** ~30,000+ GitHub stars; ranked #4 among databases in the Stack Overflow Developer Survey; ships **pre-installed in Microsoft Fabric Python notebooks**. Documented production users include **Okta** (security-log analytics over very large record volumes) and numerous data platforms; see ["15+ Companies Using DuckDB in Production"](https://motherduck.com/blog/15-companies-duckdb-in-prod/).
- **Literature and learning:** *DuckDB in Action* (Manning, 2024; Needham/Hunger/Simons) — [free authorized PDF](https://motherduck.com/duckdb-book-brief/); official documentation and guides at [duckdb.org/docs](https://duckdb.org/docs).
- **Parquet** (the storage half of the proposal) is an Apache project and the de-facto standard columnar format across the industry — readable from Python, Spark, and virtually every modern data tool, which is what makes the query engine swappable.
- **Already in use inside Barclays:** other teams have adopted Parquet as a data format (e.g. the COO Data Reporting QE group's Parquet file-generation tooling, built on Python/pyarrow and documented on Confluence). The format is therefore not novel to the firm — its use here is a new *application* of an already-accepted format, not the introduction of a new technology. (Those uses are AWS/S3-based and serve different workflows; the precedent is the format's acceptance, not this specific pipeline.)

## 6. Proposed architecture

**Design principle: the format is the architecture — the engine is an accessory.** This proposal does **not** build a dependency on DuckDB. What it builds is our order data organized as **Apache Parquet** files — an open, columnar, industry-standard format — laid out in Hive-style partitioned directories (`source=…/business_date=…`) that any modern data tool understands. Once data exists in that layout, an entire ecosystem can read it: Python (pyarrow/pandas), Spark, Java, cloud query services, and DuckDB — which is simply the **best lightweight choice today**: a single open-source binary that runs standard SQL directly against the file system, with no server and excellent speed. If DuckDB disappeared tomorrow, the data, the partition layout, and the saved query logic all survive; only the executable changes. There is no lock-in to retire later — the durable asset is the files.

```
                        EXISTING PRODUCTION PATHS (unchanged)
 ┌──────────────────────────────┐        ┌──────────────────────────────┐
 │ Solace → Neeve → RDAT files  │        │ Barclays Bedrock journals    │
 │  (all shards, HA pairs)      │        │  (all shards)                │
 └──────────────┬───────────────┘        └──────────────┬───────────────┘
                │ existing daily archive to Golden Host │
                ▼                                       ▼
        Aggregated journal folder (per business date, all shards)
                │ existing approved extraction utilities
                ▼
        Neeve JSON Lines            Bedrock JSON Lines
                └──────────────┬────────────────┘
                               ▼
                     End-of-day converter
                JSON Lines → Parquet  (+ shard-map validation)
                               ▼
                 Approved Parquet directory
            partitioned by source / business date
                               ▼
                        DuckDB CLI / SQL
                               │
             ┌─────────────────┴─────────────────┐
             ▼                                   ▼
      Saved standard queries              Ad-hoc SQL
      (lifecycle, rejects, joins)         by authorized users
```

DuckDB scans Parquet in place — no import step, no server process. A small persistent `.duckdb` catalog stores only views and macros; the data itself remains in files.

**Tooling fallback:** if DuckDB installation on the Golden Host is not approved in time, the Parquet directory is directly readable from approved Python (pyarrow/pandas). The conversion layer is the durable investment; the query engine is swappable.

## 7. Identifier model

Lifecycle reconstruction rests on identifiers that exist **by construction** in the platform, not on fuzzy correlation:

- **`compliance_id` — primary key for investigation.** Spans workflows; the majority of orders (single-leg options) are fully traceable by compliance ID + business date with a single indexed lookup. Investigations typically *start* here: upstream systems and the warehouse hand support the compliance ID of the client-facing order.
- **`global_link_id` / `workflow_link_id` — grouping keys for complex orders, kept as two distinct columns.** Multi-leg and multi-legal-entity orders (each leg carrying its own compliance ID) are linked by one or both of these; sometimes only one is populated, and merging them into a generic field would lose which linkage applied. A convenience view exposes `COALESCE(global_link_id, workflow_link_id)` where a single handle suffices.
- **Link IDs are discovered, not known upfront.** The multi-leg workflow is a three-step funnel, all on indexed identifiers: (1) look up the *primary* compliance ID's events; (2) read the link ID(s) off those events; (3) find all compliance IDs sharing that link, and trace each. No fuzzy correlation at any step.
- **FIX chain (`cl_ord_id` / `orig_cl_ord_id`), internal/street `order_id`, `exec_id`** — secondary keys for street-side and session-level investigation.

Phase 1 validates that `compliance_id` and the link IDs are consistently populated and extractable in **both** sources; this is the single most important POC deliverable, since every saved query builds on it.

## 8. Common data model

Both sources are normalized into one envelope; source-specific fields are preserved untouched.

| Column | Purpose |
|---|---|
| `event_time` | Normalized UTC timestamp, full available precision; original value and zone preserved in `attributes` (source hosts run NY-local time — normalization must not assume UTC inputs) |
| `business_date` | Partition key |
| `source` | `neeve`, `bedrock`, … |
| `environment` | dev / qa / pilot / prod, if more than one is ever converted |
| `platform` / `host` | Originating application / host |
| `shard` | Originating shard, derived from archive filename/path |
| `ha_role` | primary / backup where the source distinguishes them (see §10 dedupe rule) |
| `session_id` | FIX / Solace / internal session identifier |
| `direction` | inbound, outbound, published, consumed |
| `event_type` | Normalized classification |
| `message_type` | FIX MsgType or proprietary type |
| `compliance_id` | Primary investigation key (see §7) |
| `global_link_id` | Cross-order grouping key where assigned (multi-leg / multi-entity) |
| `workflow_link_id` | Workflow-level grouping key where assigned; one, both, or neither may be present |
| `cl_ord_id` / `orig_cl_ord_id` | Client order chain |
| `order_id` / `parent_order_id` | Internal / street / strategy identifiers |
| `exec_id` | Execution identifier |
| `symbol` | Instrument (canonical internal symbol; alternate representations, e.g. Bloomberg, in `attributes` where they diverge) |
| `underlying` | Underlying name for derivatives — enables per-underlying scans across all option series |
| `sequence_number` | Source sequence where available |
| `source_file` / `source_offset` | Traceability back to the byte |
| `raw_message` | Faithful original representation |
| `attributes` | Source-specific fields outside the common schema |
| `parser_version` | Conversion logic version |

### 8.1 Wide messages and schema evolution

The platform carries two very different shapes of record: compact internal order-state events, and FIX-style messages (NewOrderSingle, ExecutionReport, OrderCancelReplace, restates…) with **very many fields — and new fields added routinely**. The schema handles this with three layers and one policy:

1. **Envelope columns (the table above)** hold only what is needed to *find and join* events — identifiers, timestamps, types, shard. These are stable precisely because they are identifiers, not business payload. The envelope does not attempt to model every FIX tag.
2. **`attributes`** is a key→value column carrying *all remaining fields* exactly as the extraction utility emits them — position account, order/leaves quantities, trader ID, and whatever is added next month. Physically this is a **standard Parquet type, not anything DuckDB-specific**: a Parquet `MAP<string, string>` (native map logical type — efficient, since repeating tag names dictionary-encode well), readable identically from DuckDB, pyarrow, or Spark. Where extraction reveals genuinely *nested* payloads (e.g. repeating groups / legs inside one message), those structures are carried as a JSON string instead and queried via DuckDB's JSON functions; the POC confirms which shapes occur in practice. Because the converter passes fields through rather than enumerating them, **a newly added field appears in the data with zero converter changes**. DuckDB queries into it directly (`attributes['TraderID']`); this is slower than a native column, but such filters run after date/compliance-ID pruning has already reduced the row set. Map values are strings — numeric fields need a `CAST` before arithmetic, which the per-type views below bake in once.
3. **`raw_message`** preserves the byte-faithful original, so nothing is ever lost even if extraction lags a new field.

**Promotion policy:** when an `attributes` field becomes a frequent query key, it is promoted to a first-class envelope column in the next `parser_version`. Parquet evolves additively — older partitions simply lack the column and read as NULL (`union_by_name`); no migration, no rewrite, and saved queries keep working across old and new days.

**Per-type views** (`v_exec_reports`, `v_order_state_events`, …) map the relevant attributes into named columns for the message types support reads most, giving convenient typed access without forcing one impossibly wide table.

## 9. Parquet organization

```
/data/order-trace/
└── source=neeve/
    └── business_date=2026-07-17/
        ├── part-000.parquet
        └── manifest.json
└── source=bedrock/
    └── business_date=2026-07-17/
        ├── part-000.parquet
        └── manifest.json
```

- Hive-style partitioning by `source` and `business_date` enables partition pruning. `shard` is a **column, not a partition** — the archives arrive pre-aggregated, and per-shard partitions would create tiny-file sprawl.
- **What `part-000.parquet` means:** within one partition (one source, one business date), the converter writes the data as one or more numbered files — `part-000`, `part-001`, … — purely for size management. A small day fits in a single part file; a heavy day is split so each file stays in the ~128–512 MB sweet spot. The split is **not** per shard and carries no meaning: rows from all shards are mixed across the parts (each row's origin is in its `shard` column), and every query reads the partition by wildcard (`*.parquet`), so users never reference part numbers. Multiple files also let the converter write in parallel and let DuckDB scan in parallel.
- Target file sizes ~128–512 MB; avoid many tiny files.
- Compression: **zstd**. Expected ~10–20× reduction vs. extracted JSON for repetitive structured records (to be confirmed by benchmark).

## 10. Conversion process and data quality

End-of-day batch: **unpack** the day's archives to a temporary workspace (each daily zip contains the data folder tree — RDAT plus `fastpath/` journal) → decode (existing utilities) → normalize to common envelope → write Parquet → emit manifest → clean the workspace. The archive layout and member naming conventions are confirmed against real archives in Phase 1.

The JSON→Parquet step is a solved problem with interchangeable implementations, all producing identical standard files: DuckDB itself (`COPY (SELECT …) TO '….parquet'` — one binary for both conversion and querying), pure Java (Apache `parquet-java`, an ordinary internal batch job under standard testing and CI — the team's native stack), or approved Python (pyarrow). Likely split: DuckDB `COPY` for the Phase 1 POC, Java for the production-ized Phase 3 converter. Because Parquet is open, the choice can change later without affecting stored data or queries.

**Shard map.** A small, versioned configuration (derived from the application configs that define the shard topology, with effective date ranges) lists the shards expected per environment per business date. The converter validates *presence*: for each date, journals from every expected shard must be found, or the partition is flagged incomplete. This makes "did we get everything?" a mechanical manifest check and survives topology changes over time.

**HA duplicates.** Where primary and backup engines both journal the same logical events, the converter applies a documented rule (prefer primary; retain backup rows only where the primary file is absent, tagged via `ha_role`) so that counts and lifecycles are not silently doubled. The rule is validated in Phase 1 against a real failover day if one exists in retention.

**Idempotency.** Conversion writes to a temporary directory and atomically renames into place; re-running a day replaces the partition cleanly. Historical **backfill** is the same operation pointed at an older archive — the first real-world use will likely be an incident from a prior week.

Every partition ships a `manifest.json`. Its two jobs are **provenance** and **completeness**, both machine-checked:

- `source_archives` records provenance at two levels — archive name → member path (→ per-row byte offset) — because the daily unit is a timestamped zip of the data folder tree (RDAT + `fastpath/` journal), not a single file. The transient intermediate JSON is never the provenance reference.
- `expected_shards` comes from the shard map for that business date; `found_shards` is what the converter actually saw. A mismatch does not fail the conversion — it **flags the partition incomplete**, the ingestion-validation query surfaces it, and the query wrappers warn before returning results from a flagged day. This is the concrete mechanism behind "an empty query result must be distinguishable from missing data": per-row `shard` says where a row came from; expected-vs-found says whether rows are *missing entirely*.

```json
{
  "source_archives": [
    {
      "archive": "bbopt-shard1-20260717-213000.zip",
      "members": [
        {"path": "data/rdat/<rdat files>", "records": 9172610},
        {"path": "data/fastpath/<journal file>", "records": 1204332}
      ]
    },
    {
      "archive": "bbopt-shard2-20260717-213000.zip",
      "members": [
        {"path": "data/rdat/<rdat files>", "records": 9172609},
        {"path": "data/fastpath/<journal file>", "records": 1198774}
      ]
    }
  ],
  "expected_shards": ["1", "2"],
  "found_shards": ["1", "2"],
  "converted_records": 20748325,
  "parse_failures": 0,
  "first_timestamp": "2026-07-17T00:00:00.001Z",
  "last_timestamp": "2026-07-17T23:59:59.891Z",
  "output_files": ["part-000.parquet"],
  "parser_version": "1.0.0"
}
```

Validation checks: source vs. converted counts; expected vs. found shards; parse-failure samples; timestamp bounds; sequence-number gaps where sources provide them; schema/parser-version compatibility. **An empty query result must be distinguishable from missing data.**

## 11. Query workflow

The query names used below (`events`, `neeve_events`, `bedrock_events`) are **views, not tables** — defined once in the small DuckDB catalog file (§6) and expanding to `read_parquet` over the partition tree. No data is imported anywhere; a view is just a saved query:

```sql
-- defined once, versioned in the queries/ folder:
CREATE OR REPLACE VIEW events AS
SELECT * FROM read_parquet('/data/order-trace/*/business_date=*/*.parquet',
                           hive_partitioning = true);
-- hive_partitioning turns the directory names into columns automatically:
-- source=neeve/business_date=2026-07-17/ ⇒ source='neeve', business_date=DATE '2026-07-17'

CREATE OR REPLACE VIEW neeve_events   AS SELECT * FROM events WHERE source = 'neeve';
CREATE OR REPLACE VIEW bedrock_events AS SELECT * FROM events WHERE source = 'bedrock';
```

Because `source` is itself a partition column, filtering on it (directly or via these views) prunes to the matching directory subtree — the per-source views are convenience names, not copies.

```sql
-- find one order (majority case: single-leg)
SELECT event_time, source, shard, message_type, compliance_id, order_id, exec_id
FROM read_parquet('/data/order-trace/*/business_date=2026-07-17/*.parquet',
                  hive_partitioning = true)
WHERE compliance_id = 'CMP123456'
ORDER BY event_time;
```

```sql
-- multi-leg / multi-entity order. The investigator starts from the PRIMARY
-- (client-facing) compliance ID supplied by upstream — the link ID is NOT
-- known upfront. Three steps in one query, all on indexed identifiers:
--   1) events of the primary order  →  2) discover its link ID(s)
--   →  3) all compliance IDs sharing that link  →  full trace.
WITH primary_events AS (
  SELECT * FROM events
  WHERE compliance_id = 'CMP123456'            -- known: from First / warehouse
    AND business_date = DATE '2026-07-17'
),
links AS (                                     -- discovered, either kind
  SELECT DISTINCT COALESCE(global_link_id, workflow_link_id) AS link
  FROM primary_events
  WHERE COALESCE(global_link_id, workflow_link_id) IS NOT NULL
),
legs AS (                                      -- all sibling legs
  SELECT DISTINCT e.compliance_id
  FROM events e JOIN links l
    ON l.link IN (e.global_link_id, e.workflow_link_id)
  WHERE e.business_date = DATE '2026-07-17'
)
SELECT e.*
FROM events e JOIN legs USING (compliance_id)
WHERE e.business_date = DATE '2026-07-17'
ORDER BY e.event_time;
```

```sql
-- cross-source lifecycle: prefer UNION ALL BY NAME over many-to-many joins
SELECT * FROM neeve_events   WHERE compliance_id = 'CMP123456' AND business_date = DATE '2026-07-17'
UNION ALL BY NAME
SELECT * FROM bedrock_events WHERE compliance_id = 'CMP123456' AND business_date = DATE '2026-07-17'
ORDER BY event_time;
```

```sql
-- envelope columns + payload fields from `attributes` in one result:
-- lifecycle of an order with the business fields support actually reads
SELECT event_time,
       source,
       message_type,
       attributes['OrdStatus']     AS ord_status,
       attributes['OrderQty']      AS order_qty,
       attributes['LeavesQty']     AS leaves_qty,
       attributes['PositionAccount'] AS position_account,
       attributes['TraderId']      AS trader_id,
       attributes['SenderCompID']  AS sender_comp_id,
       attributes['TargetCompID']  AS target_comp_id,
       attributes['SourceTopic']   AS source_topic
FROM events
WHERE compliance_id = 'CMP123456'
  AND business_date = DATE '2026-07-17'
ORDER BY event_time;
```

```sql
-- filtering on a payload field: all working orders for one trader, one day.
-- envelope predicates (date, type) prune first; the attributes filter
-- then runs over the reduced row set.
SELECT event_time, compliance_id,
       attributes['OrderQty']  AS order_qty,
       attributes['LeavesQty'] AS leaves_qty
FROM events
WHERE business_date = DATE '2026-07-17'
  AND message_type  = 'ExecutionReport'
  AND attributes['TraderId']  = 'TRD042'
  AND attributes['OrdStatus'] IN ('New', 'PartiallyFilled')
ORDER BY event_time;
```

```sql
-- several business days: partition pruning makes the date range cheap —
-- only the listed days' files are touched, everything else is skipped.
-- Example: trace one order's activity across a week, all sources.
SELECT business_date, event_time, source, shard, message_type,
       attributes['OrdStatus']  AS ord_status,
       attributes['LeavesQty']  AS leaves_qty
FROM read_parquet('/data/order-trace/*/business_date=*/*.parquet',
                  hive_partitioning = true)
WHERE compliance_id = 'CMP123456'
  AND business_date BETWEEN DATE '2026-07-13' AND DATE '2026-07-17'
ORDER BY event_time;
```

```sql
-- aggregation over payload fields across days:
-- filled quantity by position account for the week.
-- NOTE: `attributes` values are strings — numeric fields need a CAST
-- before arithmetic. The per-type views (§8.1) bake these casts in once
-- so ad-hoc users get typed columns for free.
SELECT business_date,
       attributes['PositionAccount'] AS position_account,
       SUM(CAST(attributes['CumQty'] AS DOUBLE)) AS total_filled
FROM events
WHERE business_date BETWEEN DATE '2026-07-13' AND DATE '2026-07-17'
  AND message_type = 'ExecutionReport'
GROUP BY 1, 2
ORDER BY 1, 3 DESC;
```

*(Field names above are illustrative — actual keys in `attributes` are whatever the extraction utilities emit, e.g. FIX tag names. The per-type views in §8.1 give these stable, documented column names so ad-hoc users don't need to know raw key spellings.)*

Saved scripts under `queries/` (`find-order.sql`, `lifecycle.sql`, `find-legs.sql`, `find-rejects.sql`, `compare-sources.sql`, `ingestion-validation.sql`) plus thin shell wrappers, e.g. `find-order 2026-07-17 CMP123456`.

## 12. Intraday investigation path (same-day incidents)

The Parquet flow is end-of-day, but DuckDB also reads **JSON Lines directly**, which covers the "it happened an hour ago" case with the same tooling:

1. Copy the rolled journal segments for the current day (Neeve RDAT + Bedrock journal) into a designated **scratch folder** on the Golden Host.
2. Run the existing extraction utilities → JSON Lines (no Parquet conversion — it is one day, queried a handful of times).
3. Query in place: `SELECT ... FROM read_json_auto('/scratch/incident-20260717/neeve-*.jsonl') WHERE ...`

A pair of maintained **intraday views** (`neeve_raw`, `bedrock_raw`) maps the raw extracted field names onto the common column names, so the standard saved queries (compliance-ID lookup, link-ID leg resolution, lifecycle) work in both modes with no edits.

Honest limits, stated up front:

- **Freshness = last journal roll**, not real time. Data in the currently open segment is not visible until it rolls. For incident investigation this is normally sufficient; this path is *not* a monitoring or surveillance capability (see non-goals).
- **Slower than Parquet** — JSON scans are row-oriented and uncompressed-ish; acceptable for one day / one incident, which is exactly the scope.
- **Scratch hygiene:** the intraday extract is the only ad-hoc copy this design permits. The scratch folder lives on the same controlled host, is auto-cleaned same-day (or superseded by the normal EOD Parquet partition), and inherits the same access controls — keeping the governance story strictly better than today's copy-to-desktop workflow.



## 13. Performance and storage

### 13.1 Hardware footprint on the Golden Host

DuckDB does **not** load files into memory. Execution is streaming and vectorized, and Parquet lets it avoid most of the data before reading a byte:

- **Partition pruning** — only the queried `business_date` / `source` directories are opened.
- **Column projection** — only the columns a query touches are read; a compliance-ID lookup reads a handful of ~25 columns, and heavyweight columns (`raw_message`) are never touched unless selected.
- **Row-group skipping** — Parquet stores min/max statistics per block (~100k rows); blocks that cannot contain the searched value are skipped without decompression.

For a single-day lookup (≈2–4 GB of Parquet per day), this means **hundreds of MB of I/O and tens-to-hundreds of MB of working memory** — seconds of wall time. Aggregation memory is bounded by group counts (e.g. thousands of position accounts → trivial), not row counts, and operations that do exceed memory (large sorts/joins) **spill to disk** rather than failing — DuckDB is explicitly designed for larger-than-memory workloads.

**Indicative latency expectations** (estimates — replaced by Phase 1 benchmark measurements):

| Operation | Mode | Expected |
|---|---|---|
| Compliance-ID lifecycle, one day, both sources | Parquet (historical) | **low single-digit seconds** (sub-second when cached) |
| Multi-leg reconstruction from primary compliance ID | Parquet (historical) | seconds |
| Multi-day range / aggregation (e.g. one week) | Parquet (historical) | seconds to ~tens of seconds |
| One-time extraction of today's archives (unzip + RDAT/journal → JSON) | Same-day (intraday) | **minutes** — once per incident |
| Compliance-ID query over the day's raw JSON | Same-day (intraday) | tens of seconds per query |

The intraday extraction cost is paid once; if an incident investigation runs long, converting that day's JSON to Parquet early (the normal EOD step, run ad hoc) drops subsequent queries to the historical-mode numbers.

**Indicative server requirement: 4–8 cores, 8–16 GB RAM, local disk** — comfortably within an existing general-purpose host; no dedicated hardware. Disk throughput matters more than RAM (the Parquet directory should be on local/fast storage, not slow network mounts). On a shared host, each session sets `memory_limit` and `threads` explicitly so queries are capped, polite tenants; actual figures are measured in the Phase 1 benchmark (peak RSS is recorded alongside latency).

The dominant investigation pattern is expected to be **single-day** (orders rarely span days); the multi-day examples in §11 exist because the same design may later apply to longer-retention or higher-volume use (e.g. extending to equities), and partition pruning keeps ranges cheap either way.

Works well: compliance-ID lookups with a date; link-ID leg resolution; session + time range; message-type scans per day; lifecycle within an incident window; small cross-source correlations.
Needs care: identifier hunts across months without a date bound; unbounded full scans; large many-to-many joins; tiny-file sprawl.

**Sizing estimate (to confirm in POC):** ~20M events/day × ~1–2 KB extracted JSON ≈ 20–40 GB/day JSON → **~2–4 GB/day Parquet** at 10× compression; ≈ **1 TB/year** if run daily with full retention. Well within a single host's disk budget, but the quota should be requested explicitly.

**Benchmark plan (one representative high-volume day):** raw size → JSON size → Parquet size/ratio; conversion throughput (records & GB/min); compliance-ID lookup latency; multi-leg link resolution latency; cross-source lifecycle latency; behavior with a handful of concurrent support users; peak memory (RSS) per query pattern to confirm the §13.1 footprint estimates.

## 14. Beyond single incidents: what accumulated history unlocks

Once daily partitions accumulate, the Parquet directory becomes an analytical asset that a ~7-day Elasticsearch window cannot be:

- **A year of order history, queryable in seconds** — recurrence questions ("has this reject happened before?"), client-behavior queries, and month-over-month comparisons stop requiring warehouse requests and data-team round-trips; support answers them directly.
- **One-command investigations for RTB/support:** wrapper scripts take a compliance ID and business date and emit the complete lifecycle ready for analysis — no SQL knowledge needed for standard cases. The toolkit is one portable executable plus scripts.
- **Data-driven platform operations:** accumulated per-shard / per-symbol / per-underlying volume statistics turn re-sharding decisions and SpiderRock capacity planning from guesswork into a query — using data the platform generates itself.
- **Storage is the cheapest resource in computing:** a year of data is roughly a terabyte; the historical constraint was never storage cost but that the data sat in unqueryable formats.

## 15. Compliance, entitlements, and security

The risk is not DuckDB; it is creating a new searchable representation of sensitive trading data. Controls:

- Run only on the approved Golden Host / restricted query server.
- Reuse existing journal/ES entitlement groups where practical; require applicable data-access training. (Support staff who may query this derivative are the same population entitled to read the source journals today — the entitlement delta is small.)
- Parquet directory read-only for users; broad export disabled by default.
- Encryption per internal standards; approved retention defined up front (no "indefinite by accident").
- Mask or omit client/account/trader fields where not needed for support.
- Audit user, query time, filters, result counts, exports.
- Label clearly: **operational diagnostic derivative — not books and records.**

A controlled query service is arguably *more* compliant than today's manual file copying: access, retention, and searches become centralized and auditable.

## 16. Delivery phases

| Phase | Content | Effort |
|---|---|---|
| **1a — POC in non-production** | Build and prove the full pipeline against QA/SIT/UAT archives (identical formats, smaller volumes): unpack → extract → Parquet; shard-map validation; manifests; counts reconcile; **compliance/link ID coverage validated**. No production-side approvals required. | ~2–3 engineer-days, normal hours |
| **1b — Production-scale benchmark, still in non-production** | Copy one representative high-volume production day's archives into the non-production environment (via the standard data-handling process) and repeat the proven toolkit at full scale; collect the benchmark numbers (size ratios, latency, memory). Golden Host involvement is deferred entirely to Phase 3. | ~1–2 engineer-days |
| **2 — DuckDB toolkit** | Views, saved SQL, wrappers, documented support workflows | small, incremental |
| **3 — Controlled operations** | Scheduled EOD generation; entitlements, retention, auditing, monitoring | pending Phase 1 results |
| **4 — Optional service/UI** | Restricted API / lightweight UI **only after** CLI value is proven | not committed |

**Phase 1 success criteria:** one complete high-volume day converts with all expected shards present; counts reconcile; a known order is found by compliance ID in seconds; a known multi-leg order reconstructs from its primary compliance ID alone (link IDs discovered from the data) in one query; storage/retention costs are understood; compliance agrees a path for a controlled pilot.

Phase 1 is deliberately sized to fit inside normal support capacity. It implies **no new headcount and no out-of-hours work**; if priorities don't allow it, the design simply waits.

## 17. Risks and open questions

| Area | Question / risk |
|---|---|
| Vendor decoding | Largely retired: RDAT→JSON tooling exists and was proven at full-day scale during the Apex 2→3 migration validation. Residual: confirm current owner/approval status, version compatibility with today's RDAT format, and generic (non-fixed-field-list) output — see §8.1. |
| Tool approval | Can DuckDB be installed on the Golden Host? (Fallback: pyarrow.) |
| Key coverage | Are `compliance_id` / `link_id` populated and extractable in **every** relevant record type in both sources? (Promoted to a Phase 1 deliverable.) |
| HA duplicates | Confirm the primary/backup journal overlap semantics and the dedupe rule against a real failover day. |
| Time semantics | Source hosts run NY-local time; confirm precision, monotonicity, and cross-host skew tolerances for ordering within a lifecycle. |
| Completeness | Shard map covers topology changes; who maintains it when shards are added/removed? |
| Retention | What retention period is operationally useful *and* compliance-approved? |
| Capacity | Golden Host disk quota (~TB/year at full retention); who owns Phase 2+ if Phase 1 succeeds? (Explicitly unfunded today.) |
| Schema evolution | Addressed by design (§8.1): pass-through `attributes` + additive column promotion via `parser_version`. Residual question: extractor must emit newly added fields generically rather than from a fixed field list — confirm per utility. |
| Authoritative status | Preventing misuse of the derivative as official record? |

## 18. Recommendation

Proceed with a narrowly scoped POC: convert one representative day of already-retained, shard-aggregated Neeve RDAT and Bedrock journal data into normalized daily Parquet and query it with DuckDB (or approved fallback) on the Golden Host.

First deliverable is a **command-line toolkit, not a platform**: two converters, one common schema, a shard-aware completeness check, quality manifests, a handful of saved queries keyed on compliance ID, and benchmark numbers.

Position the initiative as an **options order-trace and support visibility tool**. The business objective is faster, more reliable incident investigation across proprietary transaction stores — ready *before* SpiderRock volumes make the current workflow untenable — at lower cost and with better control than manual copying.

---
*Product names, proprietary file semantics, entitlements, retention, and deployment constraints to be confirmed with the relevant Barclays, Neeve Research, infrastructure, and compliance owners.*
