#!/bin/bash
# launch TLT

usage() {
    echo "Usage: $0 [-t <set the location of .jar file>]"
    exit
}

FILE=$(readlink -f $0)
DIR=$(dirname $FILE)
. $DIR/../setEnvironment

# TODO VERIFY: stockloan used /app/stockloan-gateway/lib/* -> swapped to optionpricer-gateway
REL_DIR="/app/optionpricer-gateway/lib/*"

MODULE_OPTS="--add-opens=java.base/sun.nio.ch=ALL-UNNAMED \
  --add-opens=java.base/jdk.internal.ref=ALL-UNNAMED \
  --add-opens=java.base/java.nio=ALL-UNNAMED \
  --add-opens=java.base/java.io=ALL-UNNAMED"

while getopts t:h flag;
do
    case ${flag} in
        h) usage;;
        t) REL_DIR=("$OPTARG");;
        *) echo "Unknown option, see usage below"
           usage;;
    esac
done

TLT="$JAVA_HOME/bin/java $MODULE_OPTS -cp '$BASE_DIR$REL_DIR' com.neeve.tools.TransactionLogTool"
eval "$TLT"
