package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.apex.scheduler.Scheduler;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

/**
 * Covers dispatch routing only. Solace setup and the scheduleOnce thread hop are
 * exercised by the embedded-engine integration test, not here.
 * Requires BifrostInboundListener.dispatch to be package-private.
 */
public class BifrostInboundListenerTest extends BifrostTestSetup {

    @Mock private PricingResponseHandler pricingResponseHandler;
    @Mock private RiskProfileUpdateHandler riskProfileUpdateHandler;
    @Mock private Scheduler scheduler; // unused by dispatch; only needed for construction

    private BifrostInboundListener listener;

    @Before
    public void setUp() {
        listener = new BifrostInboundListener(pricingResponseHandler, riskProfileUpdateHandler, scheduler);
    }

    @Test
    public void testDispatchRoutesResponseTopicToResponseHandler() {
        PricingResponse response = PricingResponse.newBuilder()
                .setSendingTime(buildDate(SENDING_MILLIS))
                .addPricingResult(buildPricingResult(0, "bb_dev_AAPL.O", 7.50, 0.55, 0.03))
                .build();

        listener.dispatch("Pricing/RESPONSE/AAPL/corr-1", response.toByteArray());

        verify(pricingResponseHandler).handle(any(PricingResponse.class));
        verify(riskProfileUpdateHandler, never()).handle(anyString(), any(RiskProfile.class));
    }

    @Test
    public void testDispatchRoutesGreeksTopicToRiskHandlerWithProductId() {
        RiskProfile rp = buildRiskProfile(7.50, 0.55, 0.03);

        listener.dispatch("Pricing/GREEKS/AAPL/bb_dev_AAPL.O", rp.toByteArray());

        verify(riskProfileUpdateHandler).handle(eq("bb_dev_AAPL.O"), any(RiskProfile.class));
        verify(pricingResponseHandler, never()).handle(any(PricingResponse.class));
    }

    @Test
    public void testDispatchIgnoresUnexpectedTopic() {
        listener.dispatch("Pricing/UNKNOWN/foo", new byte[]{1, 2, 3});

        verify(pricingResponseHandler, never()).handle(any(PricingResponse.class));
        verify(riskProfileUpdateHandler, never()).handle(anyString(), any(RiskProfile.class));
    }

    @Test
    public void testDispatchDropsGreeksTopicMissingProductId() {
        RiskProfile rp = buildRiskProfile(7.50, 0.55, 0.03);

        // No productId segment -> extractor throws -> caught, no handler call.
        listener.dispatch("Pricing/GREEKS/AAPL", rp.toByteArray());

        verify(riskProfileUpdateHandler, never()).handle(anyString(), any(RiskProfile.class));
    }
}
