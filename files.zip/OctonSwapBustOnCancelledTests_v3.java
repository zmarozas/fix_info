@Story(spec = "https://estjira.barcapint.com/browse/BLACKBIRD-55358")
@Test
public void testVenueBustOnCancelledOctonSwapOrdersDoesNotRestoreOpenQuantity() {

    puma.requestNewOrder().handlInst(Manual).send();
    OrderReference agencySalesRoot = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Root).reference();

    batman.takeOwnership(agencySalesRoot).send();
    batman.acceptRootOrder(agencySalesRoot).deskId(DRV_SALES).send();
    OrderReference agencySalesWave = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Wave).reference();

    batman.slice(agencySalesWave).deskId(null).targetDeskId(SWAP).send();
    OrderReference agencySalesSlice = batman.mustSee().order()
            .portfolioType(Agency).deskId(DRV_SALES).parentChildType(Child).reference();

    OrderReference swapAgencyRoot = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Root).deskId(SWAP)
            .state(PENDING_NEW).reference();

    OrderReference hedgeRoot = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Root).deskId(SWAP).reference();
    batman.acceptRootOrder(hedgeRoot).deskId(SWAP).send();
    OrderReference hedgeWave = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Wave).deskId(SWAP).reference();

    batman.slice(hedgeWave).targetCompID(zeroTouchSourceLocation).send();
    OrderReference hedgeSlice = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Child).deskId(SWAP).reference();
    OrderReference affiliateHedgeSlice = batman.mustSee().order()
            .portfolioType(AffiliateHedge).parentChildType(Child).reference();

    zeroTouch.mustSee().newOrderSingle();
    ZeroTouchOrder ztOrder = zeroTouch.acceptOrder().send();
    zeroTouch.fillOrder(ztOrder).lastQty(100)
            .execID("123").origExecId("123")
            .tradeCaptureSystem("BBEMSZTNYK").tradeExecutionSystem("BBEMSZTNYK").send();

    batman.mustSee().order().orderID(affiliateHedgeSlice.orderID)
            .cumQty(100).state(PARTIALLY_FILLED);

    batman.requestCancel(hedgeSlice).send();
    zeroTouch.mustSee().orderCancelRequest();
    zeroTouch.acceptCancel(ztOrder).send();
    batman.mustReceiveResponse(CANCEL_SLICE).success();

    batman.mustSee().order().orderID(hedgeSlice.orderID).state(CANCELLED);
    batman.mustSee().order().orderID(affiliateHedgeSlice.orderID).state(CANCELLED);
    batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Wave)
            .state(CANCELLED);
    batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Root)
            .state(CANCELLED);

    zeroTouch.bustExecution().execRefID("123").origExecRefId("123").send();

    batman.mustSee().order().orderID(affiliateHedgeSlice.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Wave)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Root)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(hedgeSlice.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);

    batman.mustSee().order().orderID(hedgeWave.orderID).cumQty(0);
    batman.mustSee().order().orderID(hedgeRoot.orderID).cumQty(0).leavesQty(1000);
    batman.mustSee().order().orderID(swapAgencyRoot.orderID).cumQty(0);
    batman.mustSee().order().orderID(agencySalesRoot.orderID).cumQty(0);
}

@Story(spec = "https://estjira.barcapint.com/browse/BLACKBIRD-55358")
@Test
public void testBatmanBustOnCancelledOctonSwapOrdersDoesNotRestoreOpenQuantity() {

    puma.requestNewOrder().handlInst(Manual).send();
    OrderReference agencySalesRoot = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Root).reference();

    batman.takeOwnership(agencySalesRoot).send();
    batman.acceptRootOrder(agencySalesRoot).deskId(DRV_SALES).send();
    OrderReference agencySalesWave = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Wave).reference();

    batman.slice(agencySalesWave).deskId(null).targetDeskId(SWAP).send();
    OrderReference agencySalesSlice = batman.mustSee().order()
            .portfolioType(Agency).deskId(DRV_SALES).parentChildType(Child).reference();

    OrderReference swapAgencyRoot = batman.mustSee().order()
            .portfolioType(Agency).parentChildType(Root).deskId(SWAP)
            .state(PENDING_NEW).reference();

    OrderReference hedgeRoot = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Root).deskId(SWAP).reference();
    batman.acceptRootOrder(hedgeRoot).deskId(SWAP).send();
    OrderReference hedgeWave = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Wave).deskId(SWAP).reference();

    batman.slice(hedgeWave).targetCompID(zeroTouchSourceLocation).send();
    OrderReference hedgeSlice = batman.mustSee().order()
            .portfolioType(Hedge).parentChildType(Child).deskId(SWAP).reference();
    OrderReference affiliateHedgeSlice = batman.mustSee().order()
            .portfolioType(AffiliateHedge).parentChildType(Child).reference();

    zeroTouch.mustSee().newOrderSingle();
    ZeroTouchOrder ztOrder = zeroTouch.acceptOrder().send();
    zeroTouch.fillOrder(ztOrder).lastQty(100)
            .execID("123").origExecId("123")
            .tradeCaptureSystem("BBEMSZTNYK").tradeExecutionSystem("BBEMSZTNYK").send();

    batman.mustSee().order().orderID(affiliateHedgeSlice.orderID)
            .cumQty(100).state(PARTIALLY_FILLED);

    batman.requestCancel(hedgeSlice).send();
    zeroTouch.mustSee().orderCancelRequest();
    zeroTouch.acceptCancel(ztOrder).send();
    batman.mustReceiveResponse(CANCEL_SLICE).success();

    batman.mustSee().order().orderID(hedgeSlice.orderID).state(CANCELLED);
    batman.mustSee().order().orderID(affiliateHedgeSlice.orderID).state(CANCELLED);
    batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Wave)
            .state(CANCELLED);
    batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Root)
            .state(CANCELLED);

    batman.bustExecution().orderID(hedgeRoot.orderID).origExecID("123").send();

    batman.mustSee().order().orderID(affiliateHedgeSlice.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Wave)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().portfolioType(AffiliateHedge).parentChildType(Root)
            .cumQty(0).leavesQty(0).state(CANCELLED);
    batman.mustSee().order().orderID(hedgeSlice.orderID)
            .cumQty(0).leavesQty(0).state(CANCELLED);

    batman.mustSee().order().orderID(hedgeWave.orderID).cumQty(0);
    batman.mustSee().order().orderID(hedgeRoot.orderID).cumQty(0).leavesQty(1000);
    batman.mustSee().order().orderID(swapAgencyRoot.orderID).cumQty(0);
    batman.mustSee().order().orderID(agencySalesRoot.orderID).cumQty(0);
}
