package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;
import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResult;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Handles initial BiFrost PricingResponse messages (Solace topic Pricing/RESPONSE/...).
 * <p>
 * For ongoing per-cycle Greeks updates BiFrost uses a separate topic (Pricing/GREEKS/...)
 * carrying a raw RiskProfile; those are handled by {@link RiskProfileUpdateHandler}.
 * <p>
 * For each PricingResult in the response:
 *   - skip if per-result error is populated (logged elsewhere)
 *   - log warning if per-result warning is populated, but still publish
 *   - decode ProductId -> RIC via codec
 *   - translate RiskProfile -> ROE snapshot, publish
 * <p>
 * Top-level response error short-circuits the whole batch.
 */
@Singleton
public final class PricingResponseHandler {

    private final ProductIdCodec productIdCodec;
    private final PricingMessageTranslator translator;
    private final OptionPricingSnapshotPublisher publisher;

    @Inject
    public PricingResponseHandler(ProductIdCodec productIdCodec,
                                  PricingMessageTranslator translator,
                                  OptionPricingSnapshotPublisher publisher) {
        this.productIdCodec = productIdCodec;
        this.translator = translator;
        this.publisher = publisher;
    }

    public void handle(PricingResponse response) {
        // Top-level error - BiFrost rejected the whole request, skip publish entirely.
        if (response.hasError() && !response.getError().isEmpty()) {
            // TODO log: response.getError(), response.getCorrelationId()
            return;
        }

        long sendingTimeMillis = response.getSendingTime().getTimestamp();

        for (PricingResult result : response.getPricingResultList()) {
            // Per-result error - skip just this entry, others may still be valid.
            if (result.hasError() && !result.getError().isEmpty()) {
                // TODO log per-result error w/ tradeIndex, productId, error msg
                continue;
            }
            // Per-result warning - non-fatal, log but still publish.
            if (result.hasWarning() && !result.getWarning().isEmpty()) {
                // TODO log per-result warning w/ tradeIndex, productId, warning msg
            }

            String productId = result.getProductId();
            String ric;
            try {
                ric = productIdCodec.decode(productId);
            } catch (IllegalArgumentException e) {
                // ProductId doesn't match our env prefix - the Solace bridge layer
                // shouldn't normally route foreign messages to us, but defend anyway.
                // TODO log
                continue;
            }

            RiskProfile riskProfile = result.getRiskProfile();

            IOptionPricingSnapshotMessage snapshot =
                    translator.toRoeSnapshot(ric, riskProfile, sendingTimeMillis);

            publisher.publish(snapshot);
        }
    }
}
