package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;
import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResult;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Handles initial BiFrost PricingResponse messages on Solace topic Pricing/RESPONSE/...
 * Per-cycle Greeks updates use a separate topic and are handled by RiskProfileUpdateHandler.
 */
@Singleton
public final class PricingResponseHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(PricingResponseHandler.class);

    private final ProductIdCodec productIdCodec;
    private final PricingMessageTranslator translator;
    private final OptionPricingSnapshotPublisher publisher;

    @Inject
    public PricingResponseHandler(ProductIdCodec productIdCodec,
                                  PricingMessageTranslator translator,
                                  OptionPricingSnapshotPublisher publisher) {
        this.productIdCodec = productIdCodec;
        this.translator = translator;
        this.publisher = publisher;
    }

    public void handle(PricingResponse response) {
        if (response.hasError() && !response.getError().isEmpty()) {
            LOGGER.warn("Skipping PricingResponse due to top-level error: correlationId={}, error={}",
                    response.getCorrelationId(), response.getError());
            return;
        }

        long sendingTimeMillis = response.getSendingTime().getTimestamp();

        for (PricingResult result : response.getPricingResultList()) {
            if (result.hasError() && !result.getError().isEmpty()) {
                LOGGER.warn("Skipping PricingResult with error: tradeIndex={}, productId={}, error={}",
                        result.getTradeIndex(), result.getProductId(), result.getError());
                continue;
            }
            if (result.hasWarning() && !result.getWarning().isEmpty()) {
                LOGGER.warn("PricingResult has warning, publishing anyway: tradeIndex={}, productId={}, warning={}",
                        result.getTradeIndex(), result.getProductId(), result.getWarning());
            }

            String productId = result.getProductId();
            String ric;
            try {
                ric = productIdCodec.decode(productId);
            } catch (IllegalArgumentException e) {
                LOGGER.warn("Skipping PricingResult: productId not from this bridge's environment: productId={}",
                        productId);
                continue;
            }

            RiskProfile riskProfile = result.getRiskProfile();
            IOptionPricingSnapshotMessage snapshot =
                    translator.toRoeSnapshot(ric, riskProfile, sendingTimeMillis);
            publisher.publish(snapshot);
        }
    }
}
