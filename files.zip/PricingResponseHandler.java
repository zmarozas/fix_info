package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;
import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResult;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Handles initial BiFrost PricingResponse messages on Solace topic Pricing/RESPONSE/...
 * Per-cycle Greeks updates use a separate topic and are handled by RiskProfileUpdateHandler.
 */
@Singleton
public final class PricingResponseHandler {

    private final ProductIdCodec productIdCodec;
    private final PricingMessageTranslator translator;
    private final OptionPricingSnapshotPublisher publisher;

    @Inject
    public PricingResponseHandler(ProductIdCodec productIdCodec,
                                  PricingMessageTranslator translator,
                                  OptionPricingSnapshotPublisher publisher) {
        this.productIdCodec = productIdCodec;
        this.translator = translator;
        this.publisher = publisher;
    }

    public void handle(PricingResponse response) {
        if (response.hasError() && !response.getError().isEmpty()) {
            // TODO log: response.getError(), response.getCorrelationId()
            return;
        }

        long sendingTimeMillis = response.getSendingTime().getTimestamp();

        for (PricingResult result : response.getPricingResultList()) {
            if (result.hasError() && !result.getError().isEmpty()) {
                // TODO log per-result error w/ tradeIndex, productId
                continue;
            }
            if (result.hasWarning() && !result.getWarning().isEmpty()) {
                // TODO log per-result warning w/ tradeIndex, productId
            }

            String productId = result.getProductId();
            String ric;
            try {
                ric = productIdCodec.decode(productId);
            } catch (IllegalArgumentException e) {
                // TODO log foreign-env productId
                continue;
            }

            RiskProfile riskProfile = result.getRiskProfile();
            IOptionPricingSnapshotMessage snapshot =
                    translator.toRoeSnapshot(ric, riskProfile, sendingTimeMillis);
            publisher.publish(snapshot);
        }
    }
}
