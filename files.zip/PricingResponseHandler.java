package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResponse;
import protobuf.com.barcap.eq.risk.flow.PricingData.PricingResult;
import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Outbound handler: BiFrost PricingResponse -> ROE option pricing snapshots.
 * <p>
 * BiFrost emits the same PricingResponse shape for the initial response and
 * for ongoing updates - a batched list of PricingResult, each carrying the
 * ProductId we sent on the request and a RiskProfile with the pricing data.
 * <p>
 * For each result: decode ProductId -> RIC via the codec, translate the
 * RiskProfile into an ROE snapshot, publish to Blackbird Trading.
 * <p>
 * Stateless - no per-subscription tracking. The ProductId encodes everything
 * needed to route the snapshot back to the right Blackbird VPN.
 */
@Singleton
public final class PricingResponseHandler {

    private final ProductIdCodec productIdCodec;
    private final PricingMessageTranslator translator;
    private final OptionPricingSnapshotPublisher publisher;

    @Inject
    public PricingResponseHandler(ProductIdCodec productIdCodec,
                                  PricingMessageTranslator translator,
                                  OptionPricingSnapshotPublisher publisher) {
        this.productIdCodec = productIdCodec;
        this.translator = translator;
        this.publisher = publisher;
    }

    /**
     * Handle a BiFrost PricingResponse - same shape for initial responses and
     * ongoing updates. Wires to the Solace inbound channel binding.
     */
    public void handle(PricingResponse response) {
        // Top-level error: BiFrost rejected the whole request. Skip publish.
        // TODO confirm with Bapu: per-result error vs top-level. For now we
        // treat top-level error as "drop entire batch" and rely on per-result
        // shape (if any) once confirmed.
        if (response.hasError() && !response.getError().isEmpty()) {
            // TODO log: response.getError(), response.getCorrelationId()
            return;
        }

        long sendingTimeMillis = response.getSendingTime().getTimestamp();

        // PricingResult shape - ASSUMED based on symmetry with ProductData on
        // the request side. Verify via Shift+Shift on PricingResult:
        //   - PricingResult.getProductId() returns String
        //   - PricingResult.getRiskProfile() returns RiskpnlData.RiskProfile
        // If names differ, compilation will catch it.
        for (PricingResult result : response.getPricingResultList()) {
            String productId = result.getProductId();
            String ric = productIdCodec.decode(productId);
            RiskProfile riskProfile = result.getRiskProfile();

            IOptionPricingSnapshotMessage snapshot =
                    translator.toRoeSnapshot(ric, riskProfile, sendingTimeMillis);

            publisher.publish(snapshot);
        }
    }
}
