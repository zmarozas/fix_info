package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.roe.optionpricer.IOptionPricingSnapshotMessage;

import protobuf.com.barcap.eq.risk.flow.RiskpnlData.RiskProfile;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class RiskProfileUpdateHandlerTest extends BifrostTestSetup {

    @Mock private OptionPricingSnapshotPublisher publisher;

    private RiskProfileUpdateHandler handler;

    @Before
    public void setUp() {
        handler = new RiskProfileUpdateHandler(
                new ProductIdCodec(ENV_PREFIX),
                new PricingMessageTranslator(),
                publisher);
    }

    @Test
    public void testHandlePublishesSnapshotFromTopicProductIdAndRiskProfile() {
        RiskProfile rp = buildRiskProfile(7.50, 0.55, 0.03);

        // productId carried in the Solace topic path, not the message body
        handler.handle("bb_dev_AAPL.O", rp);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher).publish(captor.capture());

        IOptionPricingSnapshotMessage snap = captor.getValue();
        assertEquals("AAPL.O", snap.getRIC());
        assertEquals(SENDING_MILLIS, snap.getSendingTimeAsTimestamp());
        assertEquals(7.50, snap.getTheoValue(), EPSILON);
        assertEquals(0.55, snap.getDelta(), EPSILON);
        assertEquals(0.03, snap.getGamma(), EPSILON);
    }

    @Test
    public void testHandleDecodesProductIdToRecoverRic() {
        RiskProfile rp = buildRiskProfile(12.30, 0.60, 0.04);

        handler.handle("bb_dev_MSFT.OQ", rp);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher).publish(captor.capture());

        assertEquals("MSFT.OQ", captor.getValue().getRIC());
    }

    @Test
    public void testHandleDropsUpdateWhenProductIdHasWrongPrefix() {
        // Solace bridge layer should never route foreign-env messages to us,
        // but the handler defends against it anyway.
        RiskProfile rp = buildRiskProfile(7.50, 0.55, 0.03);

        handler.handle("bb_qa_AAPL.O", rp);

        verify(publisher, never()).publish(any());
    }

    @Test
    public void testHandleUsesRiskProfilePricingDateForSnapshotTimestamp() {
        // RiskProfile carries its own pricingDate (BifrostTestSetup defaults
        // this to SENDING_MILLIS via buildRiskProfile).
        RiskProfile rp = buildRiskProfile(7.50, 0.55, 0.03);

        handler.handle("bb_dev_AAPL.O", rp);

        ArgumentCaptor<IOptionPricingSnapshotMessage> captor =
                ArgumentCaptor.forClass(IOptionPricingSnapshotMessage.class);
        verify(publisher).publish(captor.capture());

        assertEquals(SENDING_MILLIS, captor.getValue().getSendingTimeAsTimestamp());
    }
}
