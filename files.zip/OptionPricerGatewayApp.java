package com.barcap.eq.oms;

import java.util.List;

import javax.inject.Inject;

import com.neeve.aep.event.AepEngineActiveEvent;
import org.glassfish.hk2.utilities.Binder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.barcap.eq.oms.module.BiFrostAdapterModule;
import com.barcap.eq.oms.server.bifrost.BifrostAdapter;
import com.barcap.eq.oms.shared.SystemStartTimeService;
import com.barclays.eq.apex.ApexServerApplication;
import com.barclays.eq.apex.EngineProvider;
import com.barclays.eq.apex.config.ApexConfiguration;
import com.barclays.eq.apex.lifecycle.tasks.FirstTransactionTask;
import com.barclays.eq.configuration.component.impl.ConfigurationComponentModule;
import com.barclays.eq.oms.apex.utils.JmxLoader;
import com.barclays.eq.oms.apex.utils.StartupEventHandler;
import com.neeve.aep.AepEngine;
import com.neeve.aep.annotations.EventHandler;
import com.neeve.server.app.annotations.AppHAPolicy;

@AppHAPolicy(AepEngine.HAPolicy.EventSourcing)
public class OptionPricerGatewayApp extends ApexServerApplication implements FirstTransactionTask {

    private static final Logger LOGGER = LoggerFactory.getLogger(OptionPricerGatewayApp.class);

    @Inject
    private SystemStartTimeService systemStartTimeService;

    @Inject
    private StartupEventHandler startupEventHandler;

    @Inject
    private EngineProvider engineProvider;

    @Inject
    private BifrostAdapter bifrostAdapter;

    // for IDE only
    public static void main(String[] args) {
        boolean isWin = System.getProperty("os.name").toLowerCase().startsWith("win");
        if (isWin) {
            System.setProperty("shard", "1");
            System.setProperty("appName", "optionpricer-gateway");
        }
        LOGGER.info("Starting optionpricer-gateway.");
        com.neeve.server.Main.main(args);
    }

    @Override
    protected void addApplicationModules(List<Binder> modules) {
        ApexConfiguration apexConfiguration = getApexConfiguration();
        modules.add(new BiFrostAdapterModule(apexConfiguration));
        modules.add(new ConfigurationComponentModule(apexConfiguration.getConfig()));
    }

    @Override
    public String getDescription() {
        return "OptionpricerGatewayApp";
    }

    @Override
    public void onFirstTransaction() throws Exception {
        systemStartTimeService.recordSystemStartTime();
        JmxLoader.startJmx(getApexConfiguration(), "optionpricerGateway");
        startupEventHandler.primaryOrBackupStartedSuccessfully();
    }

    // Stockloan starts its adapter from handle(StaticDataLoadedMessage) after async data load and
    // re-starts here on failover. This bridge has no static data, so the adapter is started when the
    // engine becomes active.
    // TODO confirm AepEngineActiveEvent fires on INITIAL primary startup, not only on failover.
    //      If it does not fire on initial startup, call startBifrostAdapter() from onFirstTransaction.
    @EventHandler
    public void handle(AepEngineActiveEvent event) {
        startBifrostAdapter();
    }

    private void startBifrostAdapter() {
        if (!getEngine().isPrimary()) {
            LOGGER.info("Not starting BiFrost Adapter on backup/DR.");
            return;
        }
        LOGGER.info("Starting BiFrost Adapter.");
        try {
            bifrostAdapter.setup();
        } catch (Exception ex) {
            LOGGER.error("Failed to start BiFrost Adapter, exiting app", ex);
            engineProvider.getEngine().setAsLastTransaction(ex, true);
        }
    }
}
