# BLACKBIRD-55073 — MR replies to Zahid

## Reply 1 — AmerToEmeaFundingTradeOrderSpecification
> "do we need this method? can we simplify this class by reducing public methods?"

Both are used — the 2-arg overload is needed at slice creation where `order.getDestination()` isn't set yet and targetDeskId only arrives via params. They delegate to the same private method, so no logic is duplicated.

---

## Reply 2 — AmerToEmeaTargetBookCalculator
> "so many public methods?"

All four are used — one params+parent overload and one parent-only overload per field, for the slice path vs the wave/auto-slice path. `isOverrideEnabled()` and `mapBook()` are private. Making the rest private breaks the translator call sites, which are in a different package.
