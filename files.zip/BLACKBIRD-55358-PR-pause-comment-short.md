# PR comment - short version

Pausing this MR.

`ReinstatingBustOnDownstreamSliceWithMultipleWavesAcceptanceTest.testReinstatingBustOfOnlyExecutionOnCancelledSliceOfSecondWave`
(BLACKBIRD-3024) fails: it expects a venue-cancelled slice to be re-opened by a
reinstating bust with SentQty > 0 on the CANCELLED order - the opposite of what
this MR enforces (SentQty=0 on cancelled orders, per Batman's terminal-order
contract and the incident).

I tried scoping the fix to firm-cancelled orders only (venue cancels keep the
re-open behaviour). That fixed the slice-level assertions, but the wave-level
assertion still fails - wave sent restores through a different path.

Existing specs answer "what should quantities be on a cancelled order after a
bust" differently per flow. Before writing more code I need guidance on the
intended behaviour. Do not merge until then.
