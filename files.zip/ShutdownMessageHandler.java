package com.barcap.eq.oms.server.bifrost;

import com.barclays.eq.oms.apex.utils.AdminShutdownMessageHandler; // TODO confirm FQN (folded in stockloan's import)

import com.neeve.managed.annotations.Managed;

import org.jvnet.hk2.annotations.Optional; // TODO confirm FQN (folded in stockloan's import)

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Apex shutdown hook. Tears down the BiFrost adapter (Solace session + subscriptions) when the
 * app receives an admin shutdown message. Mirrors stockloan's ShutdownMessageHandler, minus the
 * broadcast senders this bridge does not have.
 */
@Managed
@Singleton
public final class ShutdownMessageHandler extends AdminShutdownMessageHandler {

    @Inject
    @Optional
    private BifrostAdapter bifrostAdapter;

    @Override
    protected void beforeShutdown() {
        super.beforeShutdown();
        // TODO move to LastTransactionTask once Apex shutdown is used.
        if (bifrostAdapter != null) {
            bifrostAdapter.shutdown();
        }
    }
}
