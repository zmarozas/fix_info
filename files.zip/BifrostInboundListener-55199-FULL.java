package com.barcap.eq.oms.server.bifrost;

import com.google.protobuf.InvalidProtocolBufferException;
import com.solacesystems.jcsmp.BytesXMLMessage;
import com.solacesystems.jcsmp.ConsumerFlowProperties;
import com.solacesystems.jcsmp.FlowReceiver;
import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.JCSMPFactory;
import com.solacesystems.jcsmp.JCSMPProperties;
import com.solacesystems.jcsmp.JCSMPSession;
import com.solacesystems.jcsmp.Queue;
import com.solacesystems.jcsmp.XMLMessageListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

// NOTE: keep your existing imports for PricingResponse, RiskProfile,
// Scheduler, and the handler classes — check against your current file.

/**
 * Consumes BiFrost messages from a durable Solace queue (topic subscriptions
 * mapped broker-side) and bridges inbound messages to the business handlers.
 * onReceive runs on the Solace I/O thread and hands work to the apex
 * transaction thread via Scheduler.scheduleOnce, so the downstream ROE publish
 * runs in a transaction.
 */
@Singleton
public class BifrostInboundListener {

    private static final String RESPONSE_TOPIC_PREFIX = "Pricing/RESPONSE/";
    private static final String GREEKS_TOPIC_PREFIX = "Pricing/GREEKS/";

    private final Logger logger = LoggerFactory.getLogger(BifrostInboundListener.class);

    private final PricingResponseHandler pricingResponseHandler;
    private final RiskProfileUpdateHandler riskProfileUpdateHandler;
    private final EnvironmentPrefixTranslator environmentPrefixTranslator;
    private final Scheduler scheduler;

    // package-private so unit tests can assign it (DI sets it at runtime)
    @Inject @Named(BifrostAdapter.Solace.BIFROST_INBOUND_QUEUE)
    String bifrostInboundQueueName;

    private FlowReceiver bifrostInboundConsumer;

    @Inject
    public BifrostInboundListener(PricingResponseHandler pricingResponseHandler,
                                  RiskProfileUpdateHandler riskProfileUpdateHandler,
                                  EnvironmentPrefixTranslator environmentPrefixTranslator,
                                  Scheduler scheduler) {
        this.pricingResponseHandler = pricingResponseHandler;
        this.riskProfileUpdateHandler = riskProfileUpdateHandler;
        this.environmentPrefixTranslator = environmentPrefixTranslator;
        this.scheduler = scheduler;
    }

    public void setup(JCSMPSession session) throws JCSMPException {
        final Queue queue = JCSMPFactory.onlyInstance().createQueue(bifrostInboundQueueName);

        final ConsumerFlowProperties flowProperties = new ConsumerFlowProperties();
        flowProperties.setEndpoint(queue);
        flowProperties.setAckMode(JCSMPProperties.SUPPORTED_MESSAGE_ACK_AUTO);

        bifrostInboundConsumer = session.createFlow(new XMLMessageListener() {
            @Override
            public void onReceive(BytesXMLMessage msg) {
                // Copy out now; the BytesXMLMessage may be recycled after onReceive returns.
                String topicName = msg.getDestination().getName();
                byte[] payload = msg.getBytes();
                scheduler.scheduleOnce(() -> dispatch(topicName, payload)).immediately();
            }

            @Override
            public void onException(JCSMPException ex) {
                logger.error("BiFrost solace consumer error", ex);
            }
        }, flowProperties);

        bifrostInboundConsumer.start();
        logger.info("BiFrost solace inbound queue consumer started, queue: {}",
                bifrostInboundQueueName);
    }

    public void shutdown() {
        if (bifrostInboundConsumer != null) {
            bifrostInboundConsumer.close();
        }
    }

    void dispatch(String topicName, byte[] payload) {
        try {
            if (topicName.startsWith(RESPONSE_TOPIC_PREFIX)) {
                String underlyingName = extractTopicSegment(topicName, RESPONSE_TOPIC_PREFIX, 0);
                PricingResponse response = PricingResponse.parseFrom(payload);
                pricingResponseHandler.handle(underlyingName, response);
            } else if (topicName.startsWith(GREEKS_TOPIC_PREFIX)) {
                TopicParts parts = parseTopicParts(topicName, GREEKS_TOPIC_PREFIX);
                if (!environmentPrefixTranslator.isValid(parts.productId)) {
                    logger.warn("Ignoring greeks for productId with unexpected prefix: {}",
                            parts.productId);
                    return;
                }
                RiskProfile riskProfile = RiskProfile.parseFrom(payload);
                riskProfileUpdateHandler.handle(parts.underlyingName, parts.productId, riskProfile);
            } else {
                logger.warn("Received message on unexpected topic: {}", topicName);
            }
        } catch (InvalidProtocolBufferException e) {
            logger.error("Failed to parse protobuf payload, topic: {}", topicName, e);
        } catch (RuntimeException e) {
            logger.error("Error dispatching inbound BiFrost message, topic: {}", topicName, e);
        }
    }

    // Parse both underlying name and product ID in one pass
    private static TopicParts parseTopicParts(String topicName, String prefix) {
        int start = prefix.length();
        int firstSlash = topicName.indexOf('/', start);

        if (firstSlash <= start || firstSlash >= topicName.length() - 1) {
            throw new IllegalArgumentException("Invalid topic format: " + topicName);
        }

        String underlyingName = topicName.substring(start, firstSlash);
        String productId = topicName.substring(firstSlash + 1);

        return new TopicParts(underlyingName, productId);
    }

    // Extract a single segment from topic (for RESPONSE topics)
    private static String extractTopicSegment(String topicName, String prefix, int segmentIndex) {
        int start = prefix.length();
        int slashIdx = topicName.indexOf('/', start);

        if (slashIdx <= start) {
            throw new IllegalArgumentException("Invalid topic format: " + topicName);
        }

        return segmentIndex == 0 ? topicName.substring(start, slashIdx)
                                 : topicName.substring(slashIdx + 1);
    }

    // Simple value object to hold parsed topic parts
    private static class TopicParts {
        final String underlyingName;
        final String productId;

        TopicParts(String underlyingName, String productId) {
            this.underlyingName = underlyingName;
            this.productId = productId;
        }
    }
}
